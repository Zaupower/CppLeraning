﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Net.NetworkInformation;
using System.IO;
using ICSharpCode.SharpZipLib.Zip;

using AutoTestingService.Logging;
using System.Text.RegularExpressions;
using System.Net.Sockets;
using System.IO.Compression;
using System.Text;
using AutoTestingService.Shared;

namespace AutoTestingService
{
	/// <summary>Helper class.</summary>
	/// <description>>Class which stores relevant information and useful methods that should be shared by the Server
	/// and Client</description>
	public class Helper
	{
		#region Singleton

		public static Helper Instance { get; } = new Helper ();

		private Helper ()
		{
		}

		#endregion

		#region variables

		/// <summary>Ping timeout value (in milliseconds).</summary>
		public int PingTimeout = 10000;

		private IPAddress[] currentAddresses = Dns.GetHostEntry(Dns.GetHostName()).AddressList;

		/// <summary>This machine's current IP.</summary>
		public string Ip { get; } = Dns.GetHostEntry(Dns.GetHostName()).AddressList[0].ToString();
		
		#endregion

		#region Methods

		/// <summary>Run a bash command. From https://loune.net/2017/06/running-shell-bash-commands-in-net-core/</summary>
		/// <param name="cmd">Command to run.</param>
		/// <returns>Command output.</returns>
		public static string Bash(string cmd)
		{
			var escapedArgs = cmd.Replace("\"", "\\\"");
        
			var process = new Process
			{
				StartInfo = new ProcessStartInfo
				{
					FileName = "/bin/bash",
					Arguments = $"-c \"{escapedArgs}\"",
					RedirectStandardOutput = true,
					UseShellExecute = false,
					CreateNoWindow = true,
				}
			};
			process.Start();
			string result = process.StandardOutput.ReadToEnd();
			process.WaitForExit();
			return result;
		}

		/// <summary>Clears any files leftover by the app single instance lock setup, that stops a second instance from running.</summary>
		/// <param name="binaryName">Name of the program binary.</param>
		public void ClearAppInstanceLock(string binaryName)
		{
			File.Delete(String.Format(ATNames.Instance.AppInstanceLock, binaryName));
		}
		

		public List<string> DecodeWebSocketMessage(string message)
		{
			List<string> components = new List<string>();

			for (int c = 1; c < message.Length; c++)
			{
				if (message[c] == ';' && message[c - 1] != '\\')
				{
					components.Add(UnescapeString(message.Substring(0, c)));
					message = message.Substring(c + 1);
					c = 0;
				}
			}

			if (message.Length > 0)
			{
				components.Add(message);
			}

			return components;
		}

		public string EncodeWebSocketMessage(List<string> components)
		{
			string result = "";
			foreach (var component in components)
			{
				result += EscapeString(component) + ";";
			}

			return result;
		}

		public string EscapeString(string input)
		{
			return input.Replace(";", "\\;");
		}

		public int GetOccurenceCount(string str, string search)
		{
			int n = 0;
			int count = 0;
			while ((n = str.IndexOf(search, n, StringComparison.Ordinal)) != -1)
			{
				n++;
				count++;
			}

			return count;
		}

		/// <summary>Detects whether another instance of the program is running.
		/// If not, it creates a lock for this instance.</summary>
		/// <param name="binaryName">Name of the program binary.</param>
		/// <returns>True if you are able to run this instance, false if another is already running.</returns>
		public bool TryAppInstanceLock(string binaryName)
		{
			string path = String.Format(ATNames.Instance.AppInstanceLock, binaryName);
			bool isOtherRunning = false;
			if (File.Exists(path))
			{
				string otherPid = "";
				using (StreamReader reader = new StreamReader(path, Encoding.ASCII))
				{
					otherPid = reader.ReadToEnd();
				}
				RunCommand shell = new RunCommand ();
				shell.RunExeCommand ("ps", "-p " + otherPid, true);
				isOtherRunning = shell.ExitCode == 0;
			}

			if (isOtherRunning)
			{
				Console.WriteLine("               #%%                                                              ");
				Console.WriteLine("              %#&#%                                             %%####,         ");
				Console.WriteLine("              ,%%%%#                                            %#%%%%,         ");
				Console.WriteLine("           %%#%##%%#                                            *##%%##         ");
				Console.WriteLine("         ######%%#####,                                         &#######%%%     ");
				Console.WriteLine("         %%&%%#%%##%#####%%%###                               %#%##%#%%#%%%%#/  ");
				Console.WriteLine("         ###############   ,%*                &%%&&%        %%######%%####%###  ");
				Console.WriteLine("          &########, *%%%%%%&%%                 *%%%%%&%%###(##%(#####%#%#%%##% ");
				Console.WriteLine("          ,#######/                                              %#########(###%");
				Console.WriteLine("         &#########                                               *#######%%%%#.");
				Console.WriteLine("        /#####%#####(                                              %%&%#####    ");
				Console.WriteLine("       ,#####& *#####&                                           .##########&   ");
				Console.WriteLine("       %###%      &###%                                        .#############   ");
				Console.WriteLine("      .###(         (###                                      %#######&#####    ");
				Console.WriteLine("     (##%           *%##,                                   /#######  %###%     ");
				Console.WriteLine("    #%%%#            ##%%                                  &###%*     ###%      ");
				Console.WriteLine("    #&#%              %#%                                 ,&##%       #%##      ");
				Console.WriteLine("   %&%                /%%#                                 ####%       %%&%.    ");
				Console.WriteLine("  %%%                    &%%%                              ##%##*      %%%%%    ");
				Console.WriteLine("*#%%(                                                       %###        %%%&    ");
				
			}
			else
			{
				using (StreamWriter writer = new StreamWriter(path))
				{
					writer.Write(Process.GetCurrentProcess().Id);
				}
			}
			
			return !isOtherRunning;
		}

		/// <summary>Check if a given IP address matches localhost.</summary>
		/// <returns><c>true</c> if IP is localhost; otherwise, <c>false</c>.</returns>
		/// <param name="addr">IP Address.</param>
		public bool IsLocalhost (string addr)
		{
			if (addr == Ip) return true;
			if (addr == "localhost") return true;
			if (addr == "127.0.0.1") return true;
			foreach (var ip in currentAddresses)
			{
				if (ip.AddressFamily == AddressFamily.InterNetwork)
				{
					if (ip.ToString () == addr)
					{
						return true;
					}
				}
			}
			return false;
		}

		/// <summary>Check if a given IP address is valid</summary>
		/// <returns><c>true</c> if IP is in a valid format; otherwise, <c>false</c>.</returns>
		/// <param name="addr">IP Address.</param>
		public bool IsValidIP (string addr)
		{
			if (string.IsNullOrEmpty (addr))
			{
				return false;
			}
			if (addr == "localhost")
			{
				return true;
			}

			return Regex.Match (addr, "[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}").Success;
		}

		
		/// <summary>Checks whether two IPs match.</summary>
		/// <param name="ip1">First IP.</param>
		/// <param name="ip2">Second IP.</param>
		/// <returns>Whether they match.</returns>
		public bool IpsMatch(string ip1, string ip2)
		{
			if (IsLocalhost(ip1) && IsLocalhost(ip2))
			{
				return true;
			}

			return ip1 == ip2;
		}

		/// <summary>Returns whether the given ports pair up with each other.</summary>
		/// <returns><c>true</c> if ports pair up; otherwise, <c>false</c>.</returns>
		/// <param name="port1">First port.</param>
		/// <param name="port2">Second port.</param>
		public bool IsPortPair (string port1, string port2)
		{
			if (port1.StartsWith("/dev/tnt") && port2.StartsWith("/dev/tnt"))
			{
				int nr1 = int.Parse(port1.Substring(8));
				int nr2 = int.Parse(port2.Substring(8));
				if (nr1 % 2 == 0)
				{
					return nr2 == nr1 + 1;
				}
				else
				{
					return nr2 == nr1 - 1;
				}
			}
			else
			{
				return port1 == port2;
			}
		}

		/// <summary>Gets the identifier (Physical Address) from Network Interface.</summary>
		/// <returns>The identifier from Network Interface. If none is found returns <c>-1</c></returns>
		public int GetIdFromNetWorkInterface ()
		{
			foreach (NetworkInterface iface in NetworkInterface.GetAllNetworkInterfaces ())
			{
				if (iface.NetworkInterfaceType == NetworkInterfaceType.Ethernet)
				{
					string temp = iface.GetPhysicalAddress ().ToString ().Substring (6, 6);
					temp = temp.Substring (4, 2) + temp.Substring (2, 2) + temp.Substring (0, 2);
					return Convert.ToInt32 (temp, 16);
				}
			}
			return -1;
		}

		/// <summary>Gets the IP from Network Interface.</summary>
		/// <returns>The IP from Network Interface. If none is found returns <c>-1</c></returns>
		public string GetIPFromNetWorkInterface ()
		{
			foreach (NetworkInterface iface in NetworkInterface.GetAllNetworkInterfaces ())
			{
				if (iface.NetworkInterfaceType == NetworkInterfaceType.Ethernet || iface.NetworkInterfaceType == NetworkInterfaceType.Wireless80211)
				{
					foreach (UnicastIPAddressInformation ip in iface.GetIPProperties ().UnicastAddresses)
					{
						if (ip.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
						{
							return ip.Address.ToString ();
						}
					}
				}
			}
			return "-1";
		}

		/// <summary>Returns a line in the specified file that contains the specified text.
		/// This is useful in order to obtain, for instance, a specific configuration
		/// in a configuration file.</summary>
		/// <returns>The full matched line.</returns>
		/// <param name="path">Path to the file to open.</param>
		/// <param name="match">String to match the line with.</param>
		/// <param name="afterLine">Only return lines that come after this line number.</param>
		/// <param name="lineNr">Number of the line that was returned.</param>
		public string GetLineInFile (string path, string match, int afterLine, out int lineNr)
		{
			lineNr = 0;
			try
			{
				using (StreamReader reader = new StreamReader (path, System.Text.Encoding.UTF8, true, 128))
				{
					string lineStr = reader.ReadLine ();
					while (lineStr != null)
					{
						lineNr++;
						if (lineNr > afterLine && lineStr.Contains (match))
						{
							return lineStr;
						}
						lineStr = reader.ReadLine ();
					}
				}
			}
			catch
			{
				Logger.Instance.UpdateLog ("Could not read file " + path + ".", LoggerType.Console, true);
			}
			return "-";
		}

		/// <summary>Returns a line in the specified file that contains the specified text.
		/// This is useful in order to obtain, for instance, a specific configuration
		/// in a configuration file.</summary>
		/// <returns>The full matched line, or "-" if not found.</returns>
		/// <param name="path">Path to the file to open.</param>
		/// <param name="match">String to match the line with.</param>
		public string GetLineInFile (string path, string match)
		{
			return GetLineInFile (path, match, 0, out _);
		}

		/// <summary>Converts an ASCII string to a hex representation.</summary>
		/// <returns>The hex representation.</returns>
		/// <param name="str">String to convert.</param>
		public string StringToHex (string str)
		{
			if (str.Length == 0) return "";

			char[] charValues = str.ToCharArray ();
			string hexOutput = "";
			foreach (char c in charValues)
			{
				hexOutput += String.Format ("{0:X} ", Convert.ToInt32 (c));
			}
			hexOutput = hexOutput.Substring (0, hexOutput.Length - 1);

			return hexOutput;
		}

		/// <summary>Returns a string representing how many minutes, hours, or days ago the specified date was.</summary>
		/// <returns>The string representation. It does not include the "ago" part, and the word for minutes, hours, or days is just the first letter.Returns "[unknown]" on error.</returns>
		/// <param name="dt">Date to use.</param>
		public string GetTimeAgo (DateTime dt)
		{
			TimeSpan? diff = DateTime.Now - dt;
			string agoString = "[unknown]";
			if (diff != null)
			{
				if (diff.Value.TotalDays > 30)
				{
					agoString = "months";
				}
				else if (diff.Value.TotalHours > 24)
				{
					agoString = Math.Round (diff.Value.TotalDays) + "d";
				}
				else if (diff.Value.TotalMinutes > 60)
				{
					agoString = Math.Round (diff.Value.TotalHours) + "h";
				}
				else
				{
					agoString = Math.Round (diff.Value.TotalMinutes) + "m";
				}
			}
			return agoString;
		}

		/// <summary>Zips several files on disk into a zip in memory, and returns a byte array representing the zip.</summary>
		/// <returns>Bytes representing the zip.</returns>
		/// <param name="files">Names of the files to zip.</param>
		public byte[] ZipFiles (string[] files)
		{
			byte[] zipBytes;
			using (MemoryStream ms = new MemoryStream ())
			{
				using (ZipArchive zipArchive = new ZipArchive (ms, ZipArchiveMode.Create, true))
				{
					foreach (string f in files)
					{
						ZipArchiveEntry entry = zipArchive.CreateEntry (f);
						using (Stream entryStream = entry.Open ())
						{
							byte[] fileBytes = File.ReadAllBytes (f);
							entryStream.Write (fileBytes, 0, fileBytes.Length);
						}
					}
				}

				zipBytes = ms.ToArray ();
			}
			return zipBytes;
		}

		public string UnescapeString(string input)
		{
			return input.Replace("\\;", ";");
		}

		/// <summary>Unzips a zip in memory, extracting the files inside to disk.</summary>
		/// <param name="zipBytes">Bytes representing the zip.</param>
		/// <param name="destination">Destination folder for the extracted files.</param>
		public void UnzipFiles (string origin, string destination)
		{
			FastZip fastZip = new FastZip();

			// Will always overwrite if target filenames already exist
			fastZip.ExtractZip(origin, destination, null);
		}
		#endregion
	}
}

