using System;
using System.Collections.Generic;
using System.IO;
using AutoTestingService.Logging;
using LibGit2Sharp;

namespace AutoTestingService
{
    public class GitHandler
    {
        
        private List<string> PathList;
        private string GitRepository;
        private string CommitID;
        private string CurrentSessionFolderPath = String.Empty;
        private bool fileFound = false;
        
        public GitHandler (string gitRepository, List<string> pathList, string commitID)
        {
            PathList = pathList;
            GitRepository = gitRepository;
            CommitID = commitID;
        }

        public Dictionary<string, string> GitFilesDict = new Dictionary<string, string>();
        
        private void IterateGitRepository(IRepository GitRepository, string path, Tree tree, string targetFile)
        {
            //TODO
            //resultado da operação por retorno. null if failure, blob if ok
            //Entrada do ficheiro alvo por parametro
            //validações extra?? ver se é preciso
            
            foreach (var treeEntry in tree)
            {
                if (fileFound)
                    return;
                var treePath = path + treeEntry.Name;
                var gitObject = treeEntry.Target;

                var meta = GitRepository.ObjectDatabase.RetrieveObjectMetadata(gitObject.Id);
                // Console.WriteLine("{0}\t{1}\t{2}\t{3}\t{4}", gitObject.Id, treeEntry.Mode, treeEntry.TargetType, meta.Size, treePath);
				
                if (treePath.ToString() == targetFile)
                {
					// string fileOutput = ((((Blob)gitObject).GetContentText()));
                    fileFound = true;
                    GitFilesDict.Add(treePath, ((Blob)gitObject).GetContentText());
                    return;
                }

                if (treeEntry.TargetType == TreeEntryTargetType.Tree && !fileFound)
                {
                    IterateGitRepository(GitRepository, treePath + "/", (Tree)gitObject, targetFile);
                }

                if (treeEntry.TargetType == TreeEntryTargetType.Blob)
                {
//					Console.WriteLine((((Blob)gitObject).GetContentText()));
                }
            }

        }

        public void GitHandleFile(string path)
        {
                using (var repo = new Repository(GitRepository))
                {
                    // var headBranch = repo.Head;
                    var tip = repo.Head.Tip;

                    var treeEntry = tip[path];
                    if (treeEntry == null)
                    {
                        Logger.Instance.UpdateLog ("Invalid git tree.", LoggerType.Warning);
                    }
                    IterateGitRepository(repo, "", tip.Tree, path);
                }
        }

        public void GitHandleDirectory(string directoryPath)
        {
            foreach (var file in Directory.EnumerateFiles(GitRepository + directoryPath))
            {
                GitHandleFile(directoryPath + "/" + Path.GetFileName(file));
                fileFound = false;
            }
        }

        public Dictionary<string, string> GitHandle()
        {
            foreach (var file in PathList)
            if (!file.EndsWith(".js") ) 
                GitHandleDirectory(file);
            else
            { 
                GitHandleFile(file);
            }
            return GitFilesDict;
        }
        
    }
}