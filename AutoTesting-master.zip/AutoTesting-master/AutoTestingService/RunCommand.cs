﻿using System;
using System.IO;
using System.Text;
using System.Threading;
using System.Diagnostics;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace AutoTestingService
{
	/// <summary>Run Command class.</summary>
	/// <description>Class in which commands can be executed through a System Process.</description>
	public class RunCommand
	{
		#region Variables

		/// <summary>The output.</summary>
		public string Output;

		/// <summary>The error.</summary>
		public string Error;

		/// <summary>The exit code.</summary>
		public int ExitCode;

		#endregion

		#region Methods
		
		/// <summary>Executes a command.</summary>
		/// <returns>Returns null on error. If waiting for the command to finish, this returns the exit code. Otherwise, returns 0.</returns>
		/// <param name="cmd">Command to execute.</param>
		/// <param name="args">Command arguments.</param>
		/// <param name="wait">If true, waits until the command finishes before continuing execution.</param>
		public int? RunExeCommand (string cmd, string args, bool wait)
		{
			if (cmd == null)
				return null;

			using (var process = new Process())
			{
				process.EnableRaisingEvents = false;
				process.StartInfo.UseShellExecute = false;
				process.StartInfo.CreateNoWindow = true;
				process.StartInfo.RedirectStandardOutput = true;
				process.StartInfo.RedirectStandardError = true;
				
				process.StartInfo.FileName = cmd;
				process.StartInfo.Arguments = args;

				if (!process.Start())
				{
					return null;
				}

				if (wait)
				{
					Output = process.StandardOutput.ReadToEnd ();
					Error = process.StandardError.ReadToEnd ();
					process.WaitForExit ();
					ExitCode = process.ExitCode;
					process.Close();
					return ExitCode;
				}
				else
				{
					process.Close();
					return 0;
				}
			}
		}

		#endregion
	}
}

