﻿using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Collections.Generic;

using AutoTestingService.Shared;

namespace AutoTestingService.Logging
{
	/// <summary>Logger Message Type.</summary>
	public enum LoggerType : int
	{
		/// <summary>Console only.</summary>
		Console,
		/// <summary>Debug.</summary>
		Debug,
		/// <summary>Develop.</summary>
		Develop,
		/// <summary>General information.</summary>
		Info,
		/// <summary>Error.</summary>
		Error,
		/// <summary>Warning.</summary>
		Warning
	}

	/// <summary>Logger class.</summary>
	/// <description>>Where the Logging is managed.</description>
	public class Logger
	{
		#region Singleton

		public static Logger Instance { get; } = new Logger ();

		private Logger ()
		{
		}

		#endregion

		#region Variables

		/// <summary>Path to the Server log file.</summary>
		public string _logfile { get; private set; }

		#endregion


		#region Methods

		/// <summary>Saves a Backup of the Log file.</summary>
		/// <param name="file">Path to the Log file.</param>
		public void Initialize (string file)
		{
			_logfile = file;
			string logs_folder = ATNames.Instance.FolderLogs;
			if (!Directory.Exists (logs_folder))
			{
				try
				{
					Directory.CreateDirectory (logs_folder);
				}
				catch
				{
					return;
				}
			}
		}

		/// <summary>Outputs the message.</summary>
		/// <returns> The message.</returns>
		/// <param name='text'> Message text.</param>
		/// <param name='type'>Message type.</param>
		private string outputMessage (string text, LoggerType type)
		{
			return string.Format ("[{0}][{1}] {2}", DateTime.Now.ToString ("yyyy/MM/dd HH:mm:ss"), padBoth (type.ToString (), 7), text);
		}

		/// <summary>Add padding to both sides of the text.</summary>
		/// <returns>Padded result.</returns>
		/// <param name="source">Text to pad.</param>
		/// <param name="length">Length to pad.</param>
		private string padBoth (string source, int length)
		{
			int spaces = length - source.Length;
			int padLeft = spaces / 2 + source.Length;
			return source.PadLeft (padLeft).PadRight (length);
		}

		/// <summary> Writes the file.</summary>
		/// <param name='pathFile'>Path of the File.</param>
		/// <param name='message'> Message to write.</param>
		private void writeFile (string pathFile, string message)
		{
			try
			{
				StreamWriter file = File.AppendText (pathFile);
				file.WriteLine (message);
				file.Close ();
			}
			catch
			{
				return;
			}
		}

		/// <summary>Writes log message in file.</summary>
		/// <param name="message">Message to log.</param>
		/// <param name="type">Type of message. </param>
		private void writeLogInFile (string message, LoggerType type = LoggerType.Info)
		{
			if (type < LoggerType.Develop)
			{   //TODO Configurable?
				return;
			}

			if (!string.IsNullOrEmpty (_logfile))
			{
				writeFile (_logfile, outputMessage (message, type));
			}
		}

		/// <summary>Writes log message in the console.</summary>
		/// <param name="message">Message to log.</param>
		/// <param name="type">Type of message. </param>
		/// <param name="compactConsole">If set to <c>true</c> compact console output.</param>
		private void writeLogInConsole (string message, LoggerType type, bool compactConsole)
		{
			string text = message;
			if (type != LoggerType.Console)
			{
				text = String.Format ("[{0}] {1}", type.ToString (), message);
			}

			switch (type)
			{
			case LoggerType.Error:
				Console.ForegroundColor = ConsoleColor.DarkRed;
				break;
			case LoggerType.Warning:
				Console.ForegroundColor = ConsoleColor.DarkMagenta;
				break;
			case LoggerType.Info:
				Console.ForegroundColor = ConsoleColor.DarkGreen;
				break;
			case LoggerType.Debug:
				Console.ForegroundColor = ConsoleColor.DarkYellow;
				break;
			case LoggerType.Develop:
				Console.ForegroundColor = ConsoleColor.White;
				break;
			default:
				Console.ResetColor ();
				break;
			}

			if (!compactConsole)
			{
				text += "\n";
			}

			Console.WriteLine (text);
			Console.ResetColor ();
		}

		/// <summary>Updates the log file if it exists and prints the message to the console.</summary>
		/// <param name="message">Message to log.</param>
		/// <param name="type">Type of message. By default LoggerType.Info.</param>
		/// <param name="compactConsole">If set to <c>true</c> compact console output. By default <c>false</c>.</param>
		public void UpdateLog (string message, LoggerType type = LoggerType.Info, bool compactConsole = false)
		{
			writeLogInFile (message, type);
			writeLogInConsole (message, type, compactConsole);
		}

		/// <summary>Delete a file.</summary>
		/// <param name="pathFile">Path to the file.</param>
		public void Clean (string pathFile)
		{
			try
			{
				File.Delete (pathFile);
			}
			catch
			{
			}
		}

		#endregion
	}
}

