﻿using System;
using System.Collections.Generic;
using AutoTestingService.Configuration.EGMConfig;

namespace AutoTestingService.Machine
{
	public abstract class MachineController
	{
		public abstract bool IsReady ();

		public abstract void BlockIP (string ip);
		public abstract void ChangeGame (int galleryGameNumber);
		public abstract void ClearNVs ();
		public abstract void DoInputs (string inputs, int times);
		public abstract void PressButton (string inputs);
		public abstract void DoTouch (int x, int y);
		public abstract void FixMD5 ();
		public abstract void ForceBalls (string balls);
		public abstract void ForceCards (string cards);
		public abstract MachineConfiguration GetConfig ();
		public abstract string GetIp ();
		public abstract int GetSessionIdx ();
		public abstract void InsertCredits ();
		public abstract void RestartCashcode ();
		public abstract void InsertBill (int value);
		public abstract void InsertCard (string number);
		public abstract void InsertTicket (string validation_code);
		public abstract void LoadAusyConfig();
		public abstract void LoadEGMConfig ();
		public abstract void RebootMachine ();
		public abstract void RemoveCredits ();
		public abstract void RemoveTimer (string name);
		public abstract void RestartGame ();
		public abstract void SaveAusyConfig(Configuration.AusyConfig.AusyConfiguration config);
		public abstract void SaveEGMConfig (EGMConfig config);
		public abstract void SetInterval (string name, int milliseconds, string code);
		public abstract void SetTimeout (string name, int milliseconds, string code);
		public abstract void SetVLT (int vlt, int password);
		public abstract void TakeScreenshot (int x1, int y1, int x2, int y2, string path);
		public abstract void UnblockIP (string ip);
		//Compare images requer a biblioteca OpenimageIO Tools
		//Para instalar correr sudo apt-get install -y openimageio-tools
		public abstract bool CompareImages (string image1, string image2, int failPercentage);
		public abstract void StartAFTCashIn(Dictionary<string, object> cashInInfo);
		public abstract void StartAFTCashOut();
		public abstract void SendSASLP(int lpNumber, Dictionary<string, object> lpInfo, string lpVersion = "");
		public abstract void SendSASByteArray(byte[] bytes);

		public abstract void GetSASMeter(int meterNumber);


	}
}
