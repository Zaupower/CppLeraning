﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net.NetworkInformation;

using AutoTestingService.Shared;

namespace AutoTestingService
{
	/// <summary>Machine Configuration class.</summary>
	/// <description>Stores the information about a Machine configuration. Like the ID, IP, Distro, etc.</description>
	[Serializable]
	public class MachineConfiguration
	{
		/// <summary>Gets or sets the ID number.</summary>
		public int Id { get; set; }

		/// <summary>Gets or sets the Network IP Address.</summary>
		public string Ip { get; set; }

		/// <summary>Gets or sets the current game's name.</summary>
		public string GameName { get; set; }

		/// <summary>Gets or sets the operative system's distribution version.</summary>
		public string Distro { get; set; }

		/// <summary>Gets or sets the currently configured country ID number.</summary>
		public int Country { get; set; }

		/// <summary>Gets or sets the currently configured cash system ID number.</summary>
		public int CashSystem { get; set; }

		/// <summary>Gets or sets the currently configured game server IP address.</summary>
		public string GameServerIP { get; set; }
	}

	#region Enums

	/// <summary>Types of Log.</summary>
	public enum LogType : int
	{
		/// <summary>Bingo game.</summary>
		Bingo = 0,
		/// <summary>Slots game.</summary>
		Slots = Bingo + 1,
	}

	/// <summary>Insert bill errors. </summary>
	public enum InsertBillError : int
	{
		/// <summary>No error.</summary>
		None = 0,
		/// <summary>No communication.</summary>
		NoCommunication = 1,
		/// <summary>Unsupported bill value.</summary>
		UnsupportedBill = 2,
		/// <summary>Stacker full.</summary>
		StackerFull = 3,
		/// <summary>Bill jammed.</summary>
		BillJammed = 4,
		/// <summary>Bill rejected because the acceptor is not a state that can accept.</summary>
		BillRejectedBadState = 5,
		/// <summary>Bill rejected for some reason.</summary>
		BillRejected = 6,
		/// <summary>There is no available bill acceptor driver.</summary>
		NoDriver = 7,
	}

	/// <summary>Insert ticket errors. </summary>
	public enum InsertTicketError : int
	{
		/// <summary>No error.</summary>
		None = 0,
		/// <summary>No communication.</summary>
		NoCommunication = 1,
		/// <summary>Unsupported ticket code.</summary>
		UnsupportedTicket = 2,
		/// <summary>Stacker full.</summary>
		StackerFull = 3,
		/// <summary>Ticket jammed.</summary>
		TicketJammed = 4,
		/// <summary>Ticket rejected for some reason.</summary>
		TicketRejected = 5,
		/// <summary>There is no available bill acceptor driver.</summary>
		NoDriver = 6,
	}

	/// <summary>Insert card errors. </summary>
	public enum InsertCardError : int
	{
		/// <summary>No error.</summary>
		None = 0,
		/// <summary>Card already inside.</summary>
		CardAlreadyInside = 1,
		/// <summary>No communication.</summary>
		NoCommunication = 2,
		/// <summary>There is no available card reader driver.</summary>
		NoDriver = 3,
	}

	/// <summary>Remove card errors.</summary>
	public enum RemoveCardError : int
	{
		/// <summary>No error.</summary>
		None = 0,
		/// <summary>No card inside.</summary>
		NoCardInside = 1,
		/// <summary>No communication.</summary>
		NoCommunication = 2,
		/// <summary>There is no available card reader driver.</summary>
		NoDriver = 3,
	}

	/// <summary>Cash systems.</summary>
	public enum CashSystem : int
	{
		/// <summary>Ticket in ticket out.</summary>
		TITO = 3,
		/// <summary>Server to server (Alesis).</summary>
		S2S = 2,
		/// <summary>Slot Accounting System.</summary>
		SAS = 0,
		/// <summary>Norwegian cash system.</summary>
		FBMPIN = 4,
		/// <summary>No cash system.</summary>
		NONE = 99
	}

	public enum Peripheral : int
	{
		/// <summary>Card reader.</summary>
		CardReader = 0,
		/// <summary>Bill acceptor.</summary>
		BillAcceptor = 1,
	}

	/// <summary>Card reader drivers.</summary>
	public enum CardReaderDriver : int
	{
		Magtek = 0,
		XST = 1,
	}

	#endregion
}

