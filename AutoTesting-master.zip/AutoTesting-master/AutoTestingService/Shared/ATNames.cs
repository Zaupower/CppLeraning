﻿using System.Collections.Generic;
using System.IO;

namespace AutoTestingService.Shared
{
	/// <summary>Auto Testing names class.</summary>
	/// <description>>Class which has the definition of relevant names.</description>
	public class ATNames
	{
		#region Singleton

		public static ATNames Instance { get; } = new ATNames ();

		private ATNames ()
		{
			PathLogs = Path.Combine (PathHome, FolderLogs);
			ServerLogFile = Path.Combine (FolderLogs, LogATServer);
			ClientLogFile = Path.Combine (FolderLogs, LogATClient);
			LogFilePath = Path.Combine (FolderLogs, LogFileName);
			ServerUriFormatForClients = "ws://{0}:" + ServerPort + "/" + ServerPathForClients;
			ClientLookoutUriFormatForServers = "ws://{0}:" + ClientLookoutPort + "/" + ClientLookoutPathForServers;
		}

		#endregion

		// Files
		/// <summary>File for Configuration.</summary>
		public readonly string FileForConfig = "config.json";
		/// <summary>AT Server log file. </summary>
		public readonly string LogATServer = "ATServer {0}.log";
		/// <summary>AT Client log file. </summary>
		public readonly string LogATClient = "ATClient {0}.log";
		/// <summary>Log file name. </summary>
		public readonly string LogFileName = "AuSy {0}.log";
		/// <summary>App instance lock file path.</summary>
		public readonly string AppInstanceLock = "/tmp/{0}.pid";
		/// <summary>File with buttons map for bingo</summary>
		public readonly string ButtonsBingo = "gameData/buttonsBingo.json";
		/// <summary>File with buttons map for slots</summary>
		public readonly string ButtonsSlots = "gameData/buttonsSlots.json";
		/// <summary>Relative path (with origin in the game root directory) to file with game log configurations.</summary>
		public readonly string logmanagerFilePath = "common/.config/logmanager.cfg";

		// Folders
		/// <summary>Folder to store the Logs.</summary>
		public readonly string FolderLogs = "logs";
		/// <summary>Folder to store the script logs.</summary>
		public readonly string FolderScriptLogs = "script_logs";
		/// <summary>Folder to store the test suite results.</summary>
		public string FolderTestResults = "test_results";
		/// <summary>Folder to store scripts in the game's folder.</summary>
		public readonly string FolderGameFolderScripts = "ausy_scripts";
		/// <summary>Folder to store JS files to include.</summary>
		public readonly string FolderIncludes = "includes";

		// Patterns
		/// <summary>DateTime pattern to</summary>
		public readonly string DateTimePattern = "yyyy-MM-dd_HH-mm-ss";

		// Paths
		/// <summary>Folder where the executable is located. </summary>
		public readonly string PathHome = Path.GetDirectoryName (System.Reflection.Assembly.GetExecutingAssembly ().Location);
		/// <summary>Full path to the Logs folder.</summary>
		public readonly string PathLogs;
		/// <summary>Full path to the Server Log file.</summary>
		public string ServerLogFile;
		/// <summary>Full path to the Client Log file.</summary>
		public string ClientLogFile;
		/// <summary>Full path to the Log file.</summary>
		public string LogFilePath;

		/// <summary>Server Port.</summary>
        public int ServerPort = 4649;
        /// <summary>Client Port.</summary>
        public int ClientLookoutPort = 4650;
		/// <summary>WebSocket path that clients should connect to.</summary>
        public string ServerPathForClients = "Client";
        /// <summary>WebSocket path that servers should connect to.</summary>
        public string ClientLookoutPathForServers = "Lookout";
        /// <summary>URI format that clients should connect to.</summary>
		public string ServerUriFormatForClients = "";
		/// <summary>URI format that servers should connect to.</summary>
		public string ClientLookoutUriFormatForServers = "";

		// Other
		/// <summary>Default session index.</summary>
		public readonly int DefaultSessionIdx = 1;
		/// <summary>Location and name of temporary zip files, sent between applications.</summary>
		public readonly string TempZipLocation = "/tmp/tmp_ausy.zip";
		
		public readonly Dictionary<string, string> SUPERVISOR_BUTTONS = new Dictionary<string, string> ()
		{
			{"bt_conta", "62 412"},
			{"bt_counters", "326 412"},
			{"bt_histo", "591 412"},
			{"bt_teste", "856 412"},
			{"bt_confi", "1121 412"},
			{"bt_out_m", "1386 412"},
			{"bt__reboot", "69 918"},
			{"bt__shutdown", "220 918"},
			{"bt__exit", "1499 948"},
			{"bt__accprint", "20 700"},
			{"bt_billin", "75 382"},
			{"bt_cash", "295 382"},
			{"bt_ticket", "513 382"},
			{"bt_jackp", "952 382"},
			{"bt__game", "732 382"},
			{"bt_myste", "1388 382"},
			{"bt_event", "1169 382"},
			{"bt_cash_in", "1502 368"},
			{"bt_cash_out", "1502 537"},
			{"bt_ticket_in", "1502 368"},
			{"bt_ticket_out", "1502 537"},
			{"bt__reprint", "1502 818"},
			{"z_bonus_botao_down_leit", "101 798"},
			{"z_bonus_botao_up_leit", "1451 798"},
			{"bt_current_mystery", "1500 450"},
			{"bt_touch", "456 410"},
			{"bt_t_vol", "728 410"},
			{"bt_bt_la", "1000 410"},
			{"bt_test_mode", "1121 410"},
			{"bt__calibrate", "0 863"},
			{"bt_c_lef", "443 190"},
			{"bt_c_rig", "992 190"},
			{"bt_woofe", "718 190"},
			{"volume_bar_master", "589 513"},
			{"bt_master_less", "448 458"},
			{"bt_master_more", "1096 458"},
			{"volume_bar", "589 662"},
			{"bt_less", "448 715"},
			{"bt_play", "1096 715"},
			{"bt_more", "556 715"},
			{"bt_less_vol", "448 607"},
			{"bt_more_vol", "1096 607"},
			{"bt_t_dsp", "718 243"},
			{"bt_l_red", "443 515"},
			{"bt_l_grn", "718 515"},
			{"bt_l_yel", "992 515"},
			{"bt_set_c", "164 704"},
			{"bt_set_g", "452 704"},
			{"bt_change_sign", "1483 877"},
			{"bt_n_vlt", "48 353"},
			{"bt_local", "316 353"},
			{"bt_sas_n", "583 353"},
			{"bt_jackpot_mystery", "851 602"},
			{"bt_onoff_m", "851 602"},
			{"bt_atrackedmode", "1118 353"},
			{"bt_onoff_a", "1118 353"},
			{"bt_autoplay", "1385 353"},
			{"bt_onoff_auto", "1385 353"},
			{"bt_standbypromo", "48 600"},
			{"bt_onoff_promo", "48 600"},
			{"bt_switch_classic", "317 602"},
			{"bt_switch_quick", "583 602"},
			{"bt_switch_popup_quick", "1118 602"},
			{"bt_onoff_classic", "317 602"},
			{"bt_onoff_quick", "583 602"},
			{"bt_onoff_popup_quick", "1118 602"},
			{"bt_opened_cards", "851 353"},
			{"bt_l_cre", "43 353"},
			{"bt_tick", "311 353"},
			{"bt_prize", "578 353"},
			{"bt_cashincashout", "846 353"},
			{"bt_allow_restricted", "1114 353"},
			{"bt_onoff_b", "1114 353"},
			{"bt_allow_legacy", "1382 353"},
			{"bt_onoff_c", "1382 353"},
			{"bt_min_bet", "48 650"},
			{"bt_only_bank_currency", "1382 650"},
			{"bt_onoff_d", "1382 650"},
			{"title_calc_data", "194  20"},
			{"bt_cal_01", "971 256"},
			{"bt_cal_02", "1103 256"},
			{"bt_cal_03", "1235 256"},
			{"bt_cal_04", "971 390"},
			{"bt_cal_05", "1103 390"},
			{"bt_cal_06", "1235 390"},
			{"bt_cal_07", "971 522"},
			{"bt_cal_08", "1103 522"},
			{"bt_cal_09", "1235 522"},
			{"bt_cal_00", "971 655"},
			{"bt_cal_cl", "1105 655"},
			{"bt_cal_ac", "1105 787"},
			{"bt_cal_bs", "971 787"},
			{"bt_e_dra", "220 400"},
			{"bt_n_cre", "468 400"},
			{"bt_n_pay", "719 400"},
			{"bt_p_vid", "968 400"},
			{"bt_oth_p", "1217 400"},
		};
	}
}

