﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using AutoTestingService.Configuration.AusyConfig;
using AutoTestingService.Configuration.EGMConfig;
using AutoTestingService.Logging;
using AutoTestingService.Shared;
using Newtonsoft.Json;

namespace AutoTestingService.Configuration
{
	public class ConfigsManager
	{
		#region Fields

		public AusyConfiguration AusyConfig { get; private set; }

		public EGMConfig.EGMConfig EgmConfig { get; private set; }

		private const string _presetsConfPath = "/core/config/presets.conf";

		#endregion
		
		#region Singleton

		public static ConfigsManager Instance { get; } = new ConfigsManager ();

		private ConfigsManager ()
		{
			EventHandler.Instance.AddCallback("JsLoadAusyConfig", (s, i) => JsLoadAusyConfig(i != null ? i.Value.originIp : "localhost"));
			EventHandler.Instance.AddCallback("JsSaveAusyConfig", (s, i) => JsSaveAusyConfig(s, i != null ? i.Value.originIp : "localhost"));
			EventHandler.Instance.AddCallback("JsLoadEGMConfig", (s, i) => JsLoadEGMConfig(i != null ? i.Value.originIp : "localhost"));
			EventHandler.Instance.AddCallback("JsSaveEGMConfig", (s, i) => JsSaveEGMConfig(s, i != null ? i.Value.originIp : "localhost"));
		}

		#endregion
		
		#region Methods

		/// <summary>Loads Ausy config.</summary>
		/// <param name="config">Config object to load into.</param>
		/// <param name="createFileIfNotFound">create Ausy config file if it doesn't exist.</param>
		public void LoadAusyConfig (bool createFileIfNotFound = false)
		{
			string configJsonPath = ATNames.Instance.FileForConfig;
			AusyConfiguration config; 
			if (File.Exists (configJsonPath))
			{
				LoadFromAusyConfigJson (configJsonPath, out config);
			}
			else if (createFileIfNotFound)
			{
				Logger.Instance.UpdateLog("No Ausy config file found. Creating a new one...", LoggerType.Warning);
				config = new AusyConfiguration();
				using (StreamWriter fs = new StreamWriter(ATNames.Instance.FileForConfig))
				{
					fs.Write(JsonConvert.SerializeObject(config, Formatting.Indented));
				}
			}
			else
			{
				config = new AusyConfiguration();
				Logger.Instance.UpdateLog ("No Ausy config file found to load.", LoggerType.Warning);
			}

			AusyConfig = config;
		}

		/// <summary>Loads Ausy Config (from a JS request).</summary>
		/// <param name="requesterIp">Requester ip (could be the coordinator or the current machine)</param>
		public void JsLoadAusyConfig(string requesterIp)
		{
			LoadAusyConfig();
			string ausyConfigJson = JsonConvert.SerializeObject(AusyConfig);
			
			EventDistributor.Instance.Trigger("LoadedAusyConfig", ausyConfigJson, requesterIp);
		}

		/// <summary>Saves the Ausy's config object and file.</summary>
		/// <param name="config">Config object to save from.</param>
		public void SaveAusyConfig (AusyConfiguration config)
		{
			string configJsonPath =  ATNames.Instance.FileForConfig;
			if (File.Exists (configJsonPath))
			{
				SaveToAusyConfigJson (configJsonPath, config);
			}
			else
			{
				Logger.Instance.UpdateLog ("Save Ausy config failed! No config file to save to.");
			}
		}
		
		/// <summary>Saves Ausy Config (from a JS request). </summary>
		/// <param name="ausyConfig">Ausy config json</param>
		/// <param name="requesterIp">Requester ip (could be the coordinator or the current machine)</param>
		public void JsSaveAusyConfig(string ausyConfig, string requesterIp)
		{
			AusyConfiguration ausyConfigObj = JsonConvert.DeserializeObject<AusyConfiguration>(ausyConfig);
			SaveAusyConfig(ausyConfigObj);
			EventDistributor.Instance.Trigger("AusyConfigSaved", "", requesterIp);
		}
		
		/// <summary>Loads the game's config.</summary>
		/// <param name="config">Config object to load into.</param>
		public void LoadEGMConfig ()
		{
			EGMConfig.EGMConfig egmConfig = new EGMConfig.EGMConfig();
			string configJsonPath = AusyConfig.Game.GamePath + "/config.json";
			bool success = false;
			
			if (File.Exists (_presetsConfPath))
			{
				LoadFromPresetsConf (_presetsConfPath, egmConfig);
				success = true;
			}
			if (File.Exists (configJsonPath))
			{
				LoadFromConfigJson (configJsonPath, egmConfig);
				success = true;
			}
			
			if(!success)
			{
				Logger.Instance.UpdateLog ("Load EGM config failed! No config file to load from.");
			}

			EgmConfig = egmConfig;
		}

		/// <summary>Loads EGM config (from a JS request)</summary>
		/// <param name="requesterIp">Requester ip (could be the coordinator or the current machine)</param>
		public void JsLoadEGMConfig(string requesterIp)
		{
			LoadEGMConfig();
			string egmConfigJson = JsonConvert.SerializeObject(EgmConfig);
			
			EventDistributor.Instance.Trigger("LoadedEGMConfig", egmConfigJson, requesterIp);
		}
		
		/// <summary>Saves the game's config.</summary>
		/// <param name="config">Config object to save from.</param>
		public void SaveEGMConfig (EGMConfig.EGMConfig config)
		{
			string configJsonPath = AusyConfig.Game.GamePath + "/config.json";
			bool success = false;
			
			if (File.Exists (_presetsConfPath))
			{
				SaveToPresetsConf (_presetsConfPath, config);
				success = true;
			}
			if (File.Exists (configJsonPath))
			{
				SaveToConfigJson (configJsonPath, config);
				success = true;
			}
			
			if(!success)
			{
				Logger.Instance.UpdateLog ("Save EGM config failed! No config file to save to.");
			}
		}

		public void JsSaveEGMConfig(string EGMConfig, string requesterIp)
		{
			EGMConfig.EGMConfig egmConfigObj = JsonConvert.DeserializeObject<EGMConfig.EGMConfig>(EGMConfig);
			SaveEGMConfig(egmConfigObj);
			EventDistributor.Instance.Trigger("EGMConfigSaved", "", requesterIp);
		}

		/// <summary>Loads the EGM config from a presets.conf file.</summary>
		/// <param name="presetsConfPath">presets.conf path.</param>
		/// <param name="config">Config object to load into.</param>
		private void LoadFromPresetsConf (string presetsConfPath, EGMConfig.EGMConfig config)
		{
			List<string> lines = new List<string> (File.ReadAllLines (presetsConfPath));

			foreach (var p in config.GetType ().GetProperties ())
			{
				EGMConfigAttribute att = (EGMConfigAttribute) Attribute.GetCustomAttribute (p, typeof (EGMConfigAttribute));

				GetPropertyInPresetsConf (lines, att.presetsConfName, out int lineNr, out int valueStartPos, out int valueLength);

				if (lineNr == -1)
				{
					continue;
				}

				string valueStr = lines[lineNr].Substring (valueStartPos, valueLength);

				if (p.PropertyType == typeof (int?))
				{
					p.SetValue (config, int.Parse (valueStr));
				}
				else if (p.PropertyType == typeof (float?))
				{
					p.SetValue (config, float.Parse (valueStr));
				}
				else
				{
					p.SetValue (config, valueStr);
				}
			}
		}

		/// <summary>Loads the EGM config from a config.json file.</summary>
		/// <param name="configJsonPath">config.json path.</param>
		/// <param name="config">Config object to load into.</param>
		private void LoadFromAusyConfigJson (string configJsonPath, out AusyConfiguration config)
		{
			try
			{
				using (StreamReader fs = new StreamReader(configJsonPath))
				{
					config = JsonConvert.DeserializeObject<AusyConfiguration>(fs.ReadToEnd());
				}
			}
			catch (Exception ex)
			{
				config = new AusyConfiguration();
				Logger.Instance.UpdateLog("Failed to load Ausy config file: " + ex, LoggerType.Warning);
			}
		}

		/// <summary>Loads the EGM config from a config.json file.</summary>
		/// <param name="configJsonPath">config.json path.</param>
		/// <param name="config">Config object to load into.</param>
		private void LoadFromConfigJson (string configJsonPath, EGMConfig.EGMConfig config)
		{
			List<string> lines = new List<string> (File.ReadAllLines (configJsonPath));
			
			foreach (var p in config.GetType ().GetProperties ())
			{
				EGMConfigAttribute att = (EGMConfigAttribute) Attribute.GetCustomAttribute (p, typeof (EGMConfigAttribute));

				GetPropertyInConfigJson (lines, att.configJsonName, out int lineNr, out int valueStartPos, out int valueLength);

				if (lineNr == -1)
				{
					continue;
				}

				string valueStr = lines[lineNr].Substring (valueStartPos, valueLength);
				
				
				valueStr = valueStr.Split(',')[0]; //to remove unknown characters after the end of the property
				

				if (p.PropertyType == typeof (int?))
				{
					p.SetValue (config, int.Parse (valueStr));
				}
				else if (p.PropertyType == typeof (float?))
				{
					p.SetValue (config, float.Parse (valueStr));
				}
				else if (p.PropertyType == typeof (string))
				{
					if (valueStr[0] == '"')
					{
						valueStr = valueStr.Split('"')[1];
					}
					p.SetValue (config, valueStr);
				}
			}
		}


		/// <summary>Saves the EGM config to a presets.conf file.</summary>
		/// <param name="presetsConfPath">presets.conf path.</param>
		/// <param name="config">Config object to save from.</param>
		private void SaveToPresetsConf (string presetsConfPath, EGMConfig.EGMConfig config)
		{
			List<string> lines = new List<string> (File.ReadAllLines (presetsConfPath));

			foreach (var p in config.GetType ().GetProperties ())
			{
				EGMConfigAttribute att = (EGMConfigAttribute) Attribute.GetCustomAttribute (p, typeof (EGMConfigAttribute));

				ReplacePresetsConfProperty (lines, att.presetsConfName, p.GetValue (config).ToString ());
			}

			string countryId = "";
			switch (config.Country)
			{
			case "MX":
				countryId = "0";
				break;
			case "ES":
				countryId = "1";
				break;
			case "PH":
				countryId = "2";
				break;
			}
			ReplacePresetsConfProperty (lines, "VAR_COUNTRY", countryId);

			string layoutName = "";
			switch (config.CabinetLayout)
			{
			case 1:
				layoutName = "phantom";
				break;
			case 2:
			case 5:
				layoutName = "galaxy";
				break;
			case 3:
				layoutName = "shadow";
				break;
			case 4:
				layoutName = "phantomextreme";
				break;
			}
			ReplacePresetsConfProperty (lines, "VAR_LAYOUT_NAME", layoutName);

			ReplacePresetsConfProperty (lines, "VAR_GAMESERVER_REAL_IP", config.ServerIP);

			string cashSystemName = "";
			switch (config.CashSystem)
			{
			case 0:
				cashSystemName = "SAS";
				break;
			case 2:
				cashSystemName = "Alesis";
				break;
			case 3:
				cashSystemName = "FBM";
				break;
			}
			ReplacePresetsConfProperty (lines, "VAR_CASH_NAME", cashSystemName);


			File.WriteAllLines (presetsConfPath, lines);
		}


		private void SaveToAusyConfigJson (string configJsonPath, AusyConfiguration config)
		{
			using (StreamWriter fs = new StreamWriter(configJsonPath))
			{
				fs.Write(JsonConvert.SerializeObject(config, Formatting.Indented));
			}
		}
		
		/// <summary>Saves the EGM config to a config.json file.</summary>
		/// <param name="configJsonPath">config.json path.</param>
		/// <param name="config">Config object to save from.</param>
		private void SaveToConfigJson (string configJsonPath, EGMConfig.EGMConfig config)
		{
			List<string> lines = new List<string> (File.ReadAllLines (configJsonPath));

			foreach (var p in config.GetType ().GetProperties ())
			{
				EGMConfigAttribute att = (EGMConfigAttribute) Attribute.GetCustomAttribute (p, typeof (EGMConfigAttribute));

				GetPropertyInConfigJson (lines, att.configJsonName, out int lineNr, out int valueStartPos, out int valueLength);

				if (lineNr == -1)
				{
					continue;
				}

				string new_line = lines[lineNr].Substring (0, valueStartPos);
				if (p.PropertyType == typeof (string))
				{
					new_line += "\"" + p.GetValue (config) + "\"";
				}
				else
				{
					new_line += p.GetValue (config);
				}
				new_line += lines[lineNr].Substring (valueStartPos + valueLength);
				if(lines[lineNr].Split(',').Length>1)
				{
					new_line += ',';
				}
				lines[lineNr] = new_line;
			}

			File.WriteAllLines (configJsonPath, lines);
		}

		#endregion

		#region Auxiliary

		/// <summary>Replaces a value in a presets.conf list of lines.</summary>
		/// <param name="lines">List of lines.</param>
		/// <param name="property">Name of the property.</param>
		/// <param name="value">Value of the property.</param>
		private void ReplacePresetsConfProperty (List<string> lines, string property, string value)
		{
			GetPropertyInPresetsConf (lines, property, out int lineNr, out int valueStartPos, out int valueLength);

			if (lineNr == -1)
			{
				return;
			}

			string new_line = lines[lineNr].Substring (0, valueStartPos);
			new_line += value;
			new_line += lines[lineNr].Substring (valueStartPos + valueLength);
			lines[lineNr] = new_line;
		}


		/// <summary>Returns where a property is in a presets.conf file.</summary>
		/// <param name="lines">Lines that make up the file.</param>
		/// <param name="property">Property name.</param>
		/// <param name="lineNr">Line number of the property.</param>
		/// <param name="valueStartPos">Start position of the value of the property.</param>
		/// <param name="valueLength">Length of the value of the property.</param>
		private void GetPropertyInPresetsConf (List<string> lines, string property, out int lineNr, out int valueStartPos, out int valueLength)
		{
			for (int l = 0; l < lines.Count; l++)
			{
				Match m = Regex.Match (lines[l], "export " + property + " ?= ?(.+)");

				if (m.Success)
				{
					lineNr = l;
					valueStartPos = m.Groups[1].Captures[0].Index;
					valueLength = m.Groups[1].Captures[0].Length;

					return;
				}
			}

			lineNr = -1;
			valueStartPos = -1;
			valueLength = -1;
		}

		/// <summary>Returns where a property is in a config.json file.</summary>
		/// <param name="lines">Lines that make up the file.</param>
		/// <param name="property">Property name.</param>
		/// <param name="lineNr">Line number of the property.</param>
		/// <param name="valueStartPos">Start position of the value of the property.</param>
		/// <param name="valueLength">Length of the value of the property.</param>
		private void GetPropertyInConfigJson (List<string> lines, string property, out int lineNr, out int valueStartPos, out int valueLength)
		{
			string[] propParts = property.Split ('.');
			bool gotParent = false;

			for (int l = 0; l < lines.Count; l++)
			{
				if (!gotParent)
				{
					// Find parent object.
					Match m = Regex.Match (lines[l], "\"" + propParts[0] + "\" *:( *\\{|$)");

					if (m.Success)
					{
						gotParent = true;
					}
				}
				else
				{
					// Find the actual property.
					Match m = Regex.Match (lines[l], "\"" + propParts[1] + "\" *: *(.+)");

					if (m.Success)
					{
						lineNr = l;
						valueStartPos = m.Groups[1].Captures[0].Index;
						valueLength = m.Groups[1].Captures[0].Length;

						return;
					}
				}
			}

			lineNr = -1;
			valueStartPos = -1;
			valueLength = -1;
		}

		#endregion

		#region Logs

		public void SaveLatestAusyLog(string destinationFolder)
		{
			string ausyLogPath = Logger.Instance._logfile;
			string ausyLogFileName = Path.GetFileName(ausyLogPath);
			if (File.Exists(ausyLogPath))
			{
				File.Copy(ausyLogPath, destinationFolder + "/" + ausyLogFileName);
			}
		}

		#endregion
	}
}
