﻿using System;
using System.IO;
using AutoTestingService.Logging;
using AutoTestingService.Machine;
using AutoTestingService.Shared;
using Newtonsoft.Json;

namespace AutoTestingService.Configuration.AusyConfig
{

	/// <summary>Client configuration class.</summary>
	/// <description>Where the Client configuration information is stored. This information is parsed from the
	/// configuration file. If no file exists a new one is created with the default values.</description>
	[JsonObject (MemberSerialization.OptIn)]
	public class AusyConfiguration
	{
		#region Variables

		/// <summary>Machine identifier.</summary>
		public int MachineId { get; private set; }
		
		/// <summary>Machine ip.</summary>
		public string MachineIp { get; private set; }

		/// <summary>Server channel property, or "lookout". Example: tcp://172.20.101.224:14000/AutoTestingServer.Rem</summary>
		public string ServerChannel { get; private set; }

		/// <summary>Client network IP.</summary>
		//public string ClientIP { get; private set; }

		//public GameplayInfo gameplayInfo;

		/// <summary>Configuration settings for the application.</summary>
		[JsonProperty]
		public AusyApplicationConfig Application = new AusyApplicationConfig ();
		
		/// <summary>Configuration settings for Operator (only used when role="operator")</summary>
		[JsonProperty] 
		public AusyOperatorConfig Operator = new AusyOperatorConfig();

		/// <summary>Configuration settings for Coordinator (only used when role="coordinator")</summary>
		[JsonProperty] 
		public AusyCoordinatorConfig Coordinator = new AusyCoordinatorConfig();

		/// <summary>Configuration settings for the game.</summary>
		[JsonProperty]
		public AusyGameConfig Game = new AusyGameConfig ();

		/// <summary>Configuration settings for accounting.</summary>
		[JsonProperty]
		public AusyAccountingConfig Accounting = new AusyAccountingConfig ();
		
		/// <summary>Configuration settings for peripherals.</summary>
		[JsonProperty]
		public AusyPeripheralConfig Peripherals = new AusyPeripheralConfig ();

		#endregion

		#region Init

		public MachineController _controller;

		/// <summary>Initializes a new instance of the ClientConfiguration class.</summary>
		public AusyConfiguration ()
		{
			//ClientIP = Helper.Instance.GetIPFromNetWorkInterface ();
			//if (ClientIP == "-1")
			//{
			//	ClientIP = "localhost";
			//}
			MachineId = getIdFromNetWorkInterface ();
			//MachineIp = Helper.Instance.Ip;
		}

		#endregion

		#region Auxiliary

		/// <summary>Finishes setting up the configuration data, after it having been read or deserialized.</summary>
		public void FinishSetup ()
		{
			if (Operator.CoordinatorIP == "lookout")
			{
				ServerChannel = "lookout";
			}
			else
			{
				ServerChannel = string.Format (ATNames.Instance.ServerUriFormatForClients, Operator.CoordinatorIP);
			}
		}

		/// <summary>Gets the ID from the Network Interface.</summary>
		/// <returns>The identifier from Network Interface.</returns>
		private int getIdFromNetWorkInterface ()
		{
			return Helper.Instance.GetIdFromNetWorkInterface ();
		}

		public void setController(MachineController controller)
		{
			_controller = controller;
		}

		/*public void SetGamePlayInfo(GameplayInfo gameplayInfo)
		{
			this.gameplayInfo = gameplayInfo;
		}*/
		
		public void SetMachineIp(string machineIp)
		{
			MachineIp = machineIp;
		}
		
		/// <summary>Loads Ausy Config from file to object.</summary>
		public void Load ()
		{
			EventDistributor.Instance.Trigger("JsLoadAusyConfig", "", MachineIp);
		}

		/// <summary>Saves data to the files.</summary>
		public void Save ()
		{ 
			string ausyConfigJson = JsonConvert.SerializeObject(this);

			EventDistributor.Instance.Trigger("JsSaveAusyConfig",  ausyConfigJson, MachineIp);
		}
		#endregion

		#region Integrity

		/// <summary>Verify the validity of variables.</summary>
		public bool Verify ()
		{
			if (Application.Role == "operator" && !Application.StandaloneMode && !Helper.Instance.IsValidIP (Operator.CoordinatorIP) && Operator.CoordinatorIP != "lookout")
			{
				Logger.Instance.UpdateLog ("Unknown coordinator IP format: " + Operator.CoordinatorIP, LoggerType.Error);
				return false;
			}

			if (Application.InputDelay < 0)
			{
				Logger.Instance.UpdateLog ("Invalid input delay: " + Application.InputDelay, LoggerType.Error);
				return false;
			}

			if (Application.Role == "operator" && !Directory.Exists (Game.GamePath))
			{
				Logger.Instance.UpdateLog ("Game folder does not exist: " + Game.GamePath, LoggerType.Error);
				return false;
			}

			if (Application.Role == "operator" && Game.LogsPath.Contains("/") && !Directory.Exists (Game.LogsPath))
			{
				Logger.Instance.UpdateLog ("Logs folder does not exist: " + Game.LogsPath, LoggerType.Error);
				return false;
			}

			if (!Enum.IsDefined (typeof (LogType), Game.LogType))
			{
				Logger.Instance.UpdateLog ("Invalid log type: " + Game.LogType, LoggerType.Error);
				return false;
			}

			if (!Enum.IsDefined (typeof (CashSystem), Accounting.CashSystem))
			{
				Logger.Instance.UpdateLog ("Invalid cash system: " + Accounting.CashSystem, LoggerType.Error);
				return false;
			}

			if (!Accounting.S2S.CardNumberFromIP && Accounting.S2S.CardNumber.Length == 0)
			{
				Logger.Instance.UpdateLog ("S2S card number is empty.", LoggerType.Error);
				return false;
			}

			if (Accounting.S2S.AllowRecharge && Accounting.S2S.RechargeAmount <= 0)
			{
				Logger.Instance.UpdateLog ("Invalid S2S recharge amount: " + Accounting.S2S.RechargeAmount, LoggerType.Error);
				return false;
			}

			if (Accounting.S2S.AllowRecharge && Accounting.S2S.RechargeWait < 0)
			{
				Logger.Instance.UpdateLog ("Invalid S2S recharge wait time: " + Accounting.S2S.RechargeWait, LoggerType.Error);
				return false;
			}

			if (Accounting.S2S.AllowRecharge && !Helper.Instance.IsValidIP (Accounting.S2S.DatabaseIP))
			{
				Logger.Instance.UpdateLog ("Invalid S2S recharge database IP: " + Accounting.S2S.DatabaseIP, LoggerType.Error);
				return false;
			}

			if (Accounting.S2S.AllowRecharge && Accounting.S2S.DatabaseUser.Length == 0)
			{
				Logger.Instance.UpdateLog ("S2S recharge database user name is empty.", LoggerType.Error);
				return false;
			}

			if (Accounting.S2S.AllowRecharge && Accounting.S2S.DatabasePassword.Length == 0)
			{
				Logger.Instance.UpdateLog ("S2S recharge database password is empty.", LoggerType.Error);
				return false;
			}

			if (Accounting.S2S.AllowRecharge && Accounting.S2S.DatabaseName.Length == 0)
			{
				Logger.Instance.UpdateLog ("S2S recharge database name is empty.", LoggerType.Error);
				return false;
			}

			return true;
		}

		#endregion
	}
}

