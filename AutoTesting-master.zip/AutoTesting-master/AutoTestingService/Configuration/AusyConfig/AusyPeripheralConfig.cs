﻿using Newtonsoft.Json;

namespace AutoTestingService.Configuration.AusyConfig
{
	[JsonObject (MemberSerialization.OptIn)]
	public class AusyPeripheralConfig
	{
		#region Defaults

		public const bool UsePeripheralsDefault = true;
		public const string CardReaderPortDefault = "/dev/tnt0";
		public const string BillAcceptorPortDefault = "/dev/tnt2";
		public const string SASPortDefault = "/dev/ttyUSB0";
		public const bool DebugCashCodeDefault = false;

		#endregion

		#region Variables

		/// <summary>Use the peripherals?</summary>
		[JsonProperty]
		public bool UsePeripherals = UsePeripheralsDefault;
		
		/// <summary>Port to connect the card reader to.</summary>
		[JsonProperty]
		public string CardReaderPort = CardReaderPortDefault;
		
		/// <summary>Port to connect the bill acceptor to.</summary>
		[JsonProperty]
		public string BillAcceptorPort = BillAcceptorPortDefault;
		
		/// <summary>Port to connect the SAS host to.</summary>
		[JsonProperty]
		public string SASPort = SASPortDefault;
		
		/// <summary>Use the debug cashcode implementation</summary>
		[JsonProperty]
		public bool DebugCashCode = DebugCashCodeDefault;

		#endregion
	}
}
