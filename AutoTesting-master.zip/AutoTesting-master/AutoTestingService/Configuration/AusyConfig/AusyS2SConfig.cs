﻿using Newtonsoft.Json;

namespace AutoTestingService.Configuration.AusyConfig
{
	[JsonObject (MemberSerialization.OptIn)]
	public class AusyS2SConfig
	{
		#region Defaults

		public const string CardNumberDefault = "123";
		public const bool CardNumberFromIPDefault = true;
		public const bool AllowRechargeDefault = false;
		public const int RechargeAmountDefault = 9999;
		public const int RechargeWaitDefault = 6000;
		public const string DatabaseIPDefault = "";
		public const string DatabaseUserDefault = "";
		public const string DatabasePasswordDefault = "";
		public const string DatabaseNameDefault = "";

		#endregion

		#region Variables

		/// <summary>Card number.</summary>
		[JsonProperty]
		public string CardNumber = CardNumberDefault;

		/// <summary>Set the card number according to the machine local IP?</summary>
		[JsonProperty]
		public bool CardNumberFromIP = CardNumberFromIPDefault;

		/// <summary>Allow credits recharge?</summary>
		[JsonProperty]
		public bool AllowRecharge = AllowRechargeDefault;

		/// <summary>Amount of credits to recharge.</summary>
		[JsonProperty]
		public int RechargeAmount = RechargeAmountDefault;

		/// <summary>Time to wait for the recharge to take place.</summary>
		[JsonProperty]
		public int RechargeWait = RechargeWaitDefault;

		/// <summary>IP of the SQL database to recharge in. Likely needs to include the "\SQLEXPRESS" part.</summary>
		[JsonProperty]
		public string DatabaseIP = DatabaseIPDefault;

		/// <summary>Username of the SQL database to recharge in.</summary>
		[JsonProperty]
		public string DatabaseUser = DatabaseUserDefault;

		/// <summary>Password of the SQL database to recharge in.</summary>
		[JsonProperty]
		public string DatabasePassword = DatabasePasswordDefault;

		/// <summary>Name of the database to recharge in.</summary>
		[JsonProperty]
		public string DatabaseName = DatabaseNameDefault;

		#endregion
	}
}
