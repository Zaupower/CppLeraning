﻿using Newtonsoft.Json;

namespace AutoTestingService.Configuration.AusyConfig
{
	[JsonObject (MemberSerialization.OptIn)]
	public class AusyApplicationConfig
	{
		#region Defaults

		public const string RoleDefault = "operator";
		public const bool StandaloneModeDefault = true;
		public const string ServerIPDefault = "lookout";
		public const int InputDefaultDefault = 200;
		public const int DebugLevelDefault = 0;
		public const bool EmuServerDefault = false;
		public const bool ReportUnknownLogLinesDefault = false;
		public const string TestDefinitionsPathDefault = "/game/Ausy/testDefinitions.json";

		#endregion

		#region Variables
		
		/// <summary>Ausy role. It can take the values "operator" or "coordinator" (the 2nd is only for distributed mode)</summary>
		[JsonProperty]
		public string Role { get; private set; } = RoleDefault;

		/// <summary>Sets Ausy working mode. If true then mode=standalone, if false then mode=distributed.</summary>
		[JsonProperty]
		public bool StandaloneMode { get; private set; } = StandaloneModeDefault;

		/// <summary>JS file with a test script to run, if any.</summary>
		[JsonProperty]
		public string TestFile { get; private set; } = "";

		/// <summary>Input delay configured.</summary>
		[JsonProperty]
		public int InputDelay { get; private set; } = InputDefaultDefault;

		/// <summary>Debug level.</summary>
		[JsonProperty]
		public int DebugLevel { get; private set; } = DebugLevelDefault;

		/// <summary>Whether the gui is connected to the EMU server or the AuSy server.</summary>
		[JsonProperty]
		public bool EmuServer { get; private set; } = EmuServerDefault;

		/// <summary>Report log lines that the parser does not understand?</summary>
		[JsonProperty]
		public bool ReportUnknownLogLines { get; private set; } = ReportUnknownLogLinesDefault;

		/// <summary>Path to testDefinitions.json</summary>
		[JsonProperty]
		public string TestDefinitionsPath { get; set; } = "";

		#endregion

	}
}
