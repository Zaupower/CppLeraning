using Newtonsoft.Json;

namespace AutoTestingService.Configuration.AusyConfig
{
    /// <summary>
    /// Class for deserializing the block "Operator" in Ausy config.json
    /// </summary>
    [JsonObject (MemberSerialization.OptIn)]
    public class AusyOperatorConfig
    {
        #region JsonVariables

        /// <summary>Ip of the coordinator (for Distributed mode only)</summary>
        [JsonProperty] 
        public string CoordinatorIP { get; private set; }

        #endregion
    }
}