﻿using Newtonsoft.Json;

namespace AutoTestingService.Configuration.AusyConfig
{
	[JsonObject (MemberSerialization.OptIn)]
	public class AusyAccountingConfig
	{
		#region Defaults
		
		public const bool EnableKeyboardAcceptorDefault = false;
		public const CashSystem CashSystemDefault = CashSystem.S2S;

		#endregion

		#region Variables

		/// <summary>Current Cash System.</summary>
		[JsonProperty]
		public CashSystem CashSystem = CashSystemDefault;
		
		/// <summary>Current Cash System.</summary>
		[JsonProperty]
		public bool EnableKeyboardAcceptor = EnableKeyboardAcceptorDefault;

		/// <summary>Configurations for S2S.</summary>
		[JsonProperty]
		public AusyS2SConfig S2S = new AusyS2SConfig ();

		#endregion
	}
}
