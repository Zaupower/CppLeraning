﻿using Newtonsoft.Json;

namespace AutoTestingService.Configuration.AusyConfig
{
	[JsonObject (MemberSerialization.OptIn)]
	public class AusyGameConfig
	{
		#region Defaults

		public const string GamePathDefault = "/game";
		public const string LogsPathDefault = "/logs";
		public const bool ReadLogsWebsocketDefault = false;
		public const string LogsWebSocketReceiverIPDefault = "";
		public const LogType LogTypeDefault = LogType.Bingo;

		#endregion

		#region Variables

		/// <summary>Path to the folder with the game.</summary>
		[JsonProperty]
		public string GamePath { get; private set; } = GamePathDefault;

		/// <summary>Path to the folder with the Logs.</summary>
		[JsonProperty]
		public string LogsPath { get; private set; } = LogsPathDefault;
		
		/// <summary>Defines if Ausy is reading logs via websocket or via file.</summary>
		[JsonProperty]
		public bool ReadLogsWebsocket { get; private set; } = ReadLogsWebsocketDefault;

		/// <summary>IP that will receive websocket logs, or leave empty to use normal file logs.</summary>
		[JsonProperty]
		public string LogsWebSocketReceiverIP { get; private set; } = LogsWebSocketReceiverIPDefault;

		/// <summary>Type of the Log.</summary>
		[JsonProperty]
		public LogType LogType { get; private set; } = LogTypeDefault;

		#endregion
	}
}
