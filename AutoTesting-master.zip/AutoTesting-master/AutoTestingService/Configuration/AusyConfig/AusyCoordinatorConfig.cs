using System.Collections.Generic;
using Newtonsoft.Json;

namespace AutoTestingService.Configuration.AusyConfig
{
    /// <summary>
    /// Class for deserializing the block "Coordinator" in Ausy config.json
    /// </summary>
    [JsonObject (MemberSerialization.OptIn)]
    public class AusyCoordinatorConfig
    {
        #region JsonVariables

        /// <summary>The list of operators to connect to, if any (for distributed lookout mode only)</summary>
        [JsonProperty] 
        public List<string> OperatorList { get; private set; } = new List<string>();

        #endregion
    }
}