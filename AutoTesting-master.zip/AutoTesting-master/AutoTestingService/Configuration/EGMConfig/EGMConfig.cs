﻿using System;
using System.Reflection;
using AutoTestingService.Logging;
using AutoTestingService.Machine;
using Newtonsoft.Json;

namespace AutoTestingService.Configuration.EGMConfig
{
	public class EGMConfig
	{
		private MachineController _controller;

		private string _machineIp;

		[EGMConfig ("server.ip", "VAR_GAMESERVER_IP_ADDR")]
		public string ServerIP { get; set; }

		[EGMConfig ("server.protocol", "VAR_PROTOCOL_VERSION")]
		public int? ServerProtocol { get; set; }

		[EGMConfig ("server.country", "VAR_CR_NAME")]
		public string Country { get; set; }

		[EGMConfig ("server.provider", "VAR_PROVIDER")]
		public string Provider { get; set; }

		[EGMConfig ("machine.cabinet_type", "VAR_LAYOUT_TYPE")]
		public int? CabinetLayout { get; set; }

		[EGMConfig ("machine.io_type", "VAR_BOARD_NAME")]
		public string IoType { get; set; }

		[EGMConfig ("server.cash_system", "VAR_CASH_TYPE")]
		public int? CashSystem { get; set; }

		[EGMConfig ("machine.bill_path", "VAR_CASH_IO_PORT")]
		public string BillAcceptorPort { get; set; }

		[EGMConfig ("machine.bill_type", "VAR_CASH_IO_TYPE")]
		public int? BillAcceptorDriver { get; set; }

		[EGMConfig ("machine.printer_path", "VAR_PRINTER_PORT")]
		public string PrinterPort { get; set; }

		[EGMConfig ("machine.printer_type", "VAR_PRINTER_TYPE")]
		public int? PrinterDriver { get; set; }

		[EGMConfig ("SAS.tty", "VAR_SAS_IO_PORT")]
		public string SASPort { get; set; }

		[EGMConfig ("S2S.tty", "VAR_ALESIS_IO_PORT")]
		public string S2SPort { get; set; }

		/// <summary>Initializes a new instance of the <see cref="T:AutoTestingService.Configuration.EGMConfig.EGMConfig"/> class.</summary>
		/// <param name="controller">Controller of the machine this config belongs to.</param>
		public EGMConfig (MachineController controller)
		{
			_controller = controller;
		}

		public EGMConfig()
		{
			
		}
		
		public void SetMachineIp(string machineIp)
		{
			_machineIp = machineIp;
		}

		/// <summary>Loads data from the files.</summary>
		public void Load ()
		{
			EventDistributor.Instance.Trigger("JsLoadEGMConfig", "", _machineIp);
		}

		/// <summary>Saves data to the files.</summary>
		public void Save ()
		{
			string egmConfigJson = JsonConvert.SerializeObject(this);

			EventDistributor.Instance.Trigger("JsSaveEGMConfig", egmConfigJson, _machineIp);
		}

		/// <summary>Copies data from another config.</summary>
		/// <param name="other">The other config object to copy from.</param>
		public void CopyFrom (EGMConfig other)
		{
			MachineController controllerBackup = _controller;

			PropertyInfo[] props = GetType ().GetProperties ();
			foreach (var p in props)
			{
				p.SetValue (this, p.GetValue (other));
			}

			_controller = controllerBackup;
		}
	}

	[AttributeUsage (AttributeTargets.All)]
	public class EGMConfigAttribute : Attribute
	{
		public string configJsonName;
		public string presetsConfName;

		public EGMConfigAttribute (string configJsonName, string presetsConfName)
		{
			this.configJsonName = configJsonName;
			this.presetsConfName = presetsConfName;
		}
	}
}
