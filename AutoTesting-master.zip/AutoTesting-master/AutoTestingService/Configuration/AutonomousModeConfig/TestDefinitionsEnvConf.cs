using Newtonsoft.Json;

namespace AutoTestingService.Configuration.AutonomousModeConfig
{
    public class TestDefinitionsEnvConf
    {
        #region JsonVariables

        /// <summary>Path do envConf.js file (this can be local path or repository relative path)</summary>
        [JsonProperty]
        public string path { get; private set; }
        
        /// <summary>Git repository (opcional)</summary>
        [JsonProperty]
        public string rep { get; private set; }
        
        /// <summary>commit ID of Git repository (mandatory if using git repo)</summary>
        [JsonProperty]
        public string commitID { get; private set; }

        #endregion
    }
}