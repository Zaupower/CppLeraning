using System.Collections.Generic;

namespace AutoTestingService.Configuration.AutonomousModeConfig
{
    public class TestDefinitionsTestScriptsConfiguration
    {
        public List<string> Path { get; set; }
        
        public string Rep { get; set; }
        
        public string CommitID { get; set; }
    }
}