using System.Collections.Generic;
using Newtonsoft.Json;

namespace AutoTestingService.Configuration.AutonomousModeConfig
{
    public class TestDefinitions
    {
        #region Defaults

        //public const string ConfigEnvironmentDefault = "/game/Ausy/envConf.js";
        //public const string ConfigAuSyDefault = "/game/Ausy/ausyConf.js";
        public const string ReportScriptDefault = "/game/Ausy/deliver_ausy_test_results.py";
        #endregion
        
        #region JsonVariables

        [JsonProperty] 
        public TestDefinitionsEnvConf ConfigEnvironment = new TestDefinitionsEnvConf();

        [JsonProperty]
        public TestDefinitionsAusyConf ConfigAusy = new TestDefinitionsAusyConf();

        [JsonProperty]
        public List<TestDefinitionsTestScriptsConfiguration> Includes;

        [JsonProperty]
        public string ReportScript { get; private set; } = ReportScriptDefault;

        public List<TestDefinitionsTestScriptsConfiguration> TestScripts;

        #endregion

        #region Variables

        [JsonIgnore]
        public string testResultsFolderPath;

        // These are the local paths to the EnvConfig.js and AusyConf.js files (whether it's a git config file or a local file, the path is stored here)
        [JsonIgnore]
        public string ConfigEnvLocalPath;
        [JsonIgnore]
        public string ConfigAusyLocalPath;

        #endregion

    }
}