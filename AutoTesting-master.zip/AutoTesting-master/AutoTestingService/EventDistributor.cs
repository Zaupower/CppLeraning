using System;
using System.Collections.Generic;
using System.Net;
using Newtonsoft.Json;

namespace AutoTestingService
{
    /// <summary>The Event Distributor is in charge of distributing an event towards the local Event Handler,
    /// or towards the WebSocket Communication Manager that can send it to another AuSy program.</summary>
    public class EventDistributor
    {
        #region Singleton

        public static EventDistributor Instance { get; } = new EventDistributor ();

        private EventDistributor ()
        {
        }

        #endregion

        #region Members

        /// <summary>The WebSocket Communication Manager responsible for all connected machines.</summary>
        private WebSockets.CommunicationManager _wsManager;

        #endregion

        #region Init

        /// <summary>Initializes the Event Distributor.</summary>
        /// <param name="wsManager">The WebSocket Communication Manager responsible for all connected machines.</param>
        public void Init(WebSockets.CommunicationManager wsManager)
        {
            _wsManager = wsManager;
        }

        #endregion
        
        #region Functions

        /// <summary>Triggers an event, distributing it to the correct recipient.</summary>
        /// <param name="eventName">Name of the event.</param>
        /// <param name="param">Parameter.</param>
        /// <param name="recipientIp">IP address of the recipient. Empty for local.</param>
        public void Trigger(string eventName, string param, string recipientIp = "")
        {
            if (String.IsNullOrEmpty(recipientIp) || recipientIp == "localhost" || recipientIp == "127.0.0.1" || recipientIp == Helper.Instance.Ip)
            {
                EventHandler.Instance.Trigger(eventName, param);
            }
            else
            {
                Dictionary<string, object> d = new Dictionary<string, object>
                {
                    {"message", "TriggerEvent"},
                    {"eventName", eventName},
                    {"param", param}
                };
                _wsManager.Send(recipientIp, JsonConvert.SerializeObject(d));
            }
        }

        #endregion
    }
}