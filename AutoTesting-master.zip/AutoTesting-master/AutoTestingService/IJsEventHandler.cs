namespace AutoTestingService
{
    public interface IJsEventHandler
    {
        void DoJsPrint(string text, EventInfo? _);

        void InvokeGameEvent(Jint.Native.JsValue eventCallback, Jint.Native.JsValue[] eventParams);
    }
}