#!/bin/bash

EXACT_TAG=$(git describe --exact-match --tags HEAD 2> /dev/null)
if [ -z "$EXACT_TAG" ]; then
    VERSION=$(git describe --long --tags 2> /dev/null)
else
    VERSION=$EXACT_TAG
fi

if [ -z "$VERSION" ]; then
    VERSION=$(git rev-parse --short HEAD 2> /dev/null)
fi

if [ -z "$VERSION" ]; then
    VERSION=UNKNOWN
fi

echo "// This file is generated automatically during the build process." > ProgramProperties.cs
echo "// Do not edit it by hand!" >> ProgramProperties.cs
echo " " >> ProgramProperties.cs
echo "namespace AutoTestingService" >> ProgramProperties.cs
echo "{" >> ProgramProperties.cs
echo "    public class ProgramProperties" >> ProgramProperties.cs
echo "    {" >> ProgramProperties.cs
echo "        public const string Version = \"$VERSION\";" >> ProgramProperties.cs
echo "    }" >> ProgramProperties.cs
echo "}" >> ProgramProperties.cs
