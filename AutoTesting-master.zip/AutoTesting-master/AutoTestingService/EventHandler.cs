﻿using System;
using System.Collections.Generic;
using AutoTestingService.Logging;
using Jint.Native;
using Newtonsoft.Json;

namespace AutoTestingService
{
	/// <summary>Event handler singleton.</summary>
	public sealed class EventHandler
	{
		/// <summary>Delegate for functions that populate the full list of events.</summary>
		public delegate HashSet<string> EventListSource();

		#region Singleton

		public static EventHandler Instance { get; } = new EventHandler();

		private EventHandler()
		{
			RegisterEventListSource(GetStandardEventList);
		}

		#endregion

		#region Members

		/// <summary>Class that will handle JS events by calling JS functions.</summary>
		private IJsEventHandler _jsEventHandler;

		/// <summary>Functions that populate the complete event list.</summary>
		private List<EventListSource> _eventListSources = new List<EventListSource>();

		/// <summary>List of registered C# callbacks.</summary>
		private Dictionary<string, List<Action<string, EventInfo?>>> _csEventCallbacks =
			new Dictionary<string, List<Action<string, EventInfo?>>>();

		/// <summary>List of registered JS callbacks.</summary>
		private Dictionary<string, List<JsValue>> _jsEventCallbacks =
			new Dictionary<string, List<JsValue>>();

		#endregion

		#region Event handling

		/// <summary>Sets what object will handle JS events.</summary>
		/// <param name="jsEventHandler">Object that will handle JS events.</param>
		public void SetJsEventHandler(IJsEventHandler jsEventHandler)
		{
			_jsEventHandler = jsEventHandler;
		}

		/// <summary>Adds a callback with C# code.</summary>
		/// <param name="eventName">Event name.</param>
		/// <param name="callback">Callback code to run.</param>
		public void AddCallback(string eventName, Action<string, EventInfo?> callback)
		{
			if (!GetCompleteEventList().Contains(eventName))
			{
				Console.WriteLine("AddCallback warning: The specified event '" + eventName + "' does not exist.");
				return;
			}

			if (!_csEventCallbacks.ContainsKey(eventName))
			{
				_csEventCallbacks[eventName] = new List<Action<string, EventInfo?>>();
			}

			_csEventCallbacks[eventName].Add(callback);
		}

		/// <summary>Adds a callback with JS code.</summary>
		/// <param name="eventName">Event name.</param>
		/// <param name="callbackCode">Callback code to run.</param>
		public void AddCallback(string eventName, JsValue callbackCode)
		{
			if (!GetCompleteEventList().Contains(eventName))
			{
				_jsEventHandler.DoJsPrint(
					"AddCallback warning: The specified event '" + eventName + "' does not exist.", null);
				return;
			}

			if (!_jsEventCallbacks.ContainsKey(eventName))
			{
				_jsEventCallbacks[eventName] = new List<JsValue>();
			}

			_jsEventCallbacks[eventName].Add(callbackCode);
		}

		/// <summary>Returns whether or not the given event name is registered.</summary>
		/// <returns><c>true</c>, if event exists, <c>false</c> otherwise.</returns>
		/// <param name="eventName">Event name.</param>
		public bool ContainsEvent(string eventName)
		{
			return GetCompleteEventList().Contains(eventName);
		}

		/// <summary>Removes a registered callback with C# code.</summary>
		/// <param name="eventName">Event name.</param>
		/// <param name="callback">Callback code to run.</param>
		public void RemoveCallback(string eventName, Action<string, EventInfo?> callback)
		{
			if (!_csEventCallbacks.ContainsKey(eventName))
			{
				Console.WriteLine("RemoveCallback warning: The specified event '" + eventName + "' does not exist.");
				return;
			}

			if (_csEventCallbacks[eventName].IndexOf(callback) == -1)
			{
				Console.WriteLine("RemoveCallback warning: The specified callback for the event '" + eventName +
				                  "' does not exist.");
				return;
			}

			_csEventCallbacks[eventName].Remove(callback);
		}

		/// <summary>Removes a registered callback with JS code.</summary>
		/// <param name="eventName">Event name.</param>
		/// <param name="callback">Callback code to run.</param>
		public void RemoveCallback(string eventName, JsValue callback)
		{
			if (!_csEventCallbacks.ContainsKey(eventName))
			{
				_jsEventHandler.DoJsPrint("RemoveCallback warning: The specified event '" + eventName +
				                          "' does not exist.", null);
				return;
			}

			if (_jsEventCallbacks[eventName].IndexOf(callback) == -1)
			{
				_jsEventHandler.DoJsPrint("RemoveCallback warning: The specified callback for the event '" + eventName +
				                          "' does not exist.", null);
				return;
			}

			_jsEventCallbacks[eventName].Remove(callback);
		}


		/// <summary>Trigger the specified event.</summary>
		/// <returns>Returns true if it got handled.</returns>
		/// <param name="eventName">Event name.</param>
		/// <param name="param">Event parameters.</param>
		/// <param name="info">Extra event info.</param>
		public bool Trigger(string eventName, string param, EventInfo? info = null)
		{
			bool jsEvent = _jsEventCallbacks.ContainsKey(eventName);
			bool csEvent = _csEventCallbacks.ContainsKey(eventName);

			if (!jsEvent && !csEvent)
			{
#if DEBUG
				Console.WriteLine("Event " + eventName + " has no listeners.");
#endif
				return false;
			}

			if (csEvent)
			{
				// Save the callbacks to a list first. This is because one of the callbacks can call code to clear
				// the list of callbacks, i.e. an AuSy restart.
				List<Action<string, EventInfo?>> callbacks = new List<Action<string, EventInfo?>>();
				foreach (Action<string, EventInfo?> callback in _csEventCallbacks[eventName])
				{
					callbacks.Add(callback);
				}

				foreach (var callback in callbacks)
				{
					callback.Invoke(param, info);
				}
			}

			if (jsEvent)
			{
				// Save the callbacks to a list first. This is because one of the callbacks can call code to clear
				// the list of callbacks, i.e. an AuSy restart.
				List<string> eventParams = new List<string>
				{
					param
				};

				List<JsValue> callbacks = new List<JsValue>();
				foreach (JsValue callback in _jsEventCallbacks[eventName])
				{
					callbacks.Add(callback);
					
				}

				foreach (var callback in callbacks)
				{
					JsValue[] parameters = new JsValue[eventParams.Count];
					int i = 0;
					foreach (string p in eventParams)
					{
						parameters[i] = p;
						i++;
					}

					_jsEventHandler.InvokeGameEvent(callback, parameters);
				}
			}


			return true;
		}

		/// <summary>Trigger the specified event.</summary>
		/// <returns>Returns true if it got handled.</returns>
		/// <param name="eventName">Event name.</param>
		/// <param name="eventParams">Event parameters.</param>
		public bool TriggerForJs(string eventName, List<object> eventParams)
		{
			if (!_jsEventCallbacks.ContainsKey(eventName))
			{
				return false;
			}

			JsValue[] parameters = new JsValue[eventParams.Count];

			int i = 0;
			foreach (object p in eventParams)
			{
				if (p is double)
					parameters[i] = new JsValue((double) p);
				else if (p is string)
					parameters[i] = new JsValue((string) p);

				i++;
			}

			foreach (JsValue callback in _jsEventCallbacks[eventName])
			{
				_jsEventHandler.InvokeGameEvent(callback, parameters);
			}

			return true;
		}

		/// <summary>Trigger the specified event.</summary>
		/// <returns>Returns true if it got handled.</returns>
		/// <param name="eventName">Event name.</param>
		/// <param name="eventParams">Event parameters.</param>
		/// <param name="types">List of what type each parameter is.</param>
		public bool TriggerForJs(string eventName, List<object> eventParams, string[] types)
		{
			if (!_jsEventCallbacks.ContainsKey(eventName))
			{
				return false;
			}

			JsValue[] parameters = new JsValue[eventParams.Count];

			int i = 0;
			foreach (object p in eventParams)
			{
				if (types[i].Trim().Equals("double"))
				{
					try
					{
						parameters[i] = new JsValue((double) p);
					}
					catch (Exception e)
					{
						Logger.Instance.UpdateLog(
							"O parametro numero " + (i + 1) + " do evento " + eventName +
							" não pode ser do tipo double. O programa falhou com a exceção " + e, LoggerType.Error);
						return false;
					}
				}
				else if (types[i].Trim().Equals("string"))
				{
					parameters[i] = new JsValue(p.ToString());
				}
				else
				{
					Logger.Instance.UpdateLog(
						"O tipo introduzido para o parametro numero " + (i + 1) + " do evento " + eventName +
						" não é valido. Tem de ser um double ou uma string.", LoggerType.Warning);
				}

				i++;
			}

			foreach (JsValue callback in _jsEventCallbacks[eventName])
			{
				_jsEventHandler.InvokeGameEvent(callback, parameters);
			}

			return true;
		}

		/// <summary>Clears all registered JS event callbacks.</summary>
		public void ClearJSCallbacks()
		{
			_jsEventCallbacks.Clear();
		}

		/// <summary>Sets the list of callbacks from a helper object.</summary>
		/// <param name="helper">Helper object.</param>
		public void SetCallbackList(Jint.Native.Object.ObjectInstance helper)
		{
			ClearJSCallbacks();
			foreach (var p in helper.GetOwnProperties())
			{
				AddCallback(p.Key, p.Value.Value);
			}
		}

		#endregion

		#region List of events

		/// <summary>Registers a function as a new source of events.</summary>
		/// <param name="source">A function that returns a list of events.</param>
		public void RegisterEventListSource(EventListSource source)
		{
			_eventListSources.Add(source);
		}

		/// <summary>Returns a list with the standard AuSy events.</summary>
		private HashSet<string> GetStandardEventList()
		{
			return new HashSet<string>
			{
				// Ausy startup
				"StartAusy",
				"StartAusy2",
				
				// Ausy and EGM configuration
				"GotAusyConfig",
				"AusyConfigSaved",
				"GotEGMConfig",
				"EGMConfigSaved",
				"JsLoadAusyConfig",
				"JsLoadEGMConfig",
				"JsSaveAusyConfig",
				"JsSaveEGMConfig",
				"LoadedAusyConfig",
				"LoadedEGMConfig",
				
				//General communication
				"Send",
				"SendToAll",
				"GotMessage",
				"GotZip",
				"GuiConnected",
				"ScripterConnected",
				"ScripterDisconnected",
				"ConnectToCoordinator",
				"SendEmuMessage",
				"SendGuiMessage",
				"SendSasMessage",
				"SendAllMessage",
				"ConnectionToAusyLost",
				"EventReportIpChanged",

				//Game events.
				"ClearCustomLineTypes",
				"CreateJSTimer",
				"GotGameEvent",
				"NewGameLogLines",
				"NewCustomGameEventFromJs",
				"RemoveJSTimer",

				//JS.
				"DoJsPrint",
				"RunJs",
				"RunJsFile",
				"ResetJsEngine",
				"SetAltIncludesFolder",
				"JsOutput",
				"SetJsLogFileLocation",

				//Test management.
				"FailStep",
				"FailTest",
				"DeleteTest",
				"PassStep",
				"PassTest",
				"RegisterStep",
				"RegisterTest",
				"ReplaceTests",
				"StartTests",
				"StopTests",
				"TestSuiteEnded",
				"UpdateTestSuiteFromFolder",
				"TestSuiteError",

				//Machine actions.
				"BlockIP",
				"ChangeGalleryGame",
				"ClearNVs",
				"Click",
				"FixMD5",
				"InsertBill",
				"InsertCard",
				"InsertCredits",
				"InsertTicket",
				"ForceBalls",
				"ForceCards",
				"PressButton",
				"PressKey",
				"Reboot",
				"RegisterMachine",
				"RemoveCredits",
				"RestartGame",
				"SetVLT",
				"TakeScreenshot",
				"UnblockIP",

				//EMU.
				"EmuGotReport",
				"EmuGotStartPlay",
				"EmuGotEndPlay",
				"EmuGotPrizeJackpot",
				"EmuWonJackpotLocal",

				//SAS.
				"TransactionFinished",
				"GetSASMeter",
				"SASLPReceived",
				"SASMeterReceived",
				"SendSASByteArray",
				"SendSASLP",
				"StartAFTCashIn",
				"StartAFTCashOut",
				"RemoteResetHandpay",
				
				//S2S
				"S2SCardAlreadyInside",
				"S2SInsertCard",
				"S2SRemoveCard",
				
				//TITO
				"TITOInsertBill",
				"TITOInsertTicket",

				//Misc.
				"PrintCurrentState",
				"ResetBillAcceptor",
				"RestartCashcode",
				"RestartAusy",
				
				//GameLogsReader
				"WsNewGameLogLines",
			};
		}

		/// <summary>Returns a complete list of the names of all events currently in the system.</summary>
		/// <returns>The event list.</returns>
		private HashSet<string> GetCompleteEventList()
		{
			HashSet<string> completeEventList = new HashSet<string>();
			foreach (var source in _eventListSources)
			{
				completeEventList.UnionWith(source.Invoke());
			}

			return completeEventList;
		}

		#endregion
	}


	/// <summary>Wrapper used in JavaScript to add and remove callbacks.</summary>
	public class JSEventHandlerWrapper
	{
		private EventHandler handler;

		/// <summary>Initializes a new instance of the JSEventHandlerWrapper class.</summary>
		/// <param name="handler">Main event handler.</param>
		public JSEventHandlerWrapper(EventHandler handler)
		{
			this.handler = handler;
		}

		/// <summary>Adds a callback.</summary>
		/// <param name="eventName">Event name.</param>
		/// <param name="callbackCode">Callback code to run.</param>
		public void AddCallback(string eventName, JsValue callbackCode)
		{
			handler.AddCallback(eventName, callbackCode);
		}

		/// <summary>Adds a new log pattern to the list of events.</summary>
		/// <param name="eventName">Event name.</param>
		/// <param name="logPattern">Log regex pattern.</param>
		/// <param name="types">List of what type each parameter is.</param>
		public void AddEvent(string eventName, string logPattern, string types)
		{
			if (handler.ContainsEvent(eventName))
			{
				handler.Trigger("DoJsPrint", "AddEvent warning: The event '" + eventName + "' already exists. A new definition will be added to this event.");
			}

			Dictionary<string, string> data = new Dictionary<string, string>
			{
				{"name", eventName},
				{"logPattern", logPattern},
				{"types", types}
			};
			
			handler.Trigger("NewCustomGameEventFromJs", JsonConvert.SerializeObject(data));
		}

		/// <summary>Removes a registered callback.</summary>
		/// <param name="eventName">Event name.</param>
		/// <param name="callbackCode">Callback code to run.</param>
		public void RemoveCallback(string eventName, JsValue callbackCode)
		{
			handler.RemoveCallback(eventName, callbackCode);
		}

		/// <summary>Sets the list of callbacks from a helper object.</summary>
		/// <param name="helper">Helper object.</param>
		public void SetCallbackList(JsValue helper)
		{
			handler.SetCallbackList(helper.AsObject());
		}
	}

	/// <summary>Extra information about the event.</summary>
	public struct EventInfo
	{
		/// <summary>If the event was triggered remotely via websocket, this is the sender's IP.</summary>
		public string originIp;
	}
}