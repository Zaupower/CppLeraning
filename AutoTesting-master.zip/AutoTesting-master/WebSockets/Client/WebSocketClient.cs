using System;
using System.Collections.Generic;
using WebSocketSharp;

namespace WebSockets
{
    /// <summary>This class implements a websocket client</summary>
    public class WebSocketClient
    {
        #region Variables

        /// <summary>The Web Socket Client.</summary>
        private WebSocket _webSocketClient;

        /// <summary>The communication hub it belongs to.</summary>
        private CommunicationManager _hub;

        private string _serverIp;
        
        /// <summary>Checks if webSocketClient is alive.</summary>
        public bool IsAlive => _webSocketClient != null && _webSocketClient.IsAlive;
        
        /// <summary>Prototype of callback function to be called when string message is received</summary>
        public delegate void onStrMessageFunct (string message);
        /// <summary>Prototype of callback function to be called when string message is received</summary>
        public delegate void onStrMessageFunctIp (string senderIp, string message);
        /// <summary>Prototype of callback function to be called when bytes message is received</summary>
        public delegate void onBytesMessageFunct (byte[] message);
        /// <summary>Prototype of callback function to be called when connection to WS server is closed.</summary>
        public delegate void onCloseFunct(string ip);

        /// <summary>Callback function to be called when string message is received</summary>
        private onStrMessageFunct _onStrMessage;
        /// <summary>Callback function to be called when string message is received</summary>
        private onStrMessageFunctIp _onStrMessageIp;
        /// <summary>Callback function to be called when bytes message is received</summary>
        private onBytesMessageFunct _onBytesMessage;
        /// <summary>Callback function to be called when connection with server is closed</summary>
        private onCloseFunct _onClose;

        #endregion

        #region Constructor

        public WebSocketClient(CommunicationManager hub)
        {
            _hub = hub;
        }

        #endregion

        #region Methods

        /// <summary>Sets function to be called when string message is received</summary>
        /// <param name="onStrMessage">OnStringMessage function</param>
        /// <returns>WebSocketClient instance</returns>
        public WebSocketClient SetOnStringMessage(onStrMessageFunct onStrMessage)
        {
            _onStrMessage = onStrMessage;
            return this;
        }
        
        /// <summary>Sets function to be called when string message is received</summary>
        /// <param name="onStrMessage">OnStringMessage function</param>
        /// <returns>WebSocketClient instance</returns>
        public WebSocketClient SetOnStringMessage(onStrMessageFunctIp onStrMessageIp)
        {
            _onStrMessageIp = onStrMessageIp;
            return this;
        }
        
        /// <summary>Sets function to be called when bytes message is received</summary>
        /// <param name="onBytesMessage">onBytesMessage function</param>
        /// <returns>WebSocketClient instance</returns>
        public WebSocketClient SetOnBytesMessage(onBytesMessageFunct onBytesMessage)
        {
            _onBytesMessage = onBytesMessage;
            return this;
        }

        /// <summary>Sets function to be called when connection with server is closed</summary>
        /// <param name="onClose">onClose function</param>
        /// <returns>WebSocketClient instance</returns>
        public WebSocketClient SetOnClose(onCloseFunct onClose)
        {
            _onClose = onClose;
            return this;
        }

        /// <summary>Connects to server in specified channel</summary>
        /// <param name="ip">Server IP.</param>
        /// <param name="port">Port.</param>
        /// <param name="channel">Server channel. This is only the channel name.</param>
        /// <returns></returns>
        public bool Connect(string ip, int port, string channel)
        {
            _serverIp = ip;
            string fullUrl = "ws://" + ip + ":" + port + "/" + channel;
            
            Disconnect();
            
            _webSocketClient = new WebSocket(fullUrl);
            
            _webSocketClient.OnOpen += (sender, args) =>
            {
                _hub.wsConnectionIps.Add(new Tuple<string, WebSocket>(ip, _webSocketClient));
            };
            _webSocketClient.OnClose += (sender, args) =>
            {
                _hub.wsConnectionIps.Remove(new Tuple<string, WebSocket>(ip, _webSocketClient));
            };
            
            _webSocketClient.OnMessage += HandleServerMessage;
            _webSocketClient.OnError += HandleOnError;
            _webSocketClient.Connect();
            
            return IsAlive;
        }

        /// <summary>Handles a WebSocket message from the server.</summary>;
        /// <param name="sender">Sender object</param>
        /// <param name="e">Message information</param>
        private void HandleServerMessage(object sender, MessageEventArgs e)
        {
            if (e.IsBinary)
            {
                if (_onBytesMessage != null)
                    _onBytesMessage.Invoke(e.RawData);
                else
                    Console.WriteLine("WebSocketClient: Received bytes message but no OnByteMessage function is defined. Message: " + e.RawData);
            }
            else
            {
                if (_onStrMessage != null)
                {
                    _onStrMessage.Invoke(e.Data);
                }
                else if (_onStrMessageIp != null)
                {
                    _onStrMessageIp.Invoke(e.Data, _serverIp);
                }
                else
                {
                    Console.WriteLine("WebSocketClient: Received string message but no OnStrMessage function is defined. Message: " + e.Data);
                }
            }
        }

        /// <summary>Handles the closing of the connection to the WS server</summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void HandleOnError(object sender, ErrorEventArgs e)
        {
            // This OnError handler is used to trigger the onClose handler (the actual OnClose handler wasn't being triggered when the connection was closed)
            if (!IsAlive)
            {
                _webSocketClient?.Close();
                _onClose?.Invoke(_serverIp);
            }
        }


        /// <summary>Closes connection to the websocket Server</summary>
        public void Disconnect()
        {
            if (_webSocketClient != null)
            {
                if (_webSocketClient.IsAlive)
                {
                    _webSocketClient.Close();
                }
            }

            _webSocketClient = null;
        }

        /// <summary>Sends message to the connected websocket Server</summary>
        /// <param name="message">String message</param>
        public void Send(string message)
        {
            if (IsAlive)
            {
                _webSocketClient.Send(message);
            }
        }

        /// <summary>Sends message to the connected websocket Server</summary>
        /// <param name="message">Bytes message</param>
        public void Send(byte[] message)
        {
            if (IsAlive)
            {
                _webSocketClient.Send(message);
            }
        }

        #endregion
    }
}