namespace WebSockets
{
    /// <summary>Names of all the existing modules (e.g. Ausy, Emu, Sas)</summary>
    public enum Apps
    {
        Ausy,   // from other modules perspectives (Emu, Sas), Ausy mode (standalone or distributed) is abstracted. It doesn't matter if it's a AusyClient or AusyServer communicating.
        AusyOperator,
        AusyCoordinator,
        Emu,
        Sas,
        Gui,
        EmuGui,
        GameLogs,
        None
    }
}