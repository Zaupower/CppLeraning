using System;
using System.Reflection;
using WebSocketSharp;
using WebSocketSharp.Server;

namespace WebSockets
{
    public class SuperBehavior :  WebSocketBehavior
    {
        #region Variables

        private CommunicationManager _hub;
        private Apps _destinationApp;
        private WebSocketServer.OnOpenFunct _onOpen;
        private WebSocketServer.OnStrMessageFunct _onStrMessage;
        private WebSocketServer.OnBytesMessageFunct _onBytesMessage;
        private WebSocketServer.OnCloseFunct _onClose;

        #endregion

        #region Constructor

        /// <summary>Constructor to be used for module specific communication channels, and with a communication manager.</summary>
        /// <param name="hub">Communication manager instance</param>
        /// <param name="app">Target communication module</param>
        /// <param name="onOpen">onOpen function</param>
        /// <param name="onStrMessage">onStrMessage function</param>
        /// <param name="onBytesMessage">onBytesMessage function</param>
        /// <param name="onClose">onClose function</param>
        public SuperBehavior(CommunicationManager hub, Apps app, WebSocketServer.OnOpenFunct onOpen, WebSocketServer.OnStrMessageFunct onStrMessage, WebSocketServer.OnBytesMessageFunct onBytesMessage, WebSocketServer.OnCloseFunct onClose)
        {
            _hub = hub;
            _destinationApp = app;
            _onOpen = onOpen;
            _onStrMessage = onStrMessage;
            _onBytesMessage = onBytesMessage;
            _onClose = onClose;
        }
        
        #endregion

        #region Methods

        /// <summary>When the connection with a WsClient is open.</summary>
        protected override void OnOpen ()
        {
            if (_hub != null && _destinationApp != Apps.None)
            {
                _hub.AddWsServerConnection(_destinationApp, Context.WebSocket);
                _hub.wsConnectionIps.Add(
                    new Tuple<string, WebSocket>(Context.UserEndPoint.Address.ToString(), Context.WebSocket));
            }

            _onOpen.Invoke(Context.UserEndPoint.Address.ToString());
        }

        /// <summary>When the connection is closed.</summary>
        /// <param name="e">Event arguments.</param>
        protected override void OnClose (CloseEventArgs e)
        {
            if (_hub != null && _destinationApp != Apps.None)
            {
                foreach (var connection in _hub.wsServerConnections)
                {
                    if (connection.Item1 == _destinationApp && connection.Item2 == Context.WebSocket)
                    {
                        _hub.wsServerConnections.Remove(connection);
                        break;
                    }
                }
                
                _hub.wsConnectionIps.Remove(new Tuple<string, WebSocket>(Context.UserEndPoint.Address.ToString(), Context.WebSocket));
            }
            
            // https://github.com/sta/websocket-sharp/issues/144
            var targetType = typeof(WebSocketBehavior);
            var base_websocket = targetType.GetField("_websocket", BindingFlags.Instance | BindingFlags.NonPublic);
            base_websocket.SetValue(this, null);
            
            _onClose.Invoke(Context.UserEndPoint.Address.ToString());
        }

        /// <summary>When a message is received.</summary>
        /// <param name="e">Event arguments.</param>
        protected override void OnMessage (MessageEventArgs e)
        {
            if (e.IsBinary)
            {
                if (_onBytesMessage != null)
                {
                    _onBytesMessage.Invoke(e.RawData, Context.UserEndPoint.Address.ToString());
                }
            }
            else
            {
                if (_onStrMessage != null)
                {
                    _onStrMessage.Invoke(e.Data, Context.UserEndPoint.Address.ToString());
                }
            }
        }
        
        /// <summary>Sends a string message to the other end.</summary>
        /// <param name="message">Message to send.</param>
        public new void Send (string message)
        {
            base.Send (message);
        }

        /// <summary>Sends an array of bytes message to the other end.</summary>
        /// <param name="zipBytes">Bytes making up the zip.</param>
        public new void Send (byte[] message)
        {
            base.Send (message);
        }
        
        /// <summary>Sends a message to all connections.</summary>
        /// <param name="message">Message to send.</param>
        public void SendToAll (string message)
        {
            Sessions.Broadcast (message);
        }

        #endregion
        
    }
}