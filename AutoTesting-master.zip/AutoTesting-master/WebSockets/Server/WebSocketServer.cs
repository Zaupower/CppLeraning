using System;
using WebSocketSharp.Server;

namespace WebSockets
{
    /// <summary>This class implements a websocket server</summary>
    public class WebSocketServer
    {
        #region Variables

        /// <summary>The Web Socket Server.</summary>
        private WebSocketSharp.Server.WebSocketServer _webSocketServer;

        /// <summary>Communication manager instance</summary>
        private CommunicationManager _hub;
        
        /// <summary>Prototype of callback function to be called when new connection with a client is open</summary>
        public delegate void OnOpenFunct (string ip);
        /// <summary>Prototype of callback function to be called when when string message is received</summary>
        public delegate void OnStrMessageFunct (string message, string senderIp);
        /// <summary>Prototype of callback function to be called when when string message is received</summary>
        public delegate void OnBytesMessageFunct (byte[] message, string senderIp);
        /// <summary>Prototype of callback function to be called when a connection with a client is closed.</summary>
        public delegate void OnCloseFunct (string ip);

        #endregion

        #region Constructor
        
        /// <summary>Creates a websocket Server instance to be used by a communication manager.</summary>
        /// <param name="hub">Communication manager instance</param>
        /// <param name="port">Server port</param>
        public WebSocketServer(CommunicationManager hub, int port)
        {
            _webSocketServer = new WebSocketSharp.Server.WebSocketServer(System.Net.IPAddress.Any, port);
            _hub = hub;
        }

        /// <summary>Creates a websocket Server instance</summary>
        /// <param name="port">Server port</param>
        public WebSocketServer(int port)
        {
            _webSocketServer = new WebSocketSharp.Server.WebSocketServer(System.Net.IPAddress.Any, port);
        }

        #endregion

        #region Methods

        /// <summary>
        /// Adds a new communication channel to the server (multiple channels can be added).
        /// This method overload should be used when using a module specific communication channel.
        /// </summary>
        /// <param name="app">Module that is going to connect to this channel</param>
        /// <param name="address">Channel address (e.g. "/channel1")</param>
        /// <param name="OnOpen">OnOpen method (called when new client connection is made through this channel)</param>
        /// <param name="OnStrMessage">OnStringMessage method</param>
        /// <param name="OnBytesMessage">OnBytesMessage method</param>
        /// <param name="OnClose">OnClose method</param>
        public WebSocketServer AddChannel(Apps app, string address, OnOpenFunct OnOpen, OnStrMessageFunct OnStrMessage, OnBytesMessageFunct OnBytesMessage, OnCloseFunct OnClose)
        {
#pragma warning disable CS0618 // TODO WebSocketServer.AddWebSocketService<TBehavior>(string, Func<TBehavior>) is obsolete
            _webSocketServer.AddWebSocketService<SuperBehavior> (address, () => new SuperBehavior(_hub, app, OnOpen, OnStrMessage, OnBytesMessage, OnClose));
#pragma warning restore CS0618
            return this;
        }
        
        /// <summary>
        /// Adds a new communication channel to the server
        /// This method overload should be used when using a generic communication channel, with no specific module associated (e.g. multiple modules connect to the same channel address).
        /// </summary>
        /// <param name="address">Channel address (e.g. "/channel1")</param>
        /// <param name="OnOpen">OnOpen method (called when new client connection is made through this channel)</param>
        /// <param name="OnStrMessage">OnStringMessage method</param>
        /// <param name="OnBytesMessage">OnBytesMessage method</param>
        /// <param name="OnClose">OnClose method</param>
        public WebSocketServer AddChannel<TBehavior>(string address, Func<TBehavior> creator) where TBehavior : WebSocketBehavior, new()
        {
#pragma warning disable CS0618 // TODO WebSocketServer.AddWebSocketService<TBehavior>(string, Func<TBehavior>) is obsolete
            _webSocketServer.AddWebSocketService<TBehavior> (address, creator);
#pragma warning restore CS0618
            return this;
        }

        /// <summary>Starts the websocket server</summary>
        public void Start ()
        {
            try
            {
                _webSocketServer.Start ();
            }
            catch (Exception e)
            {
                Console.WriteLine ("Could not start websocket server in address " + _webSocketServer.Address + ": " + e.Message + " " + e.InnerException.Message);
            }

        }
        
        /// <summary>Stops the websocket server.</summary>
        public void Stop ()
        {
            _webSocketServer.Stop ();
        }
        
        #endregion
    }
}