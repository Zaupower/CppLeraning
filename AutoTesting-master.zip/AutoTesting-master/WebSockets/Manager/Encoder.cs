using System.Collections.Generic;

namespace WebSockets
{
    public static class Encoder
    {
        public static string EncodeWebSocketMessage(List<string> components)
        {
            string result = "";
            foreach (var component in components)
            {
                result += EscapeString(component) + ";";
            }

            return result;
        }
        
        private static string EscapeString(string input)
        {
            return input.Replace(";", "\\;");
        }
        
    }
}