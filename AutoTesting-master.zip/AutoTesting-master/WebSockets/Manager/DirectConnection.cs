namespace WebSockets
{
    /// <summary>Stores information about another Communication Manager,
    /// for when two Communication Managers want to communicate directly.</summary>
    public class DirectConnection
    {
        /// <summary>Code to run when the connection is established.</summary>
        public WebSocketServer.OnOpenFunct onOpen { get; }
        
        /// <summary>Code to run when a string message is received.</summary>
        public WebSocketServer.OnStrMessageFunct onStrMessage { get; }
        
        /// <summary>Code to run when a bytes message is received.</summary>
        public WebSocketServer.OnBytesMessageFunct onBytesMessage { get; }
        
        /// <summary>Code to run when the connection is closed.</summary>
        public WebSocketServer.OnCloseFunct onClose { get; }

        /// <summary>The manager belonging to the other module.</summary>
        public CommunicationManager manager = null;

        /// <summary>Initializes a new instance of the <see cref="WebSockets.DirectConnection"/> class.</summary>
        /// <param name="onOpen">Code to run when the connection is established.</param>
        /// <param name="onStrMessage">Code to run when a string message is received.</param>
        /// <param name="onBytesMessage">Code to run when a bytes message is received.</param>
        /// <param name="onClose">Code to run when the connection is closed.</param>
        public DirectConnection(WebSocketServer.OnOpenFunct onOpen, WebSocketServer.OnStrMessageFunct onStrMessage,
            WebSocketServer.OnBytesMessageFunct onBytesMessage, WebSocketServer.OnCloseFunct onClose)
        {
            this.onOpen = onOpen;
            this.onStrMessage = onStrMessage;
            this.onBytesMessage = onBytesMessage;
            this.onClose = onClose;
        }
    }
}