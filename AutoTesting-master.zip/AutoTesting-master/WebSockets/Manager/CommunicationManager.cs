using System;
using System.Collections.Generic;
using System.Linq;
using WebSocketSharp;

namespace WebSockets
{
    /// <summary>
    /// This class implements a communications manager.
    /// It stores the websocket clients/servers instances and all the external Apps connections to those clients/servers.
    /// </summary>
    public class CommunicationManager
    {
        #region Variables

        /// <summary>Stores all the Apps connected to the websocket Server and respective endpoint.</summary>
        public List<Tuple<Apps, WebSocket>> wsServerConnections;

        /// <summary>Stores all the websocket Clients and the respective Apps they're connected to.</summary>
        public Dictionary<Apps, WebSocketClient> wsClientConnections;

        /// <summary>Stores all direct connections to other Apps.</summary>
        public Dictionary<Apps, DirectConnection> directConnections = new Dictionary<Apps, DirectConnection>();

        /// <summary>Stores the IP's of every websocket connection (both for the wsServer and wsClients).</summary>
        public List<Tuple<string, WebSocket>> wsConnectionIps = new List<Tuple<string, WebSocket>>();

        List<WebSocketClient> wsClientList = new List<WebSocketClient>();
        List<WebSocketServer> wsServerList = new List<WebSocketServer>();

        #endregion
        
        
        #region Constructor

        public CommunicationManager()
        {
            wsServerConnections = new List<Tuple<Apps, WebSocket>>();
            wsClientConnections = new Dictionary<Apps, WebSocketClient>();
            directConnections = new Dictionary<Apps, DirectConnection>();
        }

        #endregion


        #region Client Methods

        /// <summary>
        /// Creates a Websocket Client to communicate with the specified App (e.g. Emu, Sas, Ausy)
        /// </summary>
        /// <param name="destinationApp">App to communicate with</param>
        /// <returns>WebSocketClient instance</returns>
        public WebSocketClient CreateWsClient(Apps destinationApp)
        {
            if (wsClientConnections.ContainsKey(destinationApp))
            {
                Console.WriteLine("[INFO] A websocket client for the App " + destinationApp + " already exists. It will be replaced by the new one (The old one will be disconnected and deleted).");
                StopWsClient(destinationApp);
            }
            WebSocketClient wsClient = new WebSocketClient(this);
            wsClientList.Add(wsClient);
            wsClientConnections.Add(destinationApp, wsClient);

            return wsClient;
        }

        /// <summary>Disconnects all the Websocket clients and deletes them from the connections dictionary</summary>
        public void StopAllWsClients()
        {
            foreach (var client in wsClientList)
            {
                client?.Disconnect();
            }
            wsClientList.Clear();
            wsClientConnections.Clear();
        }

        /// <summary>Disconnects the websocket client associated with the specified App.</summary>
        /// <param name="destinationApp">App associated with the websocket client.</param>
        public void StopWsClient(Apps destinationApp)
        {
            WebSocketClient client;
            if (wsClientConnections.TryGetValue(destinationApp, out client))
            {
                client?.Disconnect();
                wsClientList.Remove(client);
                wsClientConnections.Remove(destinationApp);
            }
        }

        /// <summary>Check if websocket client is connected (alive).</summary>
        /// <param name="destinationApp">App associated with the websocket client.</param>
        /// <returns></returns>
        public bool IsWsClientConnected(Apps destinationApp)
        {
            WebSocketClient client;
            if (wsClientConnections.TryGetValue(destinationApp, out client))
                return client != null && client.IsAlive;
            
            return false;
        }
        
        #endregion

        
        #region Server Methods

        /// <summary>Creates a Websocket Server</summary>
        /// <param name="port">Port</param>
        /// <returns>WebSocketServer instance</returns>
        public WebSocketServer CreateWsServer(int port)
        {
            if (wsServerList.Count > 0)
            {
                Console.WriteLine("A websocket server has already been created. There can only be one server running (add channels to the server for multiple communication lines)");
                return null;
            }
            WebSocketServer wsServer = new WebSocketServer(this, port);
            wsServerList.Add(wsServer);
            return wsServer;
        }
        
        /// <summary>Stops the websocket server</summary>
        public void StopWsServer()
        {
            foreach (var server in wsServerList)
            {
                server.Stop();
                wsServerList.Remove(server);
            }
            wsServerConnections.Clear();
        }
        
        public void AddWsServerConnection(Apps app, WebSocket wsClient)
        {
            wsServerConnections.Add(new Tuple<Apps, WebSocket>(app, wsClient));
        }

        #endregion


        #region General Methods
        
        /// <summary>Sends a message to a App</summary>
        /// <param name="destinationApp">App to which the message is sent.</param>
        /// <param name="message">String Message</param>
        public void Send(Apps destinationApp, string message)
        {
            if (directConnections.ContainsKey(destinationApp))
            {
                directConnections[destinationApp].manager.ReceiveDirectly(this, message);
                return;
            }

            foreach (var connection in wsServerConnections)
            {
                if (connection.Item1 == destinationApp)
                {
                    connection.Item2.Send(message);
                    return;
                }
            }
            
            if (wsClientConnections.ContainsKey(destinationApp))
            {
                wsClientConnections[destinationApp].Send(message);
                return;
            }
            
            Console.WriteLine("Can't send string websocket message: \"" + message +"\". There's no connection with the App " + destinationApp.ToString());
        }

        /// <summary>Sends a message to a App</summary>
        /// <param name="destinationApp">App to which the message is sent.</param>
        /// <param name="message">Bytes Message</param>
        public void Send(Apps destinationApp, byte[] message)
        {
            if (directConnections.ContainsKey(destinationApp))
            {
                directConnections[destinationApp].manager.ReceiveDirectly(this, message);
                return;
            }
            
            foreach (var connection in wsServerConnections)
            {
                if (connection.Item1 == destinationApp)
                {
                    connection.Item2.Send(message);
                    return;
                }
            }
            
            if (wsClientConnections.ContainsKey(destinationApp))
            {
                wsClientConnections[destinationApp].Send(message);
                return;
            }
            
            Console.WriteLine("Can't send bytes websocket message. There's no connection with the App " + destinationApp.ToString());
        }

        /// <summary>Sends a message to any connections that match the given IP.</summary>
        /// <param name="ip">IP to send to.</param>
        /// <param name="message">Message to send.</param>
        public void Send(string ip, string message)
        {
            try
            {
                bool found = false;

                List<WebSocket> wsList = new List<WebSocket>();

                foreach (Tuple<string, WebSocket> connection in wsConnectionIps)
                {
                    if (connection.Item1 == ip)
                    {
                        wsList.Add(connection.Item2);
                        found = true;
                    }
                }

                foreach (WebSocket ws in wsList)
                {
                    ws.Send(message);
                }

                if (!found)
                {
                    Console.WriteLine("Can't send string message to IP " + ip +
                                      " since there are no connections with that IP.");
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine("Can't send string message to IP " + ip + ". Exception: " + exception);
                Console.WriteLine(exception.StackTrace);
            }
        }
        
        /// <summary>Sends a message to any connections that match the given IP.</summary>
        /// <param name="ip">IP to send to.</param>
        /// <param name="message">Bytes Message</param>
        public void Send(string ip, byte[] message)
        {
            bool found = false;
            foreach (Tuple<string,WebSocket> connection in wsConnectionIps)
            {
                if (connection.Item1 == ip)
                {
                    connection.Item2.Send(message);
                    found = true;
                }
            }

            if (!found)
            {
                Console.WriteLine("Can't send bytes message to IP " + ip + " since there are no connections with that IP.");
            }
        }
        
        /// <summary>Sends a message to all Apps</summary>
        /// <param name="message">String Message</param>
        public void SendToAll(string message)
        {
            foreach (var connection in directConnections)
            {
                connection.Value.manager.ReceiveDirectly(this, message);
            }
            foreach (var connection in wsServerConnections)
            {
                connection.Item2.Send(message);
            }
            foreach (var connection in wsClientConnections)
            {
                connection.Value.Send(message);
            }
        }

        /// <summary>Sends a message to all Apps</summary>
        /// <param name="message">Bytes Message</param>
        public void SendToAll(byte[] message)
        {
            foreach (var connection in directConnections)
            {
                connection.Value.manager.ReceiveDirectly(this, message);
            }
            foreach (var connection in wsServerConnections)
            {
                connection.Item2.Send(message);
            }
            foreach (var connection in wsClientConnections)
            {
                connection.Value.Send(message);
            }
        }
        
        #endregion
        
        
        #region Direct connection

        /// <summary>Adds data for a direct connection to the list of direct connections.</summary>
        /// <param name="app">App to connect to.</param>
        /// <param name="onOpen">Code to run when the connection is established.</param>
        /// <param name="onStrMessage">Code to run when a string message is received.</param>
        /// <param name="onBytesMessage">Code to run when a bytes message is received.</param>
        /// <param name="onClose">Code to run when the connection is closed.</param>
        public void AddDirectConnection(Apps app, WebSocketServer.OnOpenFunct onOpen,
            WebSocketServer.OnStrMessageFunct onStrMessage, WebSocketServer.OnBytesMessageFunct onBytesMessage,
            WebSocketServer.OnCloseFunct onClose)
        {
            DirectConnection d = new DirectConnection(onOpen, onStrMessage, onBytesMessage, onClose);
            directConnections.Add(app, d);
        }

        /// <summary>Establishes a direct connection with another App's Communication Manager.
        /// This establishes a reciprocal connection too.</summary>
        /// <param name="thisApp">App that the current Communication Manager is about.</param>
        /// <param name="otherApp">App of the other Communication Manager.</param>
        /// <param name="otherManager">The other Communication Manager.</param>
        public void EstablishDirectConnection(Apps thisApp, Apps otherApp,
            CommunicationManager otherManager)
        {
            directConnections[otherApp].manager = otherManager;
            otherManager.directConnections[thisApp].manager = this;

            directConnections[otherApp].onOpen?.Invoke("");
            otherManager.directConnections[thisApp].onOpen?.Invoke("");
        }

        /// <summary>Makes the Communication Manager receive a message directly from another one,
        /// instead of receiving it through a WebSocket.</summary>
        /// <param name="sender">Communication Manager that sent the message.</param>
        /// <param name="message">The message.</param>
        private void ReceiveDirectly(CommunicationManager sender, string message)
        {
            foreach (KeyValuePair<Apps,DirectConnection> d in directConnections)
            {
                if (d.Value.manager == sender)
                {
                    d.Value.onStrMessage?.Invoke(message, "");
                }
            }
        }

        /// <summary>Makes the Communication Manager receive a message directly from another one,
        /// instead of receiving it through a WebSocket.</summary>
        /// <param name="sender">Communication Manager that sent the message.</param>
        /// <param name="bytes">The message.</param>
        private void ReceiveDirectly(CommunicationManager sender, byte[] bytes)
        {
            foreach (KeyValuePair<Apps,DirectConnection> d in directConnections)
            {
                if (d.Value.manager == sender)
                {
                    d.Value.onBytesMessage?.Invoke(bytes, "");
                }
            }
        }

        /// <summary>Removes all direct connections from the list of direct connections.</summary>
        public void RemoveAllDirectConnections()
        {
            foreach (var client in wsClientList)
            {
                client?.Disconnect();
            }
            directConnections.Clear();
        }
        #endregion


    }
}