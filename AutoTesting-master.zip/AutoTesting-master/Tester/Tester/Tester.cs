﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using AutoTestingService;
using AutoTestingService.Shared;
namespace Tester
{
	class Tester
	{

		static List<string> bingoEventsList = new List<string> {
				"[2020-07-24 16:05:10.345][GAMEPLAY][INFO]: Balls 47,14,88,67,80,40,19,28,1,61,13,73,86,79,42,9,56,33,81,76,25,20,7,83,29,43,31,36,62,58",
				"[2020-07-24 16:05:10.345][GAMEPLAY][INFO]: GameStart number: 7, credits: 937, bet: 20, denomination: P1, AUTO: false.",
				"[2020-07-24 16:05:14.975][GAMEPLAY][INFO]: GameEnd credits: 957",
				"[2020-07-24 16:05:10.304][BUTTONS][INFO]: ExtraBallChance",
				"[2020-07-24 16:05:10.304][BUTTONS][INFO]: ExtraBallPlayed value: 1, cost: 10",
				"[2020-07-24 16:05:10.304][BUTTONS][INFO]: ExtraBallValueExceeded",
				"[2020-07-24 16:05:10.304][BUTTONS][INFO]: WildBallChance",
				"[2020-07-24 16:05:10.304][BUTTONS][INFO]: WildBallPlayed 1",
				"[2020-07-24 16:05:12.927][GAMEPLAY][INFO]: PrizeGot card: 10, index: 1, value: 3",
				"[2020-07-24 16:05:14.974][GAMEPLAY][INFO]: PrizesWon value: 40",
				"[2020-07-24 16:05:10.304][BUTTONS][INFO]: ProgressiveWon value: 50",
				"[2020-07-24 16:05:10.304][BUTTONS][INFO]: Jackpot Won is: ",
				"[2020-07-24 16:05:10.304][BUTTONS][INFO]: PressedButtonPlay",

				"BonusChance",
				"BonusOptionPlayed id: 1, value: 2",
				"BonusWon 1",
				"[BONUS VALUES][INFO]: asd",

				"HandpayAllowed validation number: 123, validation code: 456, value to pay: 789",
				"HandpayDone validation number: 123, value paid: 456",
				"CreditsTransfer In value: 10(",
				"CreditsTransfer Invalue: 20( ",
				"CreditsTransfer Outvalue: 1543(",
				"[2020-01-20 12:26:43.806][ACCOUNTING][INFO]: CreditsTransfer Out value: 4444 (cashable = 1543, restricted = 0, non_restricted = 0)",

				"CardsChanged",
				"CardValues 1: 50",

				"MysteryAnnounce time left: 30, thermometer: 100",
				"MysteryConfirmed",
				"MysteryEnter prize: 1, container values: [100]",
				"MysteryStart time: 30",
				"MysteryObject sequence: 5, number: 10",
				"MysteryEnd",
				"MysteryWon value: 100",
				"MysteryLost",
				"Bonus1Confirmed",
				"Bonus1Enter id: PigBoom, prizes: Gold: 1 Silver: 2 Bronze: 3",
				"Bonus1Won id: PigBoom, prize: 100",
				"Bonus1End",

				"ProgBonusAskServer",
				"ProgBonusResetEligibility",
				"ProgBonusServerDidntWin",
				"ProgBonusServerWon",
				"ProgBonusStatus min plays: 1, min cars opened: 2, server status: 3",
				"ProgBonusWon asd, value: 2, type: 3",
				
				"CashierType  ",
				"DeviceInfo  ",
				"DoorClosed",

				"PressedButtonAdmin",
				"PressedButtonAuto",
				"PressedButtonBetMax",
				"PressedButtonCardLess",
				"PressedButtonCardMore",
				"PressedButtonCashout",
				"PressedButtonChangeCards",
				"PressedButtonHelp",
				"PressedButtonOpenAllCards",
				"PressedButtonOpenExtra",
				"PressedButtonPlay",
				"PressedButtonSpeedUp",

				"ApplicationError message: APPERROR",
				"DebugMessage DEBUG",
				"InfoMessage INFO",
				"WarningMessage WARNING",
				"ErrorMessage ERROR",
				"CriticalMessage CRITICAL",
				"MachineBlocked exception: MACHINEBLOCKED",
				"[MACHINEBLOCKED][INFO]: 0",
				"CommunicationErrorDetected",
				"CommunicationErrorResolved",
				"MysteryConnectionLost",
				"MysteryPowerFailure",
				"AlesisMessage message: ALESISMESSAGE",
				"GameStartTimeout state: STATE",
				"OpenBallError ERROR",
				"BacktraceResult RESULT",
				"MachineShutdownSignal signal SIGNAL",
				"Migration failed",
				"MD5 file verification FAILED",
				"CRC32 check failed on copy 10 of block 1",
				"CRC32 check failed on all 50 copies of block 1",
				"CRC32 check failed on at least 20 copy/ies of block 1",
				"Expecting checksum CHECKSUM. Aborting.",
				"GameStateFileError",
				"GameStateSyncError",
				"MathDebugInReleaseError",
				"MachineStartup STARTUP",
				"MachineShutdown",
				"GameStateFileError",
				"Switching to game: GAME",
				"ForcedBalls",
				"ForcedCards",
				"MathState STATE",
				"ConfigSoundEnter"
			};

		static List<string> slotsEventsList = new List<string> {
				"[2020-07-24 16:05:10.345][GAMEPLAY][INFO]: GameStart number: 7, credits: 937, bet: 20, denomination: P1",
				"[2019-04-16 15:00:38.886][GAMEPLAY][INFO]: GameStartSpins Game Mode: 50, Level Bet: 1, Auto: OFF",
				"[2020-07-24 16:05:14.975][GAMEPLAY][INFO]: GameEnd credits: 957",
				"[2019-04-16 15:00:38.886][GAMEPLAY][INFO]: Reel End Position 15,193,196,204,255",
				"[2020-07-24 16:05:14.974][GAMEPLAY][INFO]: PrizesWon value: 40",
				"[2019-04-16 15:03:55.665][GAMEPLAY][INFO]: PrizesWon total 2, line 7: [2,1,-1,-1,-1], symbol 9, value 2, FreeSpins false, Bonus false",
				"[2020-07-24 16:05:10.304][BUTTONS][INFO]: ProgressiveWon value: 50",
				"[2020-07-24 16:05:10.304][BUTTONS][INFO]: Jackpot Won is: 1",
				"[2019-04-16 15:04:03.413][GAMEPLAY][INFO]: Wild Type: Sticky, Stripe: 3, Position: 2",
				"Big Win Value: 10",
				"[2019-04-16 15:03:32.278][GAMEPLAY][INFO]: Free Spins - Math Game Mode: 3",
				"[2019-04-16 15:03:54.988][GAMEPLAY][INFO]: FreeSpinsChoice 0;0;6;1",
				"[2019-04-16 15:03:54.991][GAMEPLAY][INFO]: NumberFreeSpins 6;6",
				"Wild Multiplier: 1|2|3",
				"[2019-04-16 15:04:31.706][GAMEPLAY][INFO]: TotalFreeSpinWon 1316",
				"BonusChance",
				"BonusOptionPlayed id: 1, value: 2",
				"BonusWon 1",
				"[2019-04-16 17:28:17.517][GAMEPLAY][INFO]: EasyLink - MathPrize: 0",
				"[2019-04-16 17:28:17.518][GAMEPLAY][INFO]: EasyLink - Reel End Symbols: [156,650,9,-1,211,211,211,-1,-1,-1,213,-1,-1]",
				"[2019-04-16 17:28:31.538][GAMEPLAY][INFO]: EasyLink - Remaining Plays 7",
				"HandpayAllowed validation number: 123, validation code: 456, value to pay: 789",
				"HandpayDone validation number: 123, value paid: 456",
				"CreditsTransfer In value: 10 (",
				"[2020-01-20 12:26:43.806][ACCOUNTING][INFO]: CreditsTransfer Out value: 4444 (cashable = 1543, restricted = 0, non_restricted = 0)",
				"MysteryAnnounce time left: 30, thermometer: 100",
				"MysteryConfirmed",
				"MysteryEnter prize: 1, container values: [100]",
				"MysteryStart time: 30",
				"MysteryObject sequence: 5, number: 10",
				"MysteryEnd",
				"MysteryWon value: 100",
				"MysteryLost",
				"Bonus1Confirmed",
				"Bonus1Enter id: PigBoom, prizes: Gold: 1 Silver: 2 Bronze: 3",
				"Bonus1Won id: PigBoom, prize: 100",
				"Bonus1End",
				"PressedButtonAdmin",
				"PressedButtonAuto",
				"PressedButtonBetMax",
				"PressedButtonCashout",
				"PressedButtonHelp",
				"PressedButtonPlay",
				"PressedButtonSpeedUp",
				"Migration failed",
				"MD5 file verification FAILED",
				"ApplicationError message: APPERROR",
				"CommunicationErrorDetected",
				"CommunicationErrorResolved",
				"MachineBlocked exception: MACHINEBLOCKED",
				"[MACHINEBLOCKED][INFO]: 0",
				"DoorClosed",
				"MysteryConnectionLost",
				"MysteryPowerFailure",
				"MachineStartup STARTUP",
				"MachineShutdown",
				"Switching to game: GAME",
				"ConfigSoundEnter",
				"[2021-01-07 10:35:15.812][BASICGAME][INFO]: Type: GAME, Bet: 100, Duration: 500ms MANUAL AUTO Won: [Cash: 0, Points: 99] At Start: [Credits: 100, Bank: 10, Reserve: 0]",
				"[2021-01-07 10:35:21.911][BASICGAME][INFO]: Type: RISK , Points: 2883 MANUAL Won: [Cash: 2884, Points: 0] At Start: [Credits: 0, Bank: 10, Reserve: 0]"
			};

		static public string CurrentTime;
		
		//Read events from the list defined above. Writes them one second at a time to the GameLogTests file
		static void WriteEventsToLogFromList(List<string> events)
		{
			CurrentTime = DateTime.Now.ToString("HH:mm:ss");
			string finalLogPath = Path.Combine(Directory.GetCurrentDirectory(), "GameLogTest.txt");
			using (StreamWriter outputFile = new StreamWriter(finalLogPath) {AutoFlush = true})
			{
				foreach (string i in events)
				{
					Console.WriteLine("Writing to logs: " + i);
					outputFile.WriteLine(i);
					Thread.Sleep(1000);
				}
			}
		}

		//Read events from a .txt file named EventsFile.txt. Writes them one second at a time to the GameLogTests file
		static void WriteEventsToLogFromFile(string filePath)
		{
			string finalLogPath = Path.Combine(Directory.GetCurrentDirectory(), "GameLogTest.txt");
			string readLine;
			var tempList = new List<string>();

			using (var inputFile = new StreamReader(filePath))
			{
				while ((readLine = inputFile.ReadLine()) != null)
				{
					tempList.Add(readLine);
				}
			}

			using (StreamWriter outputFile = new StreamWriter(finalLogPath))
			{
				foreach (string i in tempList)
				{
					outputFile.WriteLine(i);
					Thread.Sleep(1000);
				}
			}
		}

		//Using reading from events defined as standard
		public static void Main(string[] args)
		{
			Console.WriteLine("Press 'b' to test bingo events and 's' to test slots events.");
			switch (Console.ReadLine())
			{
				case "bingo":
				case "b":
					WriteEventsToLogFromList(bingoEventsList);
					Console.WriteLine("The test for bingo events {0}.", ScriptLogReader.Instance.CompareEventLists(LogType.Bingo) ? "passed" : "failed");
					break;
				case "slots":
				case "s":
					WriteEventsToLogFromList(slotsEventsList);
					Console.WriteLine("The test for slots events {0}.", ScriptLogReader.Instance.CompareEventLists(LogType.Slots) ? "passed" : "failed");
					break;
			}
		}
	}
}
