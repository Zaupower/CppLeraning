﻿events.AddCallback("GameStart", onGameStart);
events.AddCallback("InPlay", onInPlay);
events.AddCallback("GameEnd", onGameEnd);
events.AddCallback("ExtraBallChance", onExtraBallChance);
events.AddCallback("ExtraBallPlayed", onExtraBallPlayed);
events.AddCallback("ExtraBallValueExceeded", onExtraBallValueExceeded);
events.AddCallback("WildBallChance", onWildBallChance);
events.AddCallback("WildBallPlayed", onWildBallPlayed);
events.AddCallback("PrizeGot", onPrizeGot);
events.AddCallback("PrizesWon", onPrizesWon);
events.AddCallback("ProgressiveWon", onProgressiveWon);
events.AddCallback("MultiJackpotWon", onMultiJackpotWon);


events.AddCallback("BonusChance", onBonusChance);
events.AddCallback("BonusOptionPlayed", onBonusOptionPlayed);
events.AddCallback("BonusWon", onBonusWon);


events.AddCallback("HandpayAllowed", onHandpayAllowed);
events.AddCallback("HandpayDone", onHandpayDone);
events.AddCallback("CashIn", onCashIn);
events.AddCallback("CashOut", onCashOut);


events.AddCallback("CardsChanged", onCardsChanged);
events.AddCallback("CardValues", onCardValues);


events.AddCallback("MysteryAnnounce", onMysteryAnnounce);
events.AddCallback("MysteryConfirmed", onMysteryConfirmed);
events.AddCallback("MysteryEnter", onMysteryEnter);
events.AddCallback("MysteryStart", onMysteryStart);
events.AddCallback("MysteryObject", onMysteryObject);
events.AddCallback("MysteryEnd", onMysteryEnd);
events.AddCallback("MysteryWon", onMysteryWon);
events.AddCallback("MysteryLost", onMysteryLost);
events.AddCallback("PigBoomConfirmed", onPigBoomConfirmed);
events.AddCallback("PigBoomEnter", onPigBoomEnter);
events.AddCallback("PigBoomWon", onPigBoomWon);
events.AddCallback("PigBoomEnd", onPigBoomEnd);


events.AddCallback("ProgBonusAskServer", onProgBonusAskServer);
events.AddCallback("ProgBonusResetEligibility", onProgBonusResetEligibility);
events.AddCallback("ProgBonusServerDidntWin", onProgBonusServerDidntWin);
events.AddCallback("ProgBonusServerWon", onProgBonusServerWon);
events.AddCallback("ProgBonusStatus", onProgBonusStatus);
events.AddCallback("ProgBonusWon", onProgBonusWon);


events.AddCallback("CashierType", onCashierType);
events.AddCallback("DeviceInfo", onDeviceInfo);
events.AddCallback("DoorClosed", onDoorClosed);


events.AddCallback("PressedButtonAdmin", onPressedButtonAdmin);
events.AddCallback("PressedButtonAuto", onPressedButtonAuto);
events.AddCallback("PressedButtonBetMax", onPressedButtonBetMax);
events.AddCallback("PressedButtonCardLess", onPressedButtonCardLess);
events.AddCallback("PressedButtonCardMore", onPressedButtonCardMore);
events.AddCallback("PressedButtonCashout", onPressedButtonCashout);
events.AddCallback("PressedButtonChangeCards", onPressedButtonChangeCards);
events.AddCallback("PressedButtonHelp", onPressedButtonHelp);
events.AddCallback("PressedButtonOpenAllCards", onPressedButtonOpenAllCards);
events.AddCallback("PressedButtonOpenExtra", onPressedButtonOpenExtra);
events.AddCallback("PressedButtonPlay", onPressedButtonPlay);
events.AddCallback("PressedButtonSpeedUp", onPressedButtonSpeedUp);


events.AddCallback("ApplicationError", onApplicationError);
events.AddCallback("DebugMessage", onDebugMessage);
events.AddCallback("InfoMessage", onInfoMessage);
events.AddCallback("WarningMessage", onWarningMessage);
events.AddCallback("ErrorMessage", onErrorMessage);
events.AddCallback("CriticalMessage", onCriticalMessage);
events.AddCallback("MachineBlocked", onMachineBlocked);
events.AddCallback("OutOfService", onOutOfService);
events.AddCallback("CommunicationErrorDetected", onCommunicationErrorDetected);
events.AddCallback("CommunicationErrorResolved", onCommunicationErrorResolved);
events.AddCallback("MysteryConnectionLost", onMysteryConnectionLost);
events.AddCallback("MysteryPowerFailure", onMysteryPowerFailure);
events.AddCallback("AlesisMessage", onAlesisMessage);
events.AddCallback("GameStartTimeout", onGameStartTimeout);
events.AddCallback("OpenBallError", onOpenBallError);
events.AddCallback("BacktraceResult", onBacktraceResult);
events.AddCallback("MachineShutdownSignal", onMachineShutdownSignal);


events.AddCallback("MigrationFailed", onMigrationFailed);
events.AddCallback("MD5Fail", onMD5Fail);
events.AddCallback("CRCFailedBlock", onCRCFailedBlock);
events.AddCallback("CRCFailedBlockAll", onCRCFailedBlockAll);
events.AddCallback("CRCFailedBlockMulti", onCRCFailedBlockMulti);
events.AddCallback("BinaryFileModifiedError", onBinaryFileModifiedError);
events.AddCallback("GameStateFileError", onGameStateFileError);
events.AddCallback("GameStateSyncError", onGameStateSyncError);
events.AddCallback("MathDebugInReleaseError", onMathDebugInReleaseError);


events.AddCallback("MachineStartup", onMachineStartup);
events.AddCallback("MachineShutdown", onMachineShutdown);
events.AddCallback("ChangedGame", onChangedGame);
events.AddCallback("ForcedBalls", onForcedBalls);
events.AddCallback("ForcedCards", onForcedCards);
events.AddCallback("MathState", onMathState);
events.AddCallback("ConfigSoundEnter", onConfigSoundEnter);


function onGameStart(gameNumber, credits, bet, denom, auto)
{
    print("GameStart - gameNumber: " + gameNumber + ", credits: " + credits + ", bet: " + bet +  ", denom: " + denom +", auto: " + auto);
}

function onInPlay()
{
    print("InPlay");
}

function onGameEnd(credits)
{
    print("GameEnd - credits: " + credits);
}

function onExtraBallChance()
{
    print("ExtraBallChance");
}

function onExtraBallPlayed(value, cost, auto)
{
    print("ExtraBallPlayed - value: " + value + ", cost: " + cost, ", auto: " + auto);
}

function onExtraBallValueExceeded()
{
    print("ExtraBallValueExceeded");
}

function onWildBallChance()
{
    print("WildBallChance");
}

function onWildBallPlayed(number)
{
    print("WildBallPlayed - number: " + number);
}

function onPrizeGot(card, index, value)
{
    print("PrizeGot - card: " + card + ", index: " + index + ", value: " + value);
}

function onPrizesWon(value)
{
    print("PrizesWon - value: " + value);
}

function onProgressiveWon(value)
{
    print("ProgressiveWon - value: " + value);
}

function onMultiJackpotWon()
{
    print("MultiJackpotWon");
}

function onBonusChance()
{
    print("BonusChance");
}

function onBonusOptionPlayed(id, value)
{
    print("BonusOptionPlayed - id: " + id + ", value: " + value);
}

function onBonusWon(value)
{
    print("BonusWon - value: " + value);
}

function onHandpayAllowed(validationNumber, validationCode, value)
{
    print("HandpayAllowed - validationNumber: " + validationNumber + ", validationCode: " + validationCode + ", value: " + value);
}

function onHandpayDone(validationNumber, value)
{
    print("HandpayDone - validationNumber: " + validationNumber + ", value: " + value);
}

function onCashIn(value)
{
    print("CashIn - value: " + value);
}

function onCashOut(value)
{
    print("CashOut - value: " + value);
}

function onCardsChanged()
{
    print("CardsChanged");
}

function onCardValues(number, value)
{
    print("CardValues - number: " + number +  ", value: " + value);
}

function onMysteryAnnounce(time, thermometer)
{
    print("MysteryAnnounce - time: " + time + ", thermometer: " + thermometer);
}

function onMysteryConfirmed()
{
    print("MysteryConfirmed");
}

function onMysteryEnter(prize, value)
{
    print("MysteryEnter - prize: " + prize + ", value: " + value);
}

function onMysteryStart(time)
{
    print("MysteryStart - time: " + time);
}

function onMysteryObject(sequence, number)
{
    print("MysteryObject - sequence: " + sequence + ", number: " + number);
}

function onMysteryEnd()
{
    print("MysteryEnd");
}

function onMysteryWon(value)
{
    print("MysteryWon - value: " + value);
}

function onMysteryLost()
{
    print("MysteryLost");
}

function onPigBoomConfirmed()
{
    print("PigBoomConfirmed");
}

function onPigBoomEnter(gold, silver, bronze)
{
    print("PigBoomEnter - gold: " + gold + ", silver: " + silver + ", bronze: " + bronze);
}

function onPigBoomWon(prize)
{
    print("PigBoomWon - prize: " + prize);
}

function onPigBoomEnd()
{
    print("PigBoomEnd");
}

function onProgBonusAskServer()
{
    print("ProgBonusAskServer");
}

function onProgBonusResetEligibility()
{
    print("ProgBonusResetEligibility");
}

function onProgBonusServerDidntWin()
{
    print("ProgBonusServerDidntWin");
}

function onProgBonusServerWon()
{
    print("ProgBonusServerWon");
}

function onProgBonusStatus(minPlays, minCards, status)
{
    print("ProgBonusStatus - minPlays: " + minPlays + ", minCards: " + minCards + ", status: " + status);
}

function onProgBonusWon(won, value, type)
{
    print("ProgBonusWon - won: " + won + ", value: " + value + ", type: " + type);
}

function onCashierType()
{
    print("CashierType");
}

function onDeviceInfo()
{
    print("DeviceInfo");
}

function onDoorClosed()
{
    print("DoorClosed");
}

function onPressedButtonAdmin()
{
    print("PressedButtonAdmin");
}

function onPressedButtonAuto()
{
    print("PressedButtonAuto");
}

function onPressedButtonBetMax()
{
    print("PressedButtonBetMax");
}

function onPressedButtonCardLess()
{
    print("PressedButtonCardLess");
}

function onPressedButtonCardMore()
{
    print("PressedButtonCardMore");
}

function onPressedButtonCashout()
{
    print("PressedButtonCashout");
}

function onPressedButtonChangeCards()
{
    print("PressedButtonChangeCards");
}

function onPressedButtonHelp()
{
    print("PressedButtonHelp");
}

function onPressedButtonOpenAllCards()
{
    print("PressedButtonOpenAllCards");
}

function onPressedButtonOpenExtra()
{
    print("PressedButtonOpenExtra");
}

function onPressedButtonPlay()
{
    print("PressedButtonPlay");
}

function onPressedButtonSpeedUp()
{
    print("PressedButtonSpeedUp");
}

function onApplicationError(message)
{
    print("ApplicationError - message: " + message);
}

function onDebugMessage(message)
{
    print("DebugMessage - message: " + message);
}

function onInfoMessage(message)
{
    print("InfoMessage - message: " + message);
}

function onWarningMessage(message)
{
    print("WarningMessage - message: " + message);
}

function onErrorMessage(message)
{
    print("ErrorMessage - message: " + message);
}

function onCriticalMessage(message)
{
    print("CriticalMessage - message: " + message);
}

function onMachineBlocked(message)
{
    print("MachineBlocked - message: " + message);
}

function onOutOfService()
{
    print("OutOfService");
}

function onCommunicationErrorDetected()
{
    print("CommunicationErrorDetected");
}

function onCommunicationErrorResolved()
{
    print("CommunicationErrorResolved");
}

function onMysteryConnectionLost()
{
    print("MysteryConnectionLost");
}

function onMysteryPowerFailure()
{
    print("MysteryPowerFailure");
}

function onAlesisMessage(message)
{
    print("AlesisMessage - message: " + message);
}

function onGameStartTimeout(state)
{
    print("GameStartTimeout - state: " + state);
}

function onOpenBallError(error)
{
    print("OpenBallError - error: " + error);
}

function onBacktraceResult(result)
{
    print("BacktraceResult - result: " + result);
}

function onMachineShutdownSignal(signal)
{
    print("MachineShutdownSignal - signal: " + signal);
}

function onMigrationFailed()
{
    print("MigrationFailed");
}

function onMD5Fail()
{
    print("MD5Fail");
}

function onCRCFailedBlock(copy, block)
{
    print("CRCFailedBlock - copy: " + copy + ", block: " + block);
}

function onCRCFailedBlockAll(copy, block)
{
    print("CRCFailedBlockAll - copy: " + copy + ", block: " + block);
}

function onCRCFailedBlockMulti(copy, block)
{
    print("CRCFailedBlockMulti - copy: " + copy + ", block: " + block);
}

function onBinaryFileModifiedError(checksum)
{
    print("BinaryFileModifiedError - checksum: " + checksum);
}

function onGameStateFileError()
{
    print("GameStateFileError");
}

function onGameStateSyncError()
{
    print("GameStateSyncError");
}

function onMathDebugInReleaseError()
{
    print("MathDebugInReleaseError");
}

function onMachineStartup(message)
{
    print("MachineStartup - message: " + message);
}

function onMachineShutdown()
{
    print("MachineShutdown");
}

function onChangedGame(game)
{
    print("ChangedGame - game: " + game);
}

function onForcedBalls()
{
    print("ForcedBalls");
}

function onForcedCards()
{
    print("ForcedCards");
}

function onMathState(state)
{
    print("MathState - state: " + state);
}

function onConfigSoundEnter()
{
    print("ConfigSoundEnter");
}