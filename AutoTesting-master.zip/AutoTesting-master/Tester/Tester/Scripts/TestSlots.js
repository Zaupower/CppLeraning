events.AddCallback("GameStart", onGameStart);
events.AddCallback("InPlay", onInPlay);
events.AddCallback("GameEnd", onGameEnd);
events.AddCallback("ReelEnd", onReelEnd);
events.AddCallback("Wild", onWild);
events.AddCallback("FreeSpins", onFreeSpins);
events.AddCallback("FreeSpinsChoice", onFreeSpinsChoice);
events.AddCallback("FreeSpinsPlayStart", onFreeSpinsPlayStart);
events.AddCallback("FreeSpinsWildMultiplier", onFreeSpinsWildMultiplier);
events.AddCallback("FreeSpinsTotal", onFreeSpinsTotal);
events.AddCallback("PrizeWon", onPrizeWon);
events.AddCallback("ProgressiveWon", onProgressiveWon);
events.AddCallback("MultiJackpotWon", onMultiJackpotWon);
events.AddCallback("BigWin", onBigWin);
events.AddCallback("PrizesWon", onPrizesWon);


events.AddCallback("BonusChance", onBonusChance);
events.AddCallback("BonusOptionPlayed", onBonusOptionPlayed);
events.AddCallback("BonusWon", onBonusWon);
events.AddCallback("EasyLinkEntered", onEasyLinkEntered);
events.AddCallback("EasyLinkReelEnd", onEasyLinkReelEnd);
events.AddCallback("EasyLinkRemainingPlays", onEasyLinkRemainingPlays);


events.AddCallback("HandpayAllowed", onHandpayAllowed);
events.AddCallback("HandpayDone", onHandpayDone);
events.AddCallback("CashIn", onCashIn);
events.AddCallback("CashOut", onCashOut);


events.AddCallback("MysteryAnnounce", onMysteryAnnounce);
events.AddCallback("MysteryConfirmed", onMysteryConfirmed);
events.AddCallback("MysteryEnter", onMysteryEnter);
events.AddCallback("MysteryStart", onMysteryStart);
events.AddCallback("MysteryObject", onMysteryObject);
events.AddCallback("MysteryEnd", onMysteryEnd);
events.AddCallback("MysteryWon", onMysteryWon);
events.AddCallback("MysteryLost", onMysteryLost);
events.AddCallback("PigBoomConfirmed", onPigBoomConfirmed);
events.AddCallback("PigBoomEnter", onPigBoomEnter);
events.AddCallback("PigBoomWon", onPigBoomWon);
events.AddCallback("PigBoomEnd", onPigBoomEnd);


events.AddCallback("PressedButtonAdmin", onPressedButtonAdmin);
events.AddCallback("PressedButtonAuto", onPressedButtonAuto);
events.AddCallback("PressedButtonBetMax", onPressedButtonBetMax);
events.AddCallback("PressedButtonCashout", onPressedButtonCashout);
events.AddCallback("PressedButtonHelp", onPressedButtonHelp);
events.AddCallback("PressedButtonPlay", onPressedButtonPlay);
events.AddCallback("PressedButtonSpeedUp", onPressedButtonSpeedUp);


events.AddCallback("ApplicationError", onApplicationError);
events.AddCallback("MachineBlocked", onMachineBlocked);
events.AddCallback("OutOfService", onOutOfService);
events.AddCallback("CommunicationErrorDetected", onCommunicationErrorDetected);
events.AddCallback("CommunicationErrorResolved", onCommunicationErrorResolved);
events.AddCallback("MysteryConnectionLost", onMysteryConnectionLost);
events.AddCallback("MysteryPowerFailure", onMysteryPowerFailure);
events.AddCallback("AlesisMessage", onAlesisMessage);
events.AddCallback("GameStartTimeout", onGameStartTimeout);
events.AddCallback("BacktraceResult", onBacktraceResult);
events.AddCallback("MachineShutdownSignal", onMachineShutdownSignal);

events.AddCallback("DoorClosed", onDoorClosed);
events.AddCallback("MigrationFailed", onMigrationFailed);
events.AddCallback("MD5Fail", onMD5Fail);


events.AddCallback("MachineStartup", onMachineStartup);
events.AddCallback("MachineShutdown", onMachineShutdown);
events.AddCallback("ChangedGame", onChangedGame);
events.AddCallback("ConfigSoundEnter", onConfigSoundEnter);


events.AddCallback("BasicGameBet", onBasicGameBet);
events.AddCallback("BasicGameRisk", onBasicGameRisk);


function onGameStart(gameNumber, credits, bet, denom)
{
    print("GameStart - gameNumber: " + gameNumber + ", credits: " + credits + ", bet: " + bet +  ", denom: " + denom);
}

function onInPlay(mode, bet, auto)
{
    print("InPlay - mode: " + mode + ", bet: " + bet + ", auto: " + auto);
}

function onGameEnd(credits)
{
    print("GameEnd - credits: " + credits);
}

function onReelEnd(position)
{
    print("ReelEnd - position: " + position);
}

function onPrizesWon(value)
{
    print("PrizesWon - value: " + value);
}

function onPrizeWon(total, line, symbol, value, freespins, bonus)
{
    print("PrizeWon - total: " + total + ", line: " + line + ", symbol: " + symbol + ", value: " + value + ", freespins: " + freespins + ", bonus: " + bonus);
}

function onProgressiveWon(value)
{
    print("ProgressiveWon - value: " + value);
}

function onMultiJackpotWon(value)
{
    print("MultiJackpotWon - value: " + value);
}

function onWild(type, stripe, position)
{
    print("Wild - type: " + type + ", stripe: " + stripe + ", position: " + position);
}

function onBigWin(value)
{
    print("BigWin - value: " + value);
}

function onFreeSpins(mode)
{
    print("FreeSpins - mode: " + mode);
}

function onFreeSpinsChoice(choice)
{
    print("FreeSpinsChoice - choice: " + choice);
}

function onFreeSpinsPlayStart(value1, value2)
{
    print("FreeSpinsPlayStart - value1: " + value1 + ", value2: " + value2);
}

function onFreeSpinsWildMultiplier(value1,value2,value3)
{
    print("FreeSpinsWildMultiplier - value1: " + value1 + ", value2: " + value2 + ", value3: " + value3);
}

function onFreeSpinsTotal(value)
{
    print("FreeSpinsTotal - value: " + value);
}

function onBonusChance()
{
    print("BonusChance");
}

function onBonusOptionPlayed()
{
    print("BonusOptionPlayed");
}

function onBonusWon()
{
    print("BonusWon");
}

function onEasyLinkEntered(prize)
{
    print("EasyLinkEntered - prize: " + prize);
}

function onEasyLinkReelEnd(symbols)
{
    print("EasyLinkReelEnd - symbols: " + symbols);
}

function onEasyLinkRemainingPlays(plays)
{
    print("EasyLinkRemainingPlays - plays: " + plays);
}

function onHandpayAllowed(validationNumber, validationCode, value)
{
    print("HandpayAllowed - validationNumber: " + validationNumber + ", validationCode: " + validationCode + ", value: " + value);
}

function onHandpayDone(validationNumber, value)
{
    print("HandpayDone - validationNumber: " + validationNumber + ", value: " + value);
}

function onCashIn(value)
{
    print("CashIn - value: " + value);
}

function onCashOut(value)
{
    print("CashOut - value: " + value);
}

function onMysteryAnnounce(time, thermometer)
{
    print("MysteryAnnounce - time: " + time + ", thermometer: " + thermometer);
}

function onMysteryConfirmed()
{
    print("MysteryConfirmed");
}

function onMysteryEnter(prize, value)
{
    print("MysteryEnter - prize: " + prize + ", value: " + value);
}

function onMysteryStart(time)
{
    print("MysteryStart - time: " + time);
}

function onMysteryObject(sequence, number)
{
    print("MysteryObject - sequence: " + sequence + ", number: " + number);
}

function onMysteryEnd()
{
    print("MysteryEnd");
}

function onMysteryWon(value)
{
    print("MysteryWon - value: " + value);
}

function onMysteryLost()
{
    print("MysteryLost");
}

function onPigBoomConfirmed()
{
    print("PigBoomConfirmed");
}

function onPigBoomEnter(gold, silver, bronze)
{
    print("PigBoomEnter - gold: " + gold + ", silver: " + silver + ", bronze: " + bronze);
}

function onPigBoomWon(prize)
{
    print("PigBoomWon - prize: " + prize);
}

function onPigBoomEnd()
{
    print("PigBoomEnd");
}

function onPressedButtonAdmin()
{
    print("PressedButtonAdmin");
}

function onPressedButtonAuto()
{
    print("PressedButtonAuto");
}

function onPressedButtonBetMax()
{
    print("PressedButtonBetMax");
}

function onPressedButtonCashout()
{
    print("PressedButtonCashout");
}

function onPressedButtonHelp()
{
    print("PressedButtonHelp");
}

function onPressedButtonPlay()
{
    print("PressedButtonPlay");
}

function onPressedButtonSpeedUp()
{
    print("PressedButtonSpeedUp");
}

function onApplicationError(message)
{
    print("ApplicationError - message: " + message);
}

function onMachineBlocked(message)
{
    print("MachineBlocked - message: " + message);
}

function onOutOfService()
{
    print("OutOfService");
}

function onDoorClosed()
{
    print("DoorClosed");
}

function onCommunicationErrorDetected()
{
    print("CommunicationErrorDetected");
}

function onCommunicationErrorResolved()
{
    print("CommunicationErrorResolved");
}

function onMysteryConnectionLost()
{
    print("MysteryConnectionLost");
}

function onMysteryPowerFailure()
{
    print("MysteryPowerFailure");
}

function onAlesisMessage(message)
{
    print("AlesisMessage - message: " + message);
}

function onGameStartTimeout()
{
    print("GameStartTimeout");
}

function onBacktraceResult(result)
{
    print("BacktraceResult - result: " + result);
}

function onMachineShutdownSignal(signal)
{
    print("MachineShutdownSignal - signal: " + signal);
}

function onMigrationFailed()
{
    print("MigrationFailed");
}

function onMD5Fail() 
{
    print("MD5Fail");
}

function onMachineStartup(message)
{
    print("MachineStartup - message: " + message);
}

function onMachineShutdown()
{
    print("MachineShutdown");
}

function onChangedGame(game)
{
    print("ChangedGame - game: " + game);
}

function onConfigSoundEnter()
{
    print("ConfigSoundEnter");
}

function onBasicGameBet(bet, duration, auto1, auto2, cashWon, pointsWon, startCredits, startBank, startReserve)
{
    print("BasicGameBet - bet: " + bet + ", duration: " + duration + ", auto1: " + auto1 + ", auto2: " + auto2 + ", cashWon: " + cashWon + ", pointsWon: " + pointsWon + ", startCredits: " + startCredits + ", startBank: " + startBank + ", startReserve: " + startReserve);
}

function onBasicGameRisk(points, auto, cashWon, pointsWon, startCredits, startBank, startReserve)
{
    print("BasicGameRisk - points: " + points + ", auto: " + auto + ", cashWon: " + cashWon + ", pointsWon: " + pointsWon + ", startCredits: " + startCredits + ", startBank: " + startBank + ", startReserve: " + startReserve);
}
