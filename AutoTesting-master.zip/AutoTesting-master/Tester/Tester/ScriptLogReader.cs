﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using AutoTestingService;
using AutoTestingService.Shared;

namespace Tester
{
	public class ScriptLogReader
	{
		#region Singleton

		public static ScriptLogReader Instance { get; private set; } = new ScriptLogReader();

		private ScriptLogReader()
		{
		}

		#endregion

		private List<string> InputEventsList = new List<string>();
		private List<string> OutputEventsList = new List<string>();


		public void LoadScriptLogEvents()
		{
			string currentPath = Path.Combine(ATNames.Instance.PathHome, "GameLogTest.txt");
			string readLine;
			Thread.Sleep(500);

			//Path to the script logs
			string scriptLogPath = currentPath.Split(new string[] { "/Tester/Tester/bin/Debug" }, StringSplitOptions.None)[0] + "/AutoTestingClient/AutoTestingClient/bin/Debug/script_logs/" + DateTime.Now.ToString("yyyy-MM-dd") + ".txt";
			using (var inputFile = new StreamReader(scriptLogPath))
			{
				while ((readLine = inputFile.ReadLine()) != null)
				{
					//Only checks lines in the file with a timestamp of after this tester was ran.
					if (DateTime.Parse(Tester.CurrentTime) <= DateTime.Parse(readLine.Substring(1, 8)))
					{
						OutputEventsList.Add(readLine.Substring(11));
					}
				}
			}
		}

		//Requires the file InputEvents.txt with the expected events in the expected order
		public void LoadTesterEvents(LogType type)
		{
			string basePath = ATNames.Instance.PathHome.Split(new string[] { "/bin/Debug" }, StringSplitOptions.None)[0] + "/InputEvents/InputEvents";
			string logPath = type == LogType.Slots ? basePath + "Slots.txt" : basePath + "Bingo.txt";
			string readLine;

			using (var inputFile = new StreamReader(logPath))
			{
				while ((readLine = inputFile.ReadLine()) != null)
				{
					InputEventsList.Add(readLine);
				}
			}
		}

		public bool CompareEventLists(LogType type)
		{
			LoadTesterEvents(type);
			LoadScriptLogEvents();
			return InputEventsList.SequenceEqual(OutputEventsList);
		}
	}
}
