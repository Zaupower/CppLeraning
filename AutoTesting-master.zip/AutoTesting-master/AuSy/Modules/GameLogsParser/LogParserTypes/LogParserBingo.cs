using System;
using System.Collections.Generic;
using System.IO;
using AutoTestingService.Logging;
using EventHandler = AutoTestingService.EventHandler;

namespace AuSy.Modules.GameLogsParser.LogParserTypes
{
	public class LogParserBingo : LogParserBase
	{
		#region Singleton

		public static LogParserBingo Instance { get; } = new LogParserBingo();

		private LogParserBingo()
		{
			string standardPath = "log_types/bingo.json";
			if (!File.Exists(standardPath))
			{
				string altPath =
					Directory.GetCurrentDirectory().Split(new [] {"AuSy/bin"}, StringSplitOptions.None)
						[0] + "AuSy/Modules/GameLogsParser/DefaultRules/bingo.json";
				Logger.Instance.UpdateLog("File bingo.json was read from the source folder LogParser.");
				RegisterEventsFromFile(altPath);
			}
			else
			{
				Logger.Instance.UpdateLog("File bingo.json was read from the folder log_types.");
				RegisterEventsFromFile(standardPath);
			}

			EventHandler.Instance.RegisterEventListSource(GetEventList);
		}

		#endregion
		
	}
}