using System;
using System.Collections.Generic;
using System.IO;
using AutoTestingService.Logging;
using EventHandler = AutoTestingService.EventHandler;

namespace AuSy.Modules.GameLogsParser.LogParserTypes
{
	public class LogParserSlots : LogParserBase
	{
		#region Singleton

		public static LogParserSlots Instance { get; } = new LogParserSlots();

		private LogParserSlots()
		{
			string standardPath = "log_types/slots.json";
			if (!File.Exists(standardPath))
			{
				string altPath =
					Directory.GetCurrentDirectory().Split(new [] {"AuSy/bin"}, StringSplitOptions.None)
						[0] + "AuSy/Modules/GameLogsParser/DefaultRules/slots.json";
				Logger.Instance.UpdateLog("File slots.json was read from the source folder LogParser.");
				RegisterEventsFromFile(altPath);
			}
			else
			{
				Logger.Instance.UpdateLog("File slots.json was read from the folder log_types.");
				RegisterEventsFromFile(standardPath);
			}

			EventHandler.Instance.RegisterEventListSource(GetEventList);
		}

		#endregion
		
	}
}