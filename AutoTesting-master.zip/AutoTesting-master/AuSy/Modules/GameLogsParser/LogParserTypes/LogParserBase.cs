using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using AutoTestingService;
using AutoTestingService.Logging;
using Newtonsoft.Json;
using EventHandler = AutoTestingService.EventHandler;

namespace AuSy.Modules.GameLogsParser.LogParserTypes
{
	public abstract class LogParserBase
	{
		/// <summary>Should it report log lines that don't match any event?</summary>
		public bool reportUnknownLines;

		/// <summary>List of known log line to event rules.</summary>
		protected List<Tuple<string, string, string>> _logLineTypes;

		/// <summary>List of custom log line to event rules.</summary>
		protected List<Tuple<string, string, string>> _customLogLineTypes = new List<Tuple<string, string, string>>();

		#region Public methods

		/// <summary>Constructor.</summary>
		public LogParserBase()
		{
			EventHandler.Instance.AddCallback("NewCustomGameEventFromJs", RegisterNewGameEventFromJs);
			EventHandler.Instance.AddCallback("ClearCustomLineTypes", ClearCustomLineTypes);
		}


		/// <summary>Parses log lines.</summary>
		/// <param name="lines">Lines to parse.</param>
		/// <param name="gameplay">GameplayInfo structure of the game responsible for these events.</param>
		/// <param name="isFirstRead">Returns true if the file was read for the first time in the session.</param>
		public List<GameEvent> ParseLogs(Queue<string> lines, out bool isFirstRead)
		{
			List<GameEvent> gameEvents = new List<GameEvent>();

			isFirstRead = false;

			foreach (string line in lines)
			{
				if (string.IsNullOrEmpty(line) || line == "PartialFile")
				{
					continue;
				}

				if (line == "FirstRead")
				{
					isFirstRead = true;
					continue;
				}

				if (FindLogLineType(line, out string eventName, out List<object> eventParams, out string[] paramTypes))
				{
					gameEvents.Add(new GameEvent(eventName, eventParams, paramTypes));

					if (eventName == "GPUInfo") //SIMAO
					{
						EventHandler.Instance.Trigger("ResetBillAcceptor", "");
					}
				}
				else if (reportUnknownLines)
				{
					Logger.Instance.UpdateLog("Parser could not find an event for the following log line:",
						LoggerType.Develop, true);
					Logger.Instance.UpdateLog(line, LoggerType.Develop, true);
				}
			}

			return gameEvents;
		}


		/// <summary>Removes all queued game events except for the last one.</summary>
		/// <param name="gameEvents">List of events.</param>
		public void KeepLastJSEvent(List<GameEvent> gameEvents)
		{
			if (gameEvents.Count >= 2)
			{
				gameEvents.RemoveRange(0, gameEvents.Count - 1);
			}
		}


		/// <summary>Returns a list with the names of all the events this parser can output, custom ones included.</summary>
		public HashSet<string> GetEventList()
		{
			HashSet<string> list = new HashSet<string>();
			foreach (var type in _logLineTypes)
			{
				list.Add(type.Item1);
			}

			foreach (var type in _customLogLineTypes)
			{
				list.Add(type.Item1);
			}

			return list;
		}


		/// <summary>Adds a custom log matching pattern.</summary>
		/// <param name="eventName">Event name.</param>
		/// <param name="pattern">Regex pattern.</param>
		/// <param name="types">List of what type each parameter is.</param>
		public void AddCustomLineType(string eventName, string pattern, string types)
		{
			_customLogLineTypes.Add(new Tuple<string, string, string>(eventName, pattern, types));
		}


		/// <summary>Clears all registered custom log matching patterns.</summary>
		public void ClearCustomLineTypes(string _, EventInfo? __)
		{
			_customLogLineTypes.Clear();
		}

		#endregion Public methods

		#region Aux

		/// <summary>Registers some new game events from a JSON file.</summary>
		/// <param name="path">The file's path.</param>
		protected void RegisterEventsFromFile(string path)
		{
			List<List<string>> temp = null;
			if (File.Exists(path))
			{
				StreamReader sr = new StreamReader(path);
				temp = JsonConvert.DeserializeObject<List<List<string>>>(sr.ReadToEnd());
			}

			if (temp == null)
			{
				temp = new List<List<string>>();
			}

			_logLineTypes = new List<Tuple<string, string, string>>();
			for (int t = 0; t < temp.Count; ++t)
			{
				if (temp[t].Count != 3)
				{
					Logger.Instance.UpdateLog(
						"Error while reading log type file in " + path + ": entry #" + (t + 1) +
						" does not have an event name, a regex pattern and a type for each of the parameters.",
						LoggerType.Warning);
					continue;
				}

				_logLineTypes.Add(new Tuple<string, string, string>(temp[t][0], temp[t][1], temp[t][2]));
			}
		}

		/// <summary>Given a log line, this function finds its type.</summary>
		/// <returns><c>true</c>, if a type was found, <c>false</c> otherwise.</returns>
		/// <param name="line">Line.</param>
		/// <param name="eventName">Name of the event matching this type.</param>
		/// <param name="eventParams">Event parameters.</param>
		/// <param name="paramTypes">Parameter types</param>
		private bool FindLogLineType(string line, out string eventName, out List<object> eventParams,
			out string[] paramTypes)
		{
			eventName = null;
			eventParams = new List<object>();
			paramTypes = new string[] { };


			foreach (var t in _customLogLineTypes)
			{
				if (TryLineMatch(line, t.Item2, out eventParams))
				{
					eventName = t.Item1;
					paramTypes = t.Item3.Split(',');
					if (t.Item3.Trim().Equals(""))
					{
						if (eventParams.Count != 0)
						{
							Logger.Instance.UpdateLog(
								"Error while reading log: '" + line +
								"', as the number of parameters and types of parameters isn't the same.",
								LoggerType.Warning);
							return false;
						}
					}
					else
					{
						if (eventParams.Count != paramTypes.Length)
						{
							Logger.Instance.UpdateLog(
								"Error while reading log: '" + line +
								"', as the number of parameters and types of parameters isn't the same.",
								LoggerType.Warning);
							return false;
						}
					}

					return true;
				}
			}

			foreach (var t in _logLineTypes)
			{
				if (TryLineMatch(line, t.Item2, out eventParams))
				{
					eventName = t.Item1;
					paramTypes = t.Item3.Split(',');
					if (t.Item3.Trim().Equals(""))
					{
						if (eventParams.Count != 0)
						{
							Logger.Instance.UpdateLog(
								"Error while reading log: '" + line +
								"', as the number of parameters and types of parameters isn't the same.",
								LoggerType.Warning);
							return false;
						}
					}
					else
					{
						if (eventParams.Count != paramTypes.Length)
						{
							Logger.Instance.UpdateLog(
								"Error while reading log: '" + line +
								"', as the number of parameters and types of parameters isn't the same.",
								LoggerType.Warning);
							return false;
						}
					}

					return true;
				}
			}

			return false;
		}

		/// <summary>Checks if the log line matches the specified pattern.</summary>
		/// <returns><c>true</c>, if the line matches, <c>false</c> otherwise.</returns>
		/// <param name="line">Log line.</param>
		/// <param name="pattern">Regex pattern to match.</param>
		/// <param name="eventParams">If it matched, these are the event parameters.</param>
		private bool TryLineMatch(string line, string pattern, out List<object> eventParams)
		{
			eventParams = new List<object>();

			Match m = Regex.Match(line, pattern);
			if (m.Success)
			{
				bool didFirstGroup = false;
				foreach (Group g in m.Groups)
				{
					if (!didFirstGroup)
					{
						// The first capture group is the full string. Skip it.
						didFirstGroup = true;
						continue;
					}

					bool isNumeric = Double.TryParse(g.Value, out double value);
					if (!isNumeric || g.Value.Contains(","))
						eventParams.Add(g.Value);
					else
						eventParams.Add(value);
				}

				return true;
			}

			return false;
		}

		private void RegisterNewGameEventFromJs(string dataJson, EventInfo? _)
		{
			Dictionary<string, string> data = JsonConvert.DeserializeObject<Dictionary<string, string>>(dataJson);
			AddCustomLineType(data["name"], data["logPattern"], data["types"]);
		}

		#endregion Aux
	}
}