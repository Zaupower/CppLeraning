using System;
using System.Collections.Generic;
using AuSy.Modules.GameLogsParser.LogParserTypes;
using AutoTestingService;
using AutoTestingService.Logging;
using Newtonsoft.Json;
using WebSocketSharp;
using EventHandler = AutoTestingService.EventHandler;
using Logger = AutoTestingService.Logging.Logger;

namespace AuSy.Modules.GameLogsParser
{
	public class GameLogsParser
	{
		#region Singleton

		public static GameLogsParser Instance { get; } = new GameLogsParser();

		private GameLogsParser()
		{
		}

		#endregion

		#region Members

		private LogParserBase _logParser;

		#endregion

		#region Init and Terminate

		public void Init(LogType logType, bool reportUnknownLogLines)
		{
			switch (logType)
			{
				case LogType.Bingo:
					_logParser = LogParserBingo.Instance;
					break;
				case LogType.Slots:
					_logParser = LogParserSlots.Instance;
					break;
			}

			_logParser.reportUnknownLines = reportUnknownLogLines;

			EventHandler.Instance.AddCallback("NewGameLogLines", HandleNewGameLogLines);
		}

		/// <summary>Terminates the GameLogsParser module.</summary>
		public void Terminate()
		{
			_logParser = null;
			EventHandler.Instance.RemoveCallback("NewGameLogLines", HandleNewGameLogLines);
		}

		#endregion

		#region Processing

		private void HandleNewGameLogLines(string data, EventInfo? info)
		{
			Dictionary<string, List<string>> dataDictionary =
				JsonConvert.DeserializeObject<Dictionary<string, List<string>>>(data);

			foreach (var ipAndLogs in dataDictionary)
			{
				string ip = ipAndLogs.Key;
				if (ip.IsNullOrEmpty())
				{
					// These are file logs. We must correct the IP.
					if (info.HasValue)
					{
						// Use the websocket message sender's IP.
						ip = info.Value.originIp;
					}
					else
					{
						// Use the local IP.
						ip = Helper.Instance.Ip;
					}
				}

				Queue<string> logsQueue = new Queue<string>(ipAndLogs.Value);
				List<GameEvent> gameEvents = _logParser.ParseLogs(logsQueue, out bool isFirstRead);

				if (isFirstRead)
				{
					// If this is the session's first log read, keep just the last line, so that it doesn't repeat old (pre-reboot) events.
					_logParser.KeepLastJSEvent(gameEvents);
				}

				EmitQueuedJsEvents(gameEvents, ip);
			}
		}

		private void EmitQueuedJsEvents(List<GameEvent> gameEvents, string gameIp)
		{
			foreach (GameEvent ev in gameEvents)
			{
				GameEvent finalEv = new GameEvent
				{
					ip = gameIp,
					name = ev.name,
					parameters = ev.parameters,
					types = ev.types
				};
				EventDistributor.Instance.Trigger("GotGameEvent", JsonConvert.SerializeObject(finalEv));
			}
		}

		#endregion
	}
}