using System.Collections.Generic;
using System.Threading;
using AuSy.Modules.GameLogsReader.LogReader.LogReaderFile;
using AuSy.Modules.GameLogsReader.LogReader.LogReaderWebsocket;
using AutoTestingService;
using AutoTestingService.Logging;
using Newtonsoft.Json;

namespace AuSy.Modules.GameLogsReader
{
	public class GameLogsReader
	{
		#region Variables

		/// <summary>Log reader.</summary>
		public LogReader.LogReader logReader;

		/// <summary>File Watcher component.</summary>
		private FileWatcher _fileWatcher;

		/// <summary>Signal to raise when a new log line has been written.</summary>
		private AutoResetEvent _newLogLinesSignal;

		/// <summary>Log Output control flag (if false, no logs will be read until it's true)</summary>
		private bool _logOutput = true;

		/// <summary>Flag that indicates that the Module processing should stop.</summary>
		private bool _stop = false;

		/// <summary>Ip to report to via EventDistributor when new log lines arrive (can be local or remote).</summary>
		private string _reportIp;

		private Thread _gameLogsReaderThread;

		#endregion

		#region Singleton

		/// <summary>Class instance (Singleton).</summary>
		public static GameLogsReader Instance { get; } = new GameLogsReader();
		
		private ManualResetEvent _stopSignal = new ManualResetEvent(false);

		private GameLogsReader()
		{
		}

		#endregion

		#region Init and Terminate

		/// <summary>Initializer for module GameLogsReader</summary>
		/// <param name="config">GameLogsReader Module init paramenters.</param>
		public void Init(GameLogsReaderConfig config, ManualResetEvent stopSignal)
		{
			_stopSignal = stopSignal;
			_newLogLinesSignal = new AutoResetEvent(false);
			switch (config.logMode)
			{
				case LogReaderMode.LogFile:
					SetupLogFileMode(config.logsFolder);
					break;
				case LogReaderMode.WebSocket:
					SetupWebSocketMode();
					break;
			}

			EventHandler.Instance.AddCallback("StartAusy", StartProcessThread);
			EventHandler.Instance.AddCallback("EventReportIpChanged", (s, i) => _reportIp = s);
		}

		/// <summary>Setups Log Reader to read game logs from a file.</summary>
		/// <param name="logsFolder">Path to logs Folder.</param>
		private void SetupLogFileMode(string logsFolder)
		{
			logReader = new LogReaderFile(logsFolder, _newLogLinesSignal);
			_fileWatcher = FileWatcher.Instance;
		}

		/// <summary>Setups Log Reader to read game logs via websocket.</summary>
		/// <param name="gameFolder">Path to game folder.</param>
		/// <param name="loggingIp">Ip that receives logs via websocket.</param>
		private void SetupWebSocketMode()
		{
			logReader = new LogReaderWebSocket(_newLogLinesSignal);
		}
		
		/// <summary>Terminates GameLogsReader module.</summary>
		public void Terminate()
		{
			_gameLogsReaderThread.Join();
			logReader = null;
			_fileWatcher?.Terminate();
			_fileWatcher = null;
			_newLogLinesSignal = null;
			_reportIp = null;
			EventHandler.Instance.RemoveCallback("StartAusy", StartProcessThread);
		}

		#endregion

		#region processLogs

		private void StartProcessThread(string _, EventInfo? __)
		{
			_gameLogsReaderThread = new Thread(ProcessLoop)
			{
				Name = "GameLogsReader Module Thread"
			};
			_gameLogsReaderThread.Start();
		}

		/// <summary>Thread code that processes log file changes when they arrive.</summary>
		private void ProcessLoop()
		{
			while (!_stop)
			{
				int signalIndex = WaitHandle.WaitAny(new WaitHandle[] {_newLogLinesSignal, _stopSignal});

				switch (signalIndex)
				{
					case 0:
						ProcessLogs();
						break;
					case 1:
						_stop = true;
						break;
				}
			}
		}

		/// <summary>Process new log lines.</summary>
		private void ProcessLogs()
		{
			// Mais tarde alterar esta tag com o comando SetLogOutput (de scripting??)
			if (!_logOutput)
			{
				return;
			}

			Dictionary<string, List<string>> newLinesDict = logReader.GetNewLines();

			if (newLinesDict.Count > 0)
			{
				TriggerNewLogsEvent(newLinesDict);
			}
		}

		/// <summary>Sends a trigger call to the log Parser with the new lines to parse and the corresponding machine IPs.</summary>
		/// <param name="newLines">New game log lines dictionary.</param>
		private void TriggerNewLogsEvent(Dictionary<string, List<string>> newLines)
		{
			string newLinesDictJson = JsonConvert.SerializeObject(newLines);

			EventDistributor.Instance.Trigger("NewGameLogLines", newLinesDictJson, _reportIp);
		}

		#endregion

		#region Methods

		private void SetQuitSignal(string _)
		{
			_stop = true;
		}

		#endregion
	}
	
	public enum LogReaderMode
	{
		LogFile,
		WebSocket
	}

	public struct GameLogsReaderConfig
	{
		public LogReaderMode logMode;
		public string gameFolder;
		public string logsFolder;
	}
}