using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using AuSy.WebsocketLogsSetup.LogmanagerConfig;
using AutoTestingService;
using AutoTestingService.Logging;
using AutoTestingService.Shared;
using Newtonsoft.Json;
using EventHandler = AutoTestingService.EventHandler;

namespace AuSy.Modules.GameLogsReader.LogReader.LogReaderWebsocket
{
	public class LogReaderWebSocket : LogReader
	{
		#region Variables

		/// <summary>Dictionary that stores a Queue for each game machine with new log lines. (ConcurrentQueue allows for parallel/concurrent handling)</summary>
		private Dictionary<string, ConcurrentQueue<string>> _logLines;

		/// <summary>Maximum number of new lines to read from the queue at once.</summary>
		private int maxNumLines = 30;

		/// <summary>Signal to raise when new game log lines arrive.</summary>
		private AutoResetEvent _signalNewLines;

		#endregion

		#region Constructor

		public LogReaderWebSocket(AutoResetEvent signalNewLines)
		{
			_signalNewLines = signalNewLines;
			_logLines = new Dictionary<string, ConcurrentQueue<string>>();
			
			EventHandler.Instance.AddCallback("WsNewGameLogLines", UpdateLogLines); 
		}

		#endregion

		#region Methods

		/// <summary>Gets any new unread log lines received by websocket.</summary>
		/// <returns>The new log lines.</returns>
		public override Dictionary<string, List<string>> GetNewLines()
		{
			Dictionary<string, List<string>> newLogLinesDict = new Dictionary<string, List<string>>();

			string newLine;
			foreach (var item in _logLines)
			{
				string machineIP = item.Key;

				if (!item.Value.IsEmpty)
				{
					newLogLinesDict.Add(machineIP, new List<string>());
				}
				else
				{
					continue;
				}

				for (int i = 0; i < maxNumLines; i++)
				{
					if (item.Value.TryDequeue(out newLine))
					{
						newLogLinesDict[machineIP].Add(newLine);
					}
					else
					{
						break;
					}
				}
			}

			return newLogLinesDict;
		}

		/// <summary>Updates the log lines queue with the new line.</summary>
		/// <param name="newLine">New log line.</param>
		/// <param name="eventInfo">Info about the event, containing the origin IP.</param>
		public void UpdateLogLines(string newLine, EventInfo? eventInfo)
		{
			if (!_logLines.ContainsKey(eventInfo.Value.originIp))
			{
				_logLines.Add(eventInfo.Value.originIp, new ConcurrentQueue<string>());
			}

			_logLines[eventInfo.Value.originIp].Enqueue(newLine);
			_signalNewLines.Set();
		}

		#endregion
	}

	public class NewLinesJson
	{
		[JsonProperty] public string machineIP { get; set; }

		[JsonProperty] public string newLine { get; set; }
	}
}