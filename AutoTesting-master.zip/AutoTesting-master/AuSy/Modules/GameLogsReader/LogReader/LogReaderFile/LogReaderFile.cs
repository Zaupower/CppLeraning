using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using AutoTestingService;
using AutoTestingService.Logging;

namespace AuSy.Modules.GameLogsReader.LogReader.LogReaderFile
{
	public class LogReaderFile : LogReader
	{
		#region Constructor

		public LogReaderFile(string pathToLogFolder, AutoResetEvent newLinesSignalToRaise)
		{
			FileWatcher.Instance.Init(pathToLogFolder, newLinesSignalToRaise);

			if (!Directory.Exists(pathToLogFolder))
			{
				Logger.Instance.UpdateLog("LogReaderFile: path to game logs folder provided doesn't exist (" + pathToLogFolder + ").");
				return;
			}
			
			string mostRecentLogFile = Directory.GetFiles(pathToLogFolder, "GameLog*.txt")
				.Select(fn => new FileInfo(fn)).OrderBy(f => f.Name).LastOrDefault()?.FullName;
			
			if (!String.IsNullOrEmpty(mostRecentLogFile))
			{
				// Store last byte of most recent log file so that these "old" logs are ignored and not read
				using (FileStream fileStream = File.Open(mostRecentLogFile, FileMode.Open, FileAccess.Read,
					FileShare.Read))
				{
					_lastByteRead = fileStream.Length;
				}
				_lastFileRead = mostRecentLogFile;
			}
		}

		#endregion
		
		private long _byteMax = 10000;

		private string _lastFileRead;
		private long _lastByteRead;

		/// <summary>Gets any new unread log lines in the game log files.</summary>
		/// <returns>The new log lines.</returns>
		public override Dictionary<string, List<string>> GetNewLines()
		{
			string filePath = FileWatcher.Instance.GetFilePath();

			bool isFirstRead = _lastFileRead == null;

			if (filePath != _lastFileRead)
			{
				_lastByteRead = 0;
			}

			_lastFileRead = filePath;

			try
			{
				using (FileStream fileStream = File.Open(filePath, FileMode.Open, FileAccess.Read, FileShare.Read))
				{
					long bytesToRead;
					// Determine how many bytes to read.
					if (fileStream.Length != 0)
					{
						bytesToRead = Math.Min(_byteMax, fileStream.Length - _lastByteRead);
					}
					else
					{
						bytesToRead = 0;
					}

					bytesToRead += 1; // Try to catch the \n that comes before.
					bytesToRead = Math.Min(bytesToRead, fileStream.Length);
					_lastByteRead = fileStream.Length;

					// Seek the file to that point and read from there on out.
					fileStream.Seek(-bytesToRead, SeekOrigin.End);
					byte[] bytes = new byte[bytesToRead];
					fileStream.Read(bytes, 0, (int) bytesToRead);

					// Get the lines in those bytes.
					string utfString = Encoding.UTF8.GetString(bytes);
					List<string> lines =
						new List<string>(utfString.Split(new char[] {'\n'}, StringSplitOptions.RemoveEmptyEntries));

					if (utfString.Length > 0 && utfString[0] != '\n' && lines[0] != File.ReadLines(filePath).First())
					{
						// The first line is actually an incomplete fragment of the previous line. It's garbage.
						lines.RemoveAt(0);
					}

					if (isFirstRead)
					{
						lines.Insert(0, "FirstRead");
					}

					return new Dictionary<string, List<string>> {{"", lines}};
				}
			}
			catch (Exception ex)
			{
				Logger.Instance.UpdateLog(
					"Error: Failed to open file " + filePath + ". Exception: " + ex.Message + " " + ex.StackTrace,
					LoggerType.Error);
				return new Dictionary<string, List<string>>()
					{{"", new List<string> {"Could not open file"}}};
			}
		}
	}
}