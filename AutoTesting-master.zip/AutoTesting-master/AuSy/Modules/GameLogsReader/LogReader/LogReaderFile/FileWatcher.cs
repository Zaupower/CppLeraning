﻿using System.IO;
using System.Security.Permissions;
using System.Threading;

namespace AuSy.Modules.GameLogsReader.LogReader.LogReaderFile
{
	/// <summary>File Watcher class.</summary>
	/// <description>This Watcher is responsible for monitoring the provided path for file changes and report them.</description>
	public class FileWatcher
	{
		public static FileWatcher Instance { get; } = new FileWatcher();

		#region Variables

		private AutoResetEvent _signalToRaise;

		/// <summary>Current File path.</summary>
		private string _filePath = "";

		/// <summary>File Watcher.</summary>
		private FileSystemWatcher _watcher;

		#endregion

		#region Init

		/// <summary>Initialize Watcher (given Path to watch).</summary>
		/// <param name="path">Folder Path.</param>
		/// <param name="signalToRaise">When the logs have changed, raise this signal.</param>
		[PermissionSet(SecurityAction.Demand, Name = "FullTrust")]
		public void Init(string path, AutoResetEvent signalToRaise)
		{
			_signalToRaise = signalToRaise;

			if (_watcher != null)
			{
				_watcher.EnableRaisingEvents = false;
			}

			_watcher = new FileSystemWatcher();
			_watcher.NotifyFilter = NotifyFilters.LastWrite; // Watch for changes in LastWrite times
			_watcher.Filter = "GameLog*.txt"; // Only watch text files

			_watcher.Changed += onChanged; // Add Changed event handler
			_watcher.Created += onChanged; // Add Created event handler

			_watcher.Path = path;

			_watcher.EnableRaisingEvents = true; // Begin watching
		}

		#endregion

		#region Methods

		/// <summary>On file changed or created.</summary>
		/// <param name="source">Source object.</param>
		/// <param name="args">File System Event Arguments.</param>
		private void onChanged(object source, FileSystemEventArgs args)
		{
			if (_filePath == "")
			{
				_filePath = args.FullPath;
			}
			else if (!_filePath.Equals(args.FullPath))
			{
				_filePath = args.FullPath;
			}

			_signalToRaise.Set();
		}

		/// <summary>Gets the file path.</summary>
		/// <returns>The file path.</returns>
		public string GetFilePath()
		{
			return _filePath;
		}

		public void Terminate()
		{
			_watcher.Changed -= onChanged; // Add Changed event handler
			_watcher.Created -= onChanged;
		}

		#endregion
	}
}