﻿using System.Collections.Generic;

namespace AuSy.Modules.GameLogsReader.LogReader
{
	public abstract class LogReader
	{
		/// <summary>Gets dictionary with list of new game log lines for each machine.</summary>
		/// <returns>Log lines dictionary.</returns>
		public abstract Dictionary<string, List<string>> GetNewLines();
	}
}
