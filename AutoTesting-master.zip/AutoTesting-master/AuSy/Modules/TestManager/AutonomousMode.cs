using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using AutoTestingService;
using AutoTestingService.Configuration.AusyConfig;
using AutoTestingService.Configuration.AutonomousModeConfig;
using AutoTestingService.Logging;
using AutoTestingService.Shared;
using Jint.Native;
using Newtonsoft.Json;
using EventHandler = AutoTestingService.EventHandler;

namespace AuSy.Modules.TestManager
{
    public class AutonomousMode
    {
        #region Singleton

        public static AutonomousMode Instance { get; } = new AutonomousMode();

        private AutonomousMode()
        {
        }

        #endregion

        #region Members

        /// <summary>Path to testDefinitions.json file</summary>
        private string _testDefinitionsPath = String.Empty;

        /// <summary>Stores the testDefinitions parameters from the testDefinitions.json file.</summary>
        private TestDefinitions _testDefinitions { get; set; }

        /// <summary>Saves the defined test definition script paths.</summary>
        private List<string> _scriptPaths { get; set; }

        /// <summary>Saves the defined test definition include paths.</summary>
        private List<string> _includePaths { get; set; }

        /// <summary>Stores whether or not the Ausy soft restart has already been done (to avoid infinite restarts).</summary>
        public bool ausySoftRestartDone = false;

        #endregion

        #region Init and Terminate

        public void Init(string testDefinitionsPath)
        {
            _testDefinitionsPath = testDefinitionsPath;
            _scriptPaths = new List<string>(); 
            _includePaths = new List<string>();
            LoadTestDefinitions();

            if (_testDefinitions != null)
            {
                SetupTestDefinitionsSuite();
                EventHandler.Instance.AddCallback("StartAusy2", UpdateConfigs);
                if (_scriptPaths.Any())
                {
                    EventHandler.Instance.AddCallback("StartAusy2", RunTestDefinitionsSuite);
                }
            }
        }

        public void Terminate()
        {
            if (_testDefinitions != null && _scriptPaths.Any())
            {
                EventHandler.Instance.RemoveCallback("StartAusy2", RunTestDefinitionsSuite);
            }
            
            _testDefinitionsPath = String.Empty;
            _testDefinitions = null;
            _scriptPaths = null;
            _includePaths = null;
        }

        #endregion

        #region methods

        /// <summary>Loads the testDefinitions configuration.</summary>
        private void LoadTestDefinitions()
        {
            if (_testDefinitionsPath == "")
            {
                if (File.Exists(AusyApplicationConfig.TestDefinitionsPathDefault))
                {
                    _testDefinitionsPath = AusyApplicationConfig.TestDefinitionsPathDefault;
                    Logger.Instance.UpdateLog(
                        "[TestDefinitions] Using default testDefinitions config path (not defined in Ausy config or defined equal to the default).",
                        LoggerType.Warning);
                }
                else if (File.Exists("/game/tests/ausy/testDefinitions.json"))
                {
                    _testDefinitionsPath = "/game/tests/ausy/testDefinitions.json";
                    Logger.Instance.UpdateLog(
                        "[TestDefinitions] Using /game/tests/ausy/testDefinitions.json as the testDefinitions config path (not defined in Ausy config or defined equal to the default).",
                        LoggerType.Warning);
                }
            }

            if (File.Exists(_testDefinitionsPath))
            {
                try
                {
                    using (StreamReader fs = new StreamReader(_testDefinitionsPath))
                    {
                        _testDefinitions = JsonConvert.DeserializeObject<TestDefinitions>(fs.ReadToEnd());
                        TestManager.Instance.ConfigureTestDefinitions(_testDefinitions);

                        _includePaths = ValidateTestPathings(_testDefinitions.Includes);
                        _scriptPaths = ValidateTestPathings(_testDefinitions.TestScripts);
                    }
                }
                catch (Exception ex)
                {
                    Logger.Instance.UpdateLog(
                        "[TestDefinitions] Failed to load testDefinitions config file: " + _testDefinitionsPath + "\n" +
                        ex, LoggerType.Warning);
                }
            }
            else
            {
                Logger.Instance.UpdateLog(
                    "[TestDefinitions] Couldn't find the testDefinitions config file in path: " + _testDefinitionsPath,
                    LoggerType.Warning);
            }
        }

        /// <summary>Validate if paths in a list exist and are accessible</summary>
        /// <param name="list">The list.</param>
        /// <returns>List of files that exist and are accessible</returns>
        private List<string> ValidateTestPathings(List<TestDefinitionsTestScriptsConfiguration> list)
        {
            if (list == null)
            {
                return new List<string>();
            }

            List<string> existingFiles = new List<string>();
            List<string> validFiles = new List<string>();
            foreach (var entry in list)
            {
                if (entry.Rep != null)
                {
                    Logger.Instance.UpdateLog(
                        "[TestDefinitions] Read JavaScript files from git repository: " + entry.Rep,
                        LoggerType.Warning);

                    foreach (var file in CopyGitFiles(entry.Rep, entry.Path, entry.CommitID, "tempGitFiles"))
                    {
                        existingFiles.Add(file);
                    }
                }
                else
                {
                    foreach (var path in entry.Path)
                    {
                        if (File.Exists(path) && path.EndsWith(".js"))
                        {
                            existingFiles.Add(path);
                        }
                        else if (Directory.Exists(path))
                        {
                            List<string> filesList = Directory.GetFiles(path).ToList();

                            foreach (var file in filesList)
                            {
                                if (file.EndsWith(".js"))
                                {
                                    existingFiles.Add(file);
                                }
                                else
                                    Logger.Instance.UpdateLog("[TestDefinitions] Tried to read invalid file.",
                                        LoggerType.Warning);
                            }
                        }
                        else
                            Logger.Instance.UpdateLog("[TestDefinitions] File or Directory not found: " + path,
                                LoggerType.Warning);
                    }
                }
            }

            validFiles = ValidateFileOpening(existingFiles);

            return validFiles;
        }

        /// <summary>Validate the access to read files in a list</summary>
        /// <param name="files"></param>
        /// <returns>List with accessible files</returns>
        private List<string> ValidateFileOpening(List<string> files)
        {
            List<string> validList = new List<string>();

            foreach (var file in files)
            {
                try
                {
                    using (StreamReader fs = new StreamReader(file))
                    {
                        validList.Add(file);
                    }
                }
                catch (Exception ex)
                {
                    Logger.Instance.UpdateLog("[TestDefinitions] Problem with reading the listed files: " + ex.Message,
                        LoggerType.Warning);
                }
            }

            return validList;
        }

        /// <summary>Setups the Test Definitions Suite environment (scripts/results directories) and updates the suite JSON</summary>
        private void SetupTestDefinitionsSuite()
        {
            if (_testDefinitions == null || _scriptPaths == null)
            {
                Logger.Instance.UpdateLog(
                    "(SetupTestDefinitionsSuite) TestDefinitions was not defined or has no valid testScript paths",
                    LoggerType.Warning);
                return;
            }

            string currentTestSessionPath = String.Empty;
            string testResultsPath = String.Empty;

            if (Path.GetDirectoryName(_testDefinitionsPath) == String.Empty)
            {
                currentTestSessionPath = Directory.GetCurrentDirectory() + "/currentTestSession";
                testResultsPath = "testResults/" + "testResults_" + DateTime.Now.ToString("dd-MM_HH-mm-ss");
            }
            else
            {
                currentTestSessionPath = Path.GetDirectoryName(_testDefinitionsPath) +
                                         "/" + "currentTestSession";
                testResultsPath = Path.GetDirectoryName(_testDefinitionsPath) +
                                  "/testResults/" +
                                  "testResults_" + DateTime.Now.ToString("dd-MM_HH-mm-ss") + "";
            }

            if (Directory.Exists(currentTestSessionPath))
                Directory.Delete(currentTestSessionPath, true);

            Directory.CreateDirectory(currentTestSessionPath);
            Directory.CreateDirectory(currentTestSessionPath + "/" + ATNames.Instance.FolderIncludes);
            Directory.CreateDirectory(testResultsPath);
            Directory.CreateDirectory(testResultsPath + "/" + ATNames.Instance.FolderLogs);
            Directory.CreateDirectory(testResultsPath + "/" + ATNames.Instance.FolderScriptLogs);
            EventHandler.Instance.Trigger("SetJsLogFileLocation", testResultsPath + "/");

            _testDefinitions.testResultsFolderPath = testResultsPath;

            string testDefinitionsFolder = Path.GetDirectoryName(_testDefinitionsPath);
            if (_testDefinitions.ConfigEnvironment.rep != null)
            {
                CopyGitFiles(_testDefinitions.ConfigEnvironment.rep,
                    new List<string> {_testDefinitions.ConfigEnvironment.path},
                    _testDefinitions.ConfigEnvironment.commitID, testDefinitionsFolder);
                _testDefinitions.ConfigEnvLocalPath = Path.Combine(testDefinitionsFolder,
                    Path.GetFileName(_testDefinitions.ConfigEnvironment.path));
            }
            else
            {
                _testDefinitions.ConfigEnvLocalPath = _testDefinitions.ConfigEnvironment.path;
            }

            if (_testDefinitions.ConfigAusy.rep != null)
            {
                CopyGitFiles(_testDefinitions.ConfigAusy.rep, new List<string> {_testDefinitions.ConfigAusy.path},
                    _testDefinitions.ConfigAusy.commitID, testDefinitionsFolder);
                _testDefinitions.ConfigAusyLocalPath = Path.Combine(testDefinitionsFolder,
                    Path.GetFileName(_testDefinitions.ConfigAusy.path));
            }
            else
            {
                _testDefinitions.ConfigAusyLocalPath = _testDefinitions.ConfigAusy.path;
            }

            List<string> includesPaths = new List<string>();
            foreach (var include in _includePaths)
            {
                try
                {
                    string newIncludePath = currentTestSessionPath + "/" + ATNames.Instance.FolderIncludes + "/" +
                                            Path.GetFileName(include);
                    File.Copy(include, newIncludePath, true);
                    includesPaths.Add(newIncludePath);
                }
                catch
                {
                    Logger.Instance.UpdateLog(
                        "[TestDefinitions] Failed to copy include file (probably file permissions problem): " + include,
                        LoggerType.Warning);
                }
            }

            List<string> testScriptsPaths = new List<string>();
            foreach (var test in _scriptPaths)
            {
                try
                {
                    string newTestPath = currentTestSessionPath + "/" + Path.GetFileName(test);
                    File.Copy(test, newTestPath, true);
                    testScriptsPaths.Add(newTestPath);
                }
                catch
                {
                    Logger.Instance.UpdateLog(
                        "[TestDefinitions] Failed to copy Script file (probably file permissions problem): " + test,
                        LoggerType.Warning);
                }
            }

            TestManager.Instance.UpdateFromList(testScriptsPaths);
            TestManager.Instance.altIncludesFolder = currentTestSessionPath + "/" + ATNames.Instance.FolderIncludes;

            if (_scriptPaths.Count > 0 && _scriptPaths[0].StartsWith("tempGit/"))
                Directory.Delete("tempGit", true);

            if (Directory.Exists("tempGitFiles"))
                Directory.Delete("tempGitFiles", true);
        }

        /// <summary>Triggers the event that starts the test Suite execution (if in TestDefinition mode)</summary>
        private void RunTestDefinitionsSuite(string _, EventInfo? __)
        {
            if (_testDefinitions == null || _scriptPaths == null)
            {
                return;
            }

            ATNames.Instance.FolderTestResults = _testDefinitions.testResultsFolderPath;

            EventHandler.Instance.AddCallback("TestSuiteEnded", SaveLatestAusyLog);
            EventHandler.Instance.Trigger("StartTests", "");
        }

        private void SaveLatestAusyLog(string _, EventInfo? __)
        {
            string destinationFolder = _testDefinitions.testResultsFolderPath + "/" + ATNames.Instance.FolderLogs;
            string ausyLogPath = Logger.Instance._logfile;
            string ausyLogFileName = Path.GetFileName(ausyLogPath);
            if (File.Exists(ausyLogPath))
            {
                File.Copy(ausyLogPath, destinationFolder + "/" + ausyLogFileName, true);
            }
        }

        /// <summary>Runs AusyConfig and EnvConfig scripts to update respective configs.</summary>
        public void UpdateConfigs(string _, EventInfo? __)
        {
            if (!String.IsNullOrEmpty(_testDefinitions.ConfigEnvLocalPath) && ValidateJsFile(_testDefinitions.ConfigEnvLocalPath))
            {
                EventHandler.Instance.Trigger("ResetJsEngine", "");
                EventHandler.Instance.Trigger("RunJsFile", _testDefinitions.ConfigEnvLocalPath);
            }

            if (!String.IsNullOrEmpty(_testDefinitions.ConfigAusyLocalPath) && ValidateJsFile(_testDefinitions.ConfigAusyLocalPath))
            {
                if (!ausySoftRestartDone)
                {
                    ausySoftRestartDone = true;
                    EventHandler.Instance.Trigger("ResetJsEngine", "");
                    EventHandler.Instance.Trigger("RunJsFile", _testDefinitions.ConfigAusyLocalPath);
                    EventHandler.Instance.Trigger("RestartAusy", "TestDefinitions");   
                }
            }
        }

        private bool ValidateJsFile(string jsFilePath)
        {
            if (File.Exists(jsFilePath) && jsFilePath.EndsWith(".js"))
            {
                try
                {
                    using (StreamReader fs = new StreamReader(jsFilePath))
                    {
                        return true;
                    }
                }
                catch (Exception ex)
                {
                    Logger.Instance.UpdateLog(
                        "[TestDefinitions] Failed to load JS file:  " + jsFilePath + "\n" + ex.Message,
                        LoggerType.Warning);
                    return false;
                }
            }
            else
            {
                Logger.Instance.UpdateLog("[TestDefinitions] JS File was not found in path: " + jsFilePath,
                    LoggerType.Warning);
                return false;
            }
        }

        #endregion

        #region git methods

        private List<string> CopyGitFiles(string gitRepository, List<string> pathList, string commitID,
            string destinationFolder)
        {
            string clonePath = Directory.GetCurrentDirectory() + "/gitClones/" + gitRepository.Split('/').Last() + '/';
            List<string> fileList = new List<string>();

            RunCommand shell = new RunCommand();
            try
            {
                shell.RunExeCommand(
                    "git",
                    "clone " + gitRepository + " " + clonePath,
                    true
                );

                if (shell.ExitCode != 0)
                {
                    Logger.Instance.UpdateLog(
                        "The following error occurred while trying to clone the repository: ExitCode-"
                        + shell.ExitCode + " Error-" + shell.Error + " Output-" + shell.Output,
                        LoggerType.Warning);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Git clone Exception: " + ex);
            }

            try
            {
                shell.RunExeCommand(
                    "git",
                    "-C " + clonePath + " checkout " + commitID,
                    true
                );

                if (shell.ExitCode != 0)
                {
                    Logger.Instance.UpdateLog(
                        "The following error occurred while trying to checkout the repository: ExitCode-"
                        + shell.ExitCode + " Error-" + shell.Error + " Output-" + shell.Output, LoggerType.Warning);

                    return new List<string>();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Git checkout Exception: " + ex);
                return new List<string>();
            }

            if (!Directory.Exists(destinationFolder))
                Directory.CreateDirectory(destinationFolder);

            foreach (var path in pathList)
            {
                if (!path.EndsWith(".js"))
                    fileList.AddRange(GitCopyDirectory(clonePath, path, destinationFolder));
                else
                {
                    fileList.AddRange(GitCopyFile(clonePath, path, destinationFolder));
                }
            }

            if (Directory.Exists("gitClones"))
                Directory.Delete("gitClones", true);

            return fileList;
        }

        public List<string> GitCopyDirectory(string clonePath, string path, string destinationFolder)
        {
            List<string> fileList = new List<string>();
            DirectoryInfo d = new DirectoryInfo(clonePath + path);

            foreach (var file in d.GetFiles())
            {
                string finalPath = destinationFolder + "/" + file.Name;
                File.Copy(file.FullName, finalPath, true);
                fileList.Add(finalPath);
            }

            return fileList;
        }

        public List<string> GitCopyFile(string clonePath, string path, string destinationFolder)
        {
            List<string> fileList = new List<string>();

            FileInfo file = new FileInfo(clonePath + path);
            string finalPath = destinationFolder + "/" + file.Name;
            File.Copy(file.FullName, finalPath, true);
            fileList.Add(finalPath);

            return fileList;
        }

        #endregion
    }
}