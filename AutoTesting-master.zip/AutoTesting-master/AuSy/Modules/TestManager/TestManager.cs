﻿using System;
using System.Collections.Generic;
using System.IO;
using AutoTestingService;
using AutoTestingService.Configuration.AutonomousModeConfig;
using AutoTestingService.Logging;
using AutoTestingService.Machine;
using AutoTestingService.Shared;
using Jint.Native;
using Newtonsoft.Json;
using EventHandler = AutoTestingService.EventHandler;

namespace AuSy.Modules.TestManager
{
	public class TestManager
	{
		#region Singleton

		public static TestManager Instance { get; } = new TestManager ();

		private TestManager ()
		{
		}

		#endregion
		
		#region Constants

		public const string DefaultTestName = "(unnamed)";
		public const string DefaultStepName = "(unnamed)";
		const string TestsFolderName = "scripts";
		const string SuiteFileName = "test_suite.json";

		#endregion
		
		#region Member variables

		/// <summary>List of test files to run.</summary>
		public List<string> fileList { get; private set; }

		/// <summary>List of tests run so far.</summary>
		public List<TestSuiteTest> tests { get; private set; }

		/// <summary>Are we currently running the test suite?</summary>
		public bool running { get; private set; } = false;

		/// <summary>Index of the test currently being run.</summary>
		public int currentFileIdx { get; private set; } = -1;

		/// <summary>Index of the step currently being run.</summary>
		public int currentStepIdx { get; private set; }= -1;

		/// <summary>Data about the current test.</summary>
		public TestSuiteTest currentTest { get; private set; }

		/// <summary>Data about the current test step.</summary>
		public TestSuiteStep currentStep { get; private set; }

		/// <summary>Alternative folder to search for includes in.</summary>
		public string altIncludesFolder;

		/// <summary>Latest unhandled warning about the test suite management procedures, if any.</summary>
		private string managementWarning = "";

		/// <summary>Suite execution start time.</summary>
		private DateTime startTime;

		private string testResultsFullPath;

		private TestDefinitions _testDefinitions;
				
		public struct JsonTestResults
		{
			public int passed;
			public int failed;
			public int total;
			public Test[] testList;
		}

		public struct Test
		{
			public string name;
			public string file;
			public bool passed;
		}

		private JsonTestResults jsonTestResults = new JsonTestResults();

		#endregion

		#region Init and Terminate

		public void Init(string testDefinitionspath)
		{
			tests = new List<TestSuiteTest> ();
			fileList = new List<string> ();
			
			EventHandler.Instance.AddCallback ("DeleteTest", DeleteTest);
			EventHandler.Instance.AddCallback ("FailStep", FailCurrentStep);
			EventHandler.Instance.AddCallback ("FailTest", FailCurrentTest);
			EventHandler.Instance.AddCallback ("PassStep", PassCurrentStep);
			EventHandler.Instance.AddCallback ("PassTest", PassCurrentTest);
			EventHandler.Instance.AddCallback ("RegisterStep", RegisterStep);
			EventHandler.Instance.AddCallback ("RegisterTest", RegisterTest);
			EventHandler.Instance.AddCallback ("ReplaceTests", ReplaceList);
			EventHandler.Instance.AddCallback ("StartTests", StartSuite);
			EventHandler.Instance.AddCallback ("StopTests", StopSuite);
			EventHandler.Instance.AddCallback ("UpdateTestSuiteFromFolder", UpdateFromFolder);
			EventHandler.Instance.AddCallback ("TestSuiteError", TestSuiteError);
			
			AutonomousMode.Instance.Init(testDefinitionspath);
		}

		public void Terminate()
		{
			EventHandler.Instance.RemoveCallback ("DeleteTest", DeleteTest);
			EventHandler.Instance.RemoveCallback ("FailStep", FailCurrentStep);
			EventHandler.Instance.RemoveCallback ("FailTest", FailCurrentTest);
			EventHandler.Instance.RemoveCallback ("PassStep", PassCurrentStep);
			EventHandler.Instance.RemoveCallback ("PassTest", PassCurrentTest);
			EventHandler.Instance.RemoveCallback ("RegisterStep", RegisterStep);
			EventHandler.Instance.RemoveCallback ("RegisterTest", RegisterTest);
			EventHandler.Instance.RemoveCallback ("ReplaceTests", ReplaceList);
			EventHandler.Instance.RemoveCallback ("StartTests", StartSuite);
			EventHandler.Instance.RemoveCallback ("StopTests", StopSuite);
			EventHandler.Instance.RemoveCallback ("UpdateTestSuiteFromFolder", UpdateFromFolder);
			EventHandler.Instance.RemoveCallback ("TestSuiteError", TestSuiteError);
			tests = null;
			fileList = null;
			running = false;
			currentFileIdx = -1;
			currentStepIdx = -1;
			currentTest = null;
			currentStep = null;
			altIncludesFolder = null;
			managementWarning = "";
			testResultsFullPath = null;
			_testDefinitions = null;
			AutonomousMode.Instance.Terminate();
		}

		public void ConfigureTestDefinitions(TestDefinitions testDefinitions)
		{
			_testDefinitions = testDefinitions;
		}

		#endregion
		
		#region File management

		/// <summary>Deletes a test file from the folder.</summary>
		private void DeleteTest(string file, EventInfo? _)
		{
			File.Delete ("scripts/" + file);
			UpdateFromFolder("0");
		}

		/// <summary>Updates the list of tests by checking the folder.</summary>
		private void UpdateFromFolder (string reportMissingTests = "", EventInfo? _ = null)
		{
			if (reportMissingTests == "")
			{
				reportMissingTests = "1";
			}
			LoadJsonFile ();

			if (managementWarning.Length == 0)
			{
				managementWarning = "";
			}

			List<string> files = new List<string> ();
			if (Directory.Exists (TestsFolderName))
			{
				files = new List<string> (Directory.GetFiles (TestsFolderName, "*.js"));
			}

			// Clean the filenames.
			for (int f = 0; f < files.Count; f++)
			{
				files[f] = files[f].Split (new string[] { TestsFolderName + "/" }, StringSplitOptions.RemoveEmptyEntries)[0];
			}
			files.Sort (StringComparer.Ordinal);

			// Check if any file was added, but not present in our list.
			foreach (string f in files)
			{
				if (!fileList.Contains (f))
				{
					fileList.Add (f);
				}
			}

			// Check if any file is in the list, but not in the folder.
			List<string> removedFiles = new List<string> ();
			foreach (string e in fileList)
			{
				if (!files.Contains (e))
				{
					removedFiles.Add (e);
				}
			}

			if (removedFiles.Count > 0 && int.Parse(reportMissingTests) == 1)
			{
				managementWarning = "The following test files no longer exist: ";
				foreach (string e in removedFiles)
				{
					managementWarning += e + ", ";
				}
				managementWarning = managementWarning.Remove (managementWarning.Length - 2);
				managementWarning += ".";
				Logger.Instance.UpdateLog ("Test Suite Manager warning: " + managementWarning, LoggerType.Warning);
			}

			foreach (string e in removedFiles)
			{
				fileList.Remove (e);
			}

			SaveJsonFile ();
		}

		/// <summary>Updates the list of tests (json) with the content of the passed List of strings.</summary>
		public void UpdateFromList (List<string> testScriptPaths)
		{
			string reportMissingTests = "1";
			
			LoadJsonFile ();

			if (managementWarning.Length == 0)
			{
				managementWarning = "";
			}

			// Check if any file is in the list, but not in the folder.
			List<string> removedFiles = new List<string> ();
			foreach (string e in fileList)
			{
				if (!testScriptPaths.Contains (e))
				{
					removedFiles.Add (e);
				}
			}

			if (removedFiles.Count > 0 && int.Parse(reportMissingTests) == 1)
			{
				managementWarning = "The following test files no longer exist: ";
				foreach (string e in removedFiles)
				{
					managementWarning += e + ", ";
				}
				managementWarning = managementWarning.Remove (managementWarning.Length - 2);
				managementWarning += ".";
				Logger.Instance.UpdateLog ("Test Suite Manager warning: " + managementWarning, LoggerType.Warning);
			}
			
			// Clears the fileList that is going to load the new test suite
			fileList.Clear();
			
			// Loads the fileList with the new list of test scripts
			foreach (string f in testScriptPaths)
			{
				fileList.Add (f);
			}
			
			SaveJsonFile ();
		}

		/// <summary>Returns a string representing a warning that has occurred with the test suite management, if any.</summary>
		public string PopManagementWarning ()
		{
			string s = managementWarning;
			managementWarning = "";
			return s;
		}

		/// <summary>Saves the list onto the JSON file on-disk.</summary>
		private void SaveJsonFile ()
		{
			try
			{
				using (StreamWriter fs = new StreamWriter (SuiteFileName))
				{
					fs.Write (JsonConvert.SerializeObject (fileList, Formatting.Indented));
				}
			}
			catch (Exception ex)
			{
				Logger.Instance.UpdateLog ("Failed to save " + SuiteFileName + ". Exception: " + ex);
			}
		}

		/// <summary>Loads the list from the JSON file on-disk.</summary>
		private void LoadJsonFile ()
		{
			try
			{
				using (StreamReader fs = new StreamReader (SuiteFileName))
				{
					fileList = JsonConvert.DeserializeObject<List<string>> (fs.ReadToEnd ());
				}
			}
			catch
			{
				fileList.Clear ();
			}
		}

		/// <summary>Saves the results onto a text file.</summary>
		private void SaveResults ()
		{
			jsonTestResults.testList= new Test[fileList.Count];

			if (fileList.Count == 0)
			{
				return;
			}

			if (!Directory.Exists (ATNames.Instance.FolderTestResults))
			{
				Directory.CreateDirectory (ATNames.Instance.FolderTestResults);
			}

			string fileName = startTime.ToString (ATNames.Instance.DateTimePattern) + ".txt";
			testResultsFullPath = ATNames.Instance.FolderTestResults + "/" + fileName;
			using (StreamWriter f = new StreamWriter (testResultsFullPath))
			{
				int passedSteps = 0;
				int failedSteps = 0;
				bool lastTestInProgress = false;
				bool lastStepInProgress = false;
				f.WriteLine("AuSy v" + ProgramProperties.Version + "\n");
				f.WriteLine (startTime.ToString (ATNames.Instance.DateTimePattern) + " Test suite started, with " + fileList.Count + " script files.");

				for (int t = 0; t < tests.Count; t++)
				{
					TestSuiteTest tObj = tests[t];
					lastTestInProgress = true;
					f.WriteLine (tObj.startTime.ToString (ATNames.Instance.DateTimePattern) + " Started test " + (t + 1) + ": \"" + tObj.name + "\" (file \"" + tObj.testFile + "\").");

					for (int s = 0; s < tObj.steps.Count; s++)
					{
						TestSuiteStep sObj = tObj.steps[s];
						lastStepInProgress = true;
						f.WriteLine (sObj.startTime.ToString (ATNames.Instance.DateTimePattern) + "   Started step " + (s + 1) + ": \"" + sObj.name + "\".");
						if (sObj.result != TestResult.Unfinished)
						{
							lastStepInProgress = false;
							f.WriteLine (sObj.endTime.ToString (ATNames.Instance.DateTimePattern) + "   Step " + (sObj.result == TestResult.Pass ? "passed" : "failed") + ".");
							if (sObj.result == TestResult.Pass)
							{
								passedSteps++;
							}
							else
							{
								failedSteps++;
							}
						}
					}

					if (tObj.result != TestResult.Unfinished)
					{
						lastTestInProgress = false;
						f.WriteLine(tObj.endTime.ToString(ATNames.Instance.DateTimePattern) + " Test " +
						            (tObj.result == TestResult.Pass ? "passed" : "failed") + ".");
						jsonTestResults.testList[t].name = tObj.name;
						string[] filePath = tObj.testFile.Split('/');
						jsonTestResults.testList[t].file = filePath[filePath.Length - 1];
						jsonTestResults.testList[t].passed = (tObj.result == TestResult.Pass ? true : false);
					}
				}

				if (lastStepInProgress)
				{
					f.WriteLine ("Last step did not finish.");
				}
				if (lastTestInProgress)
				{
					f.WriteLine ("Last test did not finish.");
				}

				f.WriteLine ();
				f.WriteLine ("Result:");
				f.WriteLine ("  Finished " + (GetPassCount () + GetFailCount ()) + "/" + fileList.Count + " tests. " + GetPassCount () + " passed. " + GetFailCount () + " failed.");
				f.WriteLine ("  Finished " + (passedSteps + failedSteps) + " steps in total. " + passedSteps + " passed. " + failedSteps + " failed.");

				jsonTestResults.passed = GetPassCount();
				jsonTestResults.failed = GetFailCount();
				jsonTestResults.total = fileList.Count;

			}
		}

		#endregion
		
		#region Test control

		/// <summary>Start the test suite execution.</summary>
		private void StartSuite (string _, EventInfo? __)
		{
			if (running)
			{
				EventHandler.Instance.Trigger("JsOutput", "Cannot start suite -- a previous suite is already running.");
				EventHandler.Instance.Trigger("TestSuiteError", "Previous test suite already running");
				return;
			}
			
			if (fileList.Count == 0)
			{
				EventHandler.Instance.Trigger("JsOutput", "Cannot start suite -- there are no test files to run.");
				EventHandler.Instance.Trigger("TestSuiteError", "No scripts to run");
				return;
			}

			running = true;
			currentFileIdx = -1;
			currentStepIdx = 0;
			startTime = DateTime.Now;
			tests.Clear ();
			EventHandler.Instance.Trigger("JsOutput", "Starting test suite with " + fileList.Count + " test files.");
			nextStep ();
			nextTest ();
		}

		/// <summary>Stop the test suite execution.</summary>
		private void StopSuite (string _, EventInfo? __)
		{
			if (fileList.Count == 0 || !running)
			{
				EventHandler.Instance.Trigger("JsOutput", "Cannot stop suite -- no test suite is running.");
				return;
			}
			
			EventHandler.Instance.Trigger("ResetJsEngine", "");
			running = false;
			EventHandler.Instance.Trigger("JsOutput", "Finished " + (GetPassCount () + GetFailCount ()) + "/" + fileList.Count + " tests. " + GetPassCount () + " passed, " + GetFailCount () + " failed.");
			SaveResults ();
			if (_testDefinitions != null)
			{
				runPythonScript();
			}

			EventHandler.Instance.Trigger("TestSuiteEnded", "");
		}

		/// <summary>Consider the current test a pass and move to the next.</summary>
		private void PassCurrentTest (string _, EventInfo? __)
		{
			if (!running)
			{
				return;
			}
			
			if(currentTest == null)
			{
				EventHandler.Instance.Trigger("JsOutput", "Cannot pass test -- the script is not currently inside a test. (Did you forget to register the test?)");
				return;
			}

			currentTest.result = TestResult.Pass;
			EventHandler.Instance.Trigger("JsOutput", "Test " + (currentFileIdx + 1) + " '" + currentTest.name + "' - Pass");

			nextTest ();
		}

		/// <summary>Consider the current step a pass and move to the next.</summary>
		private void PassCurrentStep (string _, EventInfo? __)
		{
			if (!running)
			{
				return;
			}

			if (currentTest == null)
			{
				EventHandler.Instance.Trigger("JsOutput", "Cannot pass step -- the script is not currently inside a test. (Did you forget to register the test?)");
				return;
			}
			
			if(currentStep == null)
			{
				EventHandler.Instance.Trigger("JsOutput", "Cannot pass step -- the script is not currently inside a step. (Did you forget to register the step?)");
				return;
			}

			currentStep.result = TestResult.Pass;
			EventHandler.Instance.Trigger("JsOutput", "Step " + (currentStepIdx + 1) + " '" + currentStep.name + "' - Pass");
			nextStep ();
		}

		/// <summary>Consider the current test a fail and move to the next.</summary>
		private void FailCurrentTest (string _, EventInfo? __)
		{
			if (!running)
			{
				return;
			}
			
			if(currentTest == null)
			{
				EventHandler.Instance.Trigger("JsOutput", "Cannot fail test -- the script is not currently inside a test. (Did you forget to register the test?)");
				return;
			}

			currentTest.result = TestResult.Fail;
			EventHandler.Instance.Trigger("JsOutput", "Test " + (currentFileIdx + 1) + " '" + currentTest.name + "' - FAIL");
			nextTest ();
		}

		/// <summary>Consider the current step a fail and move to the next.</summary>
		private void FailCurrentStep (string _, EventInfo? __)
		{
			if (!running)
			{
				return;
			}

			if (currentTest == null)
			{
				EventHandler.Instance.Trigger("JsOutput", "Cannot fail step -- the script is not currently inside a test. (Did you forget to register the test?)");
				return;
			}
			
			if(currentStep == null)
			{
				EventHandler.Instance.Trigger("JsOutput", "Cannot fail step -- the script is not currently inside a step. (Did you forget to register the step?)");
				return;
			}

			currentStep.result = TestResult.Fail;
			EventHandler.Instance.Trigger("JsOutput", "Step " + (currentStepIdx + 1) + " '" + currentStep.name + "' - FAIL");
			nextStep ();
		}

		/// <summary>Registers the info for the current test.</summary>
		private void RegisterTest (string testName, EventInfo? _)
		{
			if (!running)
			{
				return;
			}
			
			if(currentTest != null)
			{
				EventHandler.Instance.Trigger("JsOutput", $"Cannot register test \"{testName}\" -- the script is already currently inside a test (\"{currentTest.name}\").");
				return;
			}

			currentTest = new TestSuiteTest
			{
				name = testName,
				startTime = DateTime.Now,
				testFile = fileList[currentFileIdx]
			};
			tests.Add (currentTest);
			currentStep = null;
		}

		/// <summary>Registers the info for the current step.</summary>
		private void RegisterStep (string stepName, EventInfo? _)
		{
			if (!running)
			{
				return;
			}
			
			if (currentTest == null)
			{
				EventHandler.Instance.Trigger("JsOutput", $"Cannot register step \"{stepName}\" -- the script is not currently inside a test. (Did you forget to register the test?)");
				return;
			}

			if(currentStep != null)
			{
				EventHandler.Instance.Trigger("JsOutput", $"Cannot register step \"{stepName}\" -- the script is already currently inside a step (\"{currentStep.name}\").");
				return;
			}
			
			currentStep = new TestSuiteStep
			{
				name = stepName,
				startTime = DateTime.Now
			};
			currentTest.steps.Add (currentStep);
		}

		/// <summary>Advance to the next test, or the first one.</summary>
		private void nextTest ()
		{
			if (!running)
			{
				return;
			}

			if (currentTest != null)
			{
				currentTest.endTime = DateTime.Now;
			}

			if (currentFileIdx < fileList.Count - 1)
			{
				currentFileIdx++;
				currentTest = null;
				currentStepIdx = 0;
				currentStep = null;
				EventHandler.Instance.Trigger("ResetJsEngine", "");
				EventHandler.Instance.Trigger("SetAltIncludesFolder", altIncludesFolder);
				EventHandler.Instance.Trigger("RunJsFile", fileList[currentFileIdx]);
			}
			else
			{
				StopSuite (null, null);
			}
		}

		/// <summary>Advance to the next step, or the first one.</summary>
		private void nextStep ()
		{
			if (!running || currentTest == null)
			{
				return;
			}

			if (currentStep != null)
			{
				currentStep.endTime = DateTime.Now;
			}

			currentStepIdx++;
			currentStep = null;
		}

		private void runPythonScript()
		{
			var script = _testDefinitions.ReportScript;
			RunCommand shell = new RunCommand ();
			shell.RunExeCommand("python2", script +" "+ testResultsFullPath, true);
		}

		private void TestSuiteError(string errorReason, EventInfo? _)
		{
			if (_testDefinitions != null)
			{
				saveErrorResults(errorReason);
				runPythonScript();
			}
		}

		private void saveErrorResults(string errorReason)
		{
			if (!Directory.Exists (ATNames.Instance.FolderTestResults))
			{
				Directory.CreateDirectory (ATNames.Instance.FolderTestResults);
			}

			string fileName = DateTime.Now.ToString(ATNames.Instance.DateTimePattern) + ".txt";
			testResultsFullPath = ATNames.Instance.FolderTestResults + "/" + fileName;
			using (StreamWriter f = new StreamWriter (testResultsFullPath))
			{
				if (errorReason != String.Empty)
				{
					f.WriteLine ("The testSuite didn't run properly. Error: " + errorReason);
				}
				else
				{
					f.WriteLine ("The testSuite didn't run properly.");
				}
			}
		}

		#endregion
		
		#region List replacement

		/// <summary>Replaces the list with a list given by some other source.</summary>
		private void ReplaceList (string newList, EventInfo? _)
		{
			fileList = new List<string>(newList.Split(';'));
			SaveJsonFile ();
		}

		#endregion
		
		#region Aux

		/// <summary>Returns how many tests have passed.</summary>
		/// <returns>How many tests have passed.</returns>
		public int GetPassCount ()
		{
			int count = 0;
			foreach (TestSuiteTest t in tests)
			{
				if (t.result == TestResult.Pass)
				{
					count++;
				}
			}
			return count;
		}

		/// <summary>Returns how many tests have failed.</summary>
		/// <returns>How many tests have failed.</returns>
		public int GetFailCount ()
		{
			int count = 0;
			foreach (TestSuiteTest t in tests)
			{
				if (t.result == TestResult.Fail)
				{
					count++;
				}
			}
			return count;
		}

		#endregion
	}
	
	
	/// <summary>Possible test results.</summary>
	public enum TestResult
	{
		Pass,
		Fail,
		Unfinished,
	}

	/// <summary>A test in a test suite.</summary>
	public class TestSuiteTest
	{
		/// <summary>Registered test name.</summary>
		public string name = TestManager.DefaultTestName;

		/// <summary>Test result.</summary>
		public TestResult result = TestResult.Unfinished;

		/// <summary>Test steps, if any.</summary>
		public List<TestSuiteStep> steps = new List<TestSuiteStep> ();

		/// <summary>Test start time.</summary>
		public DateTime startTime;

		/// <summary>Test end time.</summary>
		public DateTime endTime;

		/// <summary>Script file for the test.</summary>
		public string testFile;
	}

	/// <summary>A step in a test suite's test.</summary>
	public class TestSuiteStep
	{
		/// <summary>Registered step name.</summary>
		public string name = TestManager.DefaultStepName;

		/// <summary>Step result.</summary>
		public TestResult result = TestResult.Unfinished;

		/// <summary>Step start time.</summary>
		public DateTime startTime;

		/// <summary>Step end time.</summary>
		public DateTime endTime;
	}
}
