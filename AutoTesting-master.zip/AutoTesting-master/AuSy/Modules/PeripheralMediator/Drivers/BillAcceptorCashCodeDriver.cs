﻿using System;
using System.IO.Ports;
using System.Text;
using System.Threading;
using AutoTestingService;
using AutoTestingService.Logging;
using EventHandler = AutoTestingService.EventHandler;

namespace AuSy.Modules.PeripheralMediator.Drivers
{
	public sealed class BillAcceptorCashCodeDriver : IBillAcceptorDriver
	{
		public static BillAcceptorCashCodeDriver Instance { get; private set; } = new BillAcceptorCashCodeDriver ();

		#region Variables

		public bool QuitBillAcceptorCashcodeWorkerThread;
		public bool DebugCashCode;
		
		private SerialPort serialPort;
		//private Track _track1;
		private CashcodeCommand cashcodeCommand;
		private CashcodeResponse cashcodeResponse;
		private bool initialized = false;
		private byte[] rxData = new byte[1024];
		private byte[] tempData = new byte[1024];
		private int bytes;
		private int loopTime;
		private int count = 0;
		private CashcodeState state;
		private bool gotAck;
		private bool connected;
		private bool ticket = false;
		


		Thread processThread;

		#endregion
		/// <summary>Initializes a new instance of the <see cref="AutoTestingClient.BillAcceptorCashCodeDriver"/> class.</summary>
		//public CardReaderMagtekDriver ()
		//{
		//	QuitCardReaderMagtekWorkerThread = false;
		//}

		/// <summary>Releases unmanaged resources and performs other cleanup operations before the
		/// <see cref="AutoTestingClient.BillAcceptorCashCodeDriver"/> is reclaimed by garbage collection.</summary>
		~BillAcceptorCashCodeDriver ()
		{
			Terminate ();
		}

		#region Init

		/// <summary>Initializes this instance.</summary>
		public void Init (string port)
		{
			
			EventHandler.Instance.AddCallback("ResetBillAcceptor", resetStateToOff);
			EventHandler.Instance.AddCallback("PrintCurrentState", PrintCurrentState);

			loopTime = 25;
			state = CashcodeState.Unknown;
			BuildCashcodeCommands ();     // Build the Cashcode Commmands
			BuildCashcodeResponses ();
			setupSerialPort (port);         // Serial Port Initialization

			processThread = new Thread (BACashcodethread)
			{
				Name = "CashCode Bill Acceptor Thread"
			};

			try
			{
				serialPort.Open ();
				Logger.Instance.UpdateLog ("CashCode bill acceptor opened serial port " + port + " successfully.", LoggerType.Develop);
			}
			catch (Exception ex)
			{
				Logger.Instance.UpdateLog ("CashCode bill acceptor could not open serial port " + port + ": " + ex, LoggerType.Error);
				Environment.Exit (1);
			}

			processThread.Start ();

			initialized = true;
		}

		/// <summary>Terminates this instance.</summary>
		public void Terminate ()
		{
			try
			{
				if (serialPort.IsOpen)
				{
					serialPort.DtrEnable = false;
					serialPort.RtsEnable = false;
					serialPort.DiscardInBuffer ();
					serialPort.DiscardOutBuffer ();
					serialPort.Close ();
				}
			}
			catch (Exception ex)
			{
				Logger.Instance.UpdateLog ("Serial port closing exception: " + ex, LoggerType.Warning);
			}

			QuitBillAcceptorCashcodeWorkerThread = true;
			if (initialized)
			{
				processThread.Join ();
			}
		}

		/// <summary>Sets up the Serial Port.</summary>
		private void setupSerialPort (string port)
		{
			serialPort = new SerialPort
			{
				// Set the appropriate properties for a CashCode bill acceptor.
				PortName = port,
				BaudRate = 9600,
				Parity = DriverUtils.Instance.ParseParity ("even"),
				DataBits = 8,
				StopBits = DriverUtils.Instance.ParseStopBits ("1"),
				Handshake = DriverUtils.Instance.ParseHandshake ("none"),
				RtsEnable = true,
				DtrEnable = true,
				ReadTimeout = 250,
				WriteTimeout = 250
			};
		}

		/// <summary>Resets the state of the acceptor to the IdlingEnabled state, so that it may start
		/// accepting bills.</summary>
		public void resetStateToIdling ()
		{
			state = CashcodeState.IdlingEnabled;
		}

		/// <summary>Resets the state of the acceptor to the Off state, so that it may start
		/// a new connection with the game.</summary>
		private void resetStateToOff (string _, EventInfo? __)
		{
			state = CashcodeState.Off;
		}
		private void PrintCurrentState (string _, EventInfo? __)
		{
			Console.WriteLine("Cashcode Driver current state is " + state);
		}
		
		
		
		
		
		/// <summary>Resets the state of the acceptor to the Powering Up state, so that it may start
		/// a new connection with the game.</summary>
		private void resetStateToPoweringUp ()
		{
			state = CashcodeState.PoweringUp;
		}

		/// <summary>Resets the state of the acceptor to the Unknown state, so that it may start
		/// figuring out the connection with the game again.</summary>
		private void resetStateToUnknown ()
		{
			state = CashcodeState.Unknown;
		}

		#endregion

		#region Input

		/// <summary>CashCode bill acceptor worker thread.</summary>
		private void BACashcodethread ()
		{
			if (!serialPort.IsOpen)
			{
				return;
			}

			serialPort.DiscardInBuffer ();
			serialPort.DiscardOutBuffer ();
			while (!QuitBillAcceptorCashcodeWorkerThread)
			{
				try
				{
					int read = serialPort.Read (tempData, 0, 1024);
					byte[] temp = new byte[read];
					rxData = tempData;
					bytes = rxData.Length;
					for (int i = 0; i < read; i++)
					{
						temp[i] = rxData[i];
					}
					if (rxData[1] != read)
					{
						Logger.Instance.UpdateLog ("Total number of bytes in the message is incorrect.", LoggerType.Error);
					}
					Logger.Instance.UpdateLog ("STATE [" + state + "]" + ", Serial port got: [" + BitConverter.ToString (temp) + "]", LoggerType.Develop);

					if (checkFrameIntegrity ())
					{   // Check frame integrity
						if (!connected)
						{
							connected = true;
							Logger.Instance.UpdateLog ("Connection established with serial port.", LoggerType.Develop);
						}
						processNewFrame ();
					}
				}
				catch (Exception ex)
				{
					if (ex.Message.Equals ("The operation has timed out."))
					
					{
					}
				}
				Thread.Sleep (loopTime);
			}
		}

		/// <summary>Checks the frame integrity.</summary>
		/// <returns><c>true</c>, if frame integrity was ok, <c>false</c> otherwise.</returns>
		private bool checkFrameIntegrity ()
		{
			if (bytes <= 0)
			{   // 1 - Nothin read or read failed
				return false;
			}

			return true;
		}

		/// <summary>Processes the new frame. </summary>
		/// <returns><c>true</c>, if new frame was processed successfully, <c>false</c> otherwise.</returns>
		private bool processNewFrame ()
		{
			bool result = false;
			if (bytes > 3)
			{
				byte stxByte = rxData[0];
				byte sizeByte = rxData[1];
				byte commandByte = rxData[2];
				byte[] crc = new byte[2];

				if (stxByte != Constants.STX)
				{
					Console.WriteLine ("Message didn't begin with command 0xFC.");
					return result;
				}

				// Resolve some error cases.
				if (commandByte == cashcodeCommand.VERSION_REQUEST[2])
				{
					// Override the state back to powering up, since the game wants to boot up.
					Logger.Instance.UpdateLog ("Resetting bill acceptor due to game reset...");
					resetStateToPoweringUp ();
					
				}
				else if (commandByte == cashcodeCommand.POLLING[2])
				{
					switch(state)
					{
					case CashcodeState.Unknown:
						// Assume power off state.
						resetStateToOff ("", null);
						break;
					}
					
				}
				else if (commandByte == cashcodeCommand.INHIBIT[2])
				{
					switch (state)
					{
					case CashcodeState.Unknown:
						// The game only sends INHIBIT after the login phase.
						// So the acceptor is actually meant to be in a regular idle state.
						resetStateToIdling();
						break;
					case CashcodeState.Escrow:
						// The driver is stuck in escrow and the game wants something else. Reset.
						Logger.Instance.UpdateLog ("Cancelling bill acceptor bill in due to desync with game, and resetting to idle...");
						resetStateToIdling();
						break;
					}
				}

				switch (state)
				{
				case CashcodeState.Off:
					if (commandByte == cashcodeCommand.POLLING[2])
					{
						sendResponse (cashcodeResponse.DISABLE);
						state = CashcodeState.PoweringUp;
						result = true;
					}
					break;
				case CashcodeState.PoweringUp:

					if (commandByte == cashcodeCommand.VERSION_REQUEST[2])
					{
						sendResponse (cashcodeResponse.VERSION_INFORMATION);
						result = true;
					}
					if (commandByte == cashcodeCommand.RESET[2])
					{
						sendResponse (cashcodeResponse.ACK);
						state = CashcodeState.Initializing;
						result = true;
					}
					break;
				case CashcodeState.Initializing:
					if (commandByte == cashcodeCommand.POLLING[2])
					{
						sendResponse (cashcodeResponse.INITIALIZE);
						if (count++ == 3)
						{
							state = CashcodeState.FirstIdling;
							count = 0;
						}
						result = true;
					}
					else if (commandByte == 0xC2)
					{
						sendResponse (cashcodeResponse.COMMUNICATION_MODE);
						result = true;
					}
					else if (commandByte == 0xC5)
					{
						sendResponse (cashcodeResponse.OPTIONAL_FUNCTION);
						result = true;
					}
					else if (commandByte == 0xC6)
					{
						sendResponse (cashcodeResponse.BARCODE_FUNCTION);
						result = true;
					}
					else if (commandByte == 0xC7)
					{
						sendResponse (cashcodeResponse.BAR_INHIBIT);
						result = true;
					}
					else
					{
						sendResponse (rxData);
						result = true;
					}

					break;
				case CashcodeState.FirstIdling:
					if (commandByte == cashcodeCommand.POLLING[2])
					{
						state = CashcodeState.IdlingDisabled;
						sendResponse (cashcodeResponse.DISABLE);
						result = true;
					}
					break;
				case CashcodeState.IdlingDisabled:
					if (commandByte == cashcodeCommand.POLLING[2])
					{
						sendResponse (cashcodeResponse.ENABLE);
						result = true;
					}
					else if (commandByte == cashcodeCommand.INHIBIT[2])
					{
						if (rxData[3] == 0x00)
						{
							state = CashcodeState.IdlingEnabled;
						}
						cashcodeResponse.INHIBIT[3] = rxData[3];
						crc = DriverUtils.CalcCRC (cashcodeResponse.INHIBIT);
						cashcodeResponse.INHIBIT[4] = crc[0];
						cashcodeResponse.INHIBIT[5] = crc[1];
						sendResponse (cashcodeResponse.INHIBIT);
						result = true;
					}
					break;


				case CashcodeState.IdlingEnabled:
					if (commandByte == cashcodeCommand.POLLING[2])
					{
						sendResponse (cashcodeResponse.ENABLE);
						result = true;
					}
					else if (commandByte == cashcodeCommand.INHIBIT[2])
					{
						if (rxData[3] == 0x01)
						{
							state = CashcodeState.IdlingDisabled;
						}
						cashcodeResponse.INHIBIT[3] = rxData[3];
						crc = DriverUtils.CalcCRC (cashcodeResponse.INHIBIT);
						cashcodeResponse.INHIBIT[4] = crc[0];
						cashcodeResponse.INHIBIT[5] = crc[1];
						sendResponse (cashcodeResponse.INHIBIT);
						result = true;
					}
					break;

				case CashcodeState.InsertingBill:

					if (commandByte == cashcodeCommand.POLLING[2])
					{
						state = CashcodeState.Accepting;
						sendResponse (cashcodeResponse.ACCEPTING);
						sendResponse (cashcodeResponse.ENQ);
						result = true;
					}
					break;

				case CashcodeState.Accepting:

					if (commandByte == cashcodeCommand.POLLING[2])
					{
						{
							if (ticket)
							{
								sendResponse (cashcodeResponse.ESCROW_TICKET);
							}
							else
							{
								sendResponse (cashcodeResponse.ESCROW_BILL);
							}
							state = CashcodeState.Escrow;
							count = 0;
							return true;
						}
					}
					break;
				case CashcodeState.Escrow:

					if (commandByte == cashcodeCommand.STACK1[2])
					{
						sendResponse (cashcodeResponse.ACK);
						sendResponse (cashcodeResponse.ENQ);
						return true;
					}
					else if (commandByte == cashcodeCommand.HOLD[2])
					{
						sendResponse (cashcodeResponse.ACK);
						result = true;
					}
					else if (commandByte == cashcodeCommand.POLLING[2])
					{
						state = CashcodeState.Stacking;
						sendResponse (cashcodeResponse.STAKING);
						sendResponse (cashcodeResponse.ENQ);
						result = true;
					}
					break;

				case CashcodeState.Stacking:

					if (commandByte == cashcodeCommand.POLLING[2])
					{
						state = CashcodeState.VendValid;
						sendResponse (cashcodeResponse.VEND_VALID);
						sendResponse (cashcodeResponse.ENQ);
						result = true;
					}
					break;

				case CashcodeState.VendValid:

					if (commandByte == cashcodeCommand.ACK[2] && !gotAck)
					{
						gotAck = true;
						sendResponse (cashcodeResponse.ENQ);
						result = true;
					}
					else if (commandByte == cashcodeCommand.POLLING[2] && gotAck)
					{
						sendResponse (cashcodeResponse.STACKED);
						sendResponse (cashcodeResponse.ENQ);
						gotAck = false;
						state = CashcodeState.IdlingEnabled;
						result = true;
					}
					else if (commandByte == cashcodeCommand.INHIBIT[2] && gotAck && DebugCashCode)
					{
						sendResponse (cashcodeResponse.STACKED);
						sendResponse (cashcodeResponse.ENQ);
						gotAck = false;
						state = CashcodeState.IdlingDisabled;
						result = true;
					}
					break;

				case CashcodeState.Stacked:
					if (commandByte == cashcodeCommand.POLLING[2])
					{
						sendResponse (cashcodeResponse.STACKED);
						sendResponse (cashcodeResponse.ENQ);
						state = CashcodeState.IdlingEnabled;
						result = true;
					}
					break;
				}

			}
			return result;
		}

		#endregion

		#region Output

		/// <summary>Sends the response to the serial port.</summary>
		/// <param name="response">Response.</param>
		private void sendResponse (byte[] response)
		{
			if (serialPort.IsOpen)
			{
				try
				{
					serialPort.Write (response, 0, response[1]);
					byte[] trimmedResponse = new byte[response[1]];
					for (int i = 0; i < response[1]; i++)
					{
						trimmedResponse[i] = response[i];
					}
					Logger.Instance.UpdateLog ("STATE [" + state + "]" + ", Serial port wrote: [" + BitConverter.ToString (trimmedResponse) + "]", LoggerType.Develop);


				}
				catch (Exception ex)
				{
					Logger.Instance.UpdateLog ("Serial port write exception: " + ex, LoggerType.Error);
					resetStateToUnknown ();
				}
			}
		}

		#endregion

		#region Interface methods

		public InsertBillError InsertBill (int value)
		{
			PrintCurrentState("",new EventInfo());
			InsertBillError result = InsertBillError.None;
			ticket = false;
			if (value > 7)
			{
				result = InsertBillError.UnsupportedBill;
			}
			else
			{
				byte[] crc = new byte[2];
				if (state == CashcodeState.Unknown || state == CashcodeState.Accepting)
				{
					// AuSy is requesting a cash in. Assume idle state, start the cash in, and hope for the best.
					resetStateToIdling ();
				}

				if (state == CashcodeState.InsertingBill || state == CashcodeState.VendValid)
				{
					resetStateToOff("",new EventInfo());
				}
				switch (state)
				{
					case CashcodeState.IdlingEnabled:
						state = CashcodeState.InsertingBill;
						cashcodeResponse.ESCROW_BILL[3] = DriverUtils.Instance.BillDict[value];
						crc = DriverUtils.CalcCRC (cashcodeResponse.ESCROW_BILL);
						cashcodeResponse.ESCROW_BILL[4] = crc[0];
						cashcodeResponse.ESCROW_BILL[5] = crc[1];
						sendResponse (cashcodeResponse.ENQ);
						Logger.Instance.UpdateLog ("Sent ACCEPTING", LoggerType.Warning);
						result = InsertBillError.None;
						break;
					case CashcodeState.Stacked:
						Console.WriteLine("XUPA NEIDE");
						//result = InsertBillError.StackerFull;
						break;
					default: 
						result = InsertBillError.BillRejectedBadState;
						break;
				}
			}
			
			
			
			return result;
		}

		public InsertTicketError InsertTicket (string validation_code)
		{
			PrintCurrentState("",new EventInfo());
			ticket = true;
			byte[] crc = new byte[2];
			byte[] validCodeASCII = Encoding.ASCII.GetBytes (validation_code);
			Console.WriteLine (validCodeASCII.Length);
			switch (state)
			{
			case CashcodeState.IdlingEnabled:
				for (int i = 0; i < validCodeASCII.Length; i++)
				{
					cashcodeResponse.ESCROW_TICKET[i + 4] = validCodeASCII[i];
					Console.WriteLine (i + ": " + validCodeASCII[i] + ", ");
				}
				state = CashcodeState.InsertingBill;
				crc = DriverUtils.CalcCRC (cashcodeResponse.ESCROW_TICKET);
				cashcodeResponse.ESCROW_TICKET[22] = crc[0];
				cashcodeResponse.ESCROW_TICKET[23] = crc[1];
				sendResponse (cashcodeResponse.ENQ);
				Logger.Instance.UpdateLog ("Sent ACCEPTING", LoggerType.Warning);
				return InsertTicketError.None;
			case CashcodeState.Stacked:
				return InsertTicketError.StackerFull;
			}
			return InsertTicketError.TicketRejected;
		}

		#endregion

		#region Cashcode specific

		struct CashcodeCommand
		{
			public CashcodeCommand (bool notUsed = true)
			{
				POLLING = new byte[5];
				ACK = new byte[5];
				RESET = new byte[5];
				STACK1 = new byte[5];
				STACK2 = new byte[5];
				RETURN = new byte[5];
				HOLD = new byte[5];
				WAIT = new byte[5];
				ENABLE = new byte[7];
				DISABLE = new byte[7];
				SECURITY = new byte[7];
				COMM_MODE = new byte[6];
				INHIBIT = new byte[6];
				DIRECTION = new byte[6];
				OPTIONAL = new byte[7];
				BARCODE = new byte[7];
				BAR_INHIBIT = new byte[6];
				VERSION_REQUEST = new byte[5];
			}

			public byte[] POLLING;
			public byte[] ACK;
			public byte[] RESET;
			public byte[] STACK1;
			public byte[] STACK2;
			public byte[] RETURN;
			public byte[] HOLD;
			public byte[] WAIT;
			public byte[] ENABLE;
			public byte[] DISABLE;
			public byte[] SECURITY;
			public byte[] COMM_MODE;
			public byte[] INHIBIT;
			public byte[] DIRECTION;
			public byte[] OPTIONAL;
			public byte[] BARCODE;
			public byte[] BAR_INHIBIT;
			public byte[] VERSION_REQUEST;
		};

		void BuildCashcodeCommands ()
		{
			byte[] crc = new byte[2];
			cashcodeCommand = new CashcodeCommand (true);

			cashcodeCommand.POLLING[0] = Constants.STX;
			cashcodeCommand.POLLING[1] = Constants.STANDARDLENGTH;
			cashcodeCommand.POLLING[2] = 0x11;
			crc = DriverUtils.CalcCRC (cashcodeCommand.POLLING);
			cashcodeCommand.POLLING[3] = crc[0];
			cashcodeCommand.POLLING[4] = crc[1];

			cashcodeCommand.ACK[0] = Constants.STX;
			cashcodeCommand.ACK[1] = Constants.STANDARDLENGTH;
			cashcodeCommand.ACK[2] = Constants.ACK;
			crc = DriverUtils.CalcCRC (cashcodeCommand.ACK);
			cashcodeCommand.ACK[3] = crc[0];
			cashcodeCommand.ACK[4] = crc[1];

			cashcodeCommand.RESET[0] = Constants.STX;
			cashcodeCommand.RESET[1] = Constants.STANDARDLENGTH;
			cashcodeCommand.RESET[2] = 0x40;
			crc = DriverUtils.CalcCRC (cashcodeCommand.RESET);
			cashcodeCommand.RESET[3] = crc[0];
			cashcodeCommand.RESET[4] = crc[1];

			cashcodeCommand.STACK1[0] = Constants.STX;
			cashcodeCommand.STACK1[1] = Constants.STANDARDLENGTH;
			cashcodeCommand.STACK1[2] = 0x41;
			crc = DriverUtils.CalcCRC (cashcodeCommand.STACK1);
			cashcodeCommand.STACK1[3] = crc[0];
			cashcodeCommand.STACK1[4] = crc[1];

			cashcodeCommand.STACK2[0] = Constants.STX;
			cashcodeCommand.STACK2[1] = Constants.STANDARDLENGTH;
			cashcodeCommand.STACK2[2] = 0x42;
			crc = DriverUtils.CalcCRC (cashcodeCommand.STACK2);
			cashcodeCommand.STACK2[3] = crc[0];
			cashcodeCommand.STACK2[4] = crc[1];

			cashcodeCommand.RETURN[0] = Constants.STX;
			cashcodeCommand.RETURN[1] = Constants.STANDARDLENGTH;
			//todo em binario este
			cashcodeCommand.RETURN[2] = 0x43;
			crc = DriverUtils.CalcCRC (cashcodeCommand.RETURN);
			cashcodeCommand.RETURN[3] = crc[0];
			cashcodeCommand.RETURN[4] = crc[1];

			cashcodeCommand.HOLD[0] = Constants.STX;
			cashcodeCommand.HOLD[1] = Constants.STANDARDLENGTH;
			cashcodeCommand.HOLD[2] = 0x44;
			crc = DriverUtils.CalcCRC (cashcodeCommand.HOLD);
			cashcodeCommand.HOLD[3] = crc[0];
			cashcodeCommand.HOLD[4] = crc[1];

			cashcodeCommand.WAIT[0] = Constants.STX;
			cashcodeCommand.WAIT[1] = Constants.STANDARDLENGTH;
			cashcodeCommand.WAIT[2] = 0x45;
			crc = DriverUtils.CalcCRC (cashcodeCommand.WAIT);
			cashcodeCommand.WAIT[3] = crc[0];
			cashcodeCommand.WAIT[4] = crc[1];


			//SETTINGS

			cashcodeCommand.ENABLE[0] = Constants.STX;
			cashcodeCommand.ENABLE[1] = (byte) cashcodeCommand.ENABLE.Length;
			cashcodeCommand.ENABLE[2] = 0xC0;
			cashcodeCommand.ENABLE[3] = 0x82;
			cashcodeCommand.ENABLE[4] = 0x00;
			crc = DriverUtils.CalcCRC (cashcodeCommand.ENABLE);
			cashcodeCommand.ENABLE[5] = crc[0];
			cashcodeCommand.ENABLE[6] = crc[1];

			cashcodeCommand.INHIBIT[0] = Constants.STX;
			cashcodeCommand.INHIBIT[1] = (byte) cashcodeCommand.INHIBIT.Length;
			cashcodeCommand.INHIBIT[2] = 0xC3;
			//crc = DriverUtils.CalcCRC (cashcodeCommand.INHIBIT);
			//cashcodeCommand.INHIBIT[4] = crc[0];
			//cashcodeCommand.INHIBIT[5] = crc[1];

			cashcodeCommand.DISABLE[0] = Constants.STX;
			cashcodeCommand.DISABLE[1] = (byte) cashcodeCommand.DISABLE.Length;
			cashcodeCommand.DISABLE[2] = 0xC0;
			cashcodeCommand.DISABLE[3] = 0x82;
			cashcodeCommand.DISABLE[4] = 0x01;
			crc = DriverUtils.CalcCRC (cashcodeCommand.DISABLE);
			cashcodeCommand.DISABLE[5] = crc[0];
			cashcodeCommand.DISABLE[6] = crc[1];

			cashcodeCommand.VERSION_REQUEST[0] = Constants.STX;
			cashcodeCommand.VERSION_REQUEST[1] = Constants.STANDARDLENGTH;
			cashcodeCommand.VERSION_REQUEST[2] = 0x88;
			crc = DriverUtils.CalcCRC (cashcodeCommand.VERSION_REQUEST);
			cashcodeCommand.VERSION_REQUEST[3] = crc[0];
			cashcodeCommand.VERSION_REQUEST[4] = crc[1];
		}

		struct CashcodeResponse
		{
			public CashcodeResponse (bool notUsed = true)
			{
				ENABLE = new byte[5];
				ACCEPTING = new byte[5];
				ESCROW_TICKET = new byte[24];
				ESCROW_BILL = new byte[6];
				STAKING = new byte[5];
				VEND_VALID = new byte[5];
				STACKED = new byte[5];
				REJECTING = new byte[6];
				RETURNING = new byte[5];
				HOLDING = new byte[5];
				DISABLE = new byte[5];
				INITIALIZE = new byte[5];
				POWER_UP = new byte[5];
				POWER_UP_BILL_IN_ACCEPTOR = new byte[5];
				POWER_UP_BILL_IN_STACKER = new byte[5];
				ERROR_STACKER_FULL = new byte[5];
				ERROR_STACKER_OPEN = new byte[5];
				ERROR_JAMMED_ACCEPTOR = new byte[5];
				ERROR_JAMMED_STACKER = new byte[5];
				ERROR_PAUSE = new byte[5];
				ERROR_CHEATED = new byte[5];
				ERROR_FAILURE = new byte[6];
				ERROR_COMM_ERROR = new byte[5];
				ACK = new byte[5];
				ENQ = new byte[5];
				INVALID = new byte[5];
				SETTINGS_ENABLE = new byte[7];
				SETTINGS_DISABLE = new byte[7];
				SECURITY = new byte[7];
				COMM_MODE = new byte[6];
				INHIBIT = new byte[6];
				DIRECTION = new byte[6];
				OPTIONAL = new byte[7];
				BARCODE = new byte[7];
				COMMUNICATION_MODE = new byte[6];
				BAR_INHIBIT = new byte[6];
				OPTIONAL_FUNCTION = new byte[7];
				BARCODE_FUNCTION = new byte[7];
				VERSION_INFORMATION = new byte[46]
					{
					  0xFC, 0x2E, 0x88, 0x53, 0x28, 0x55, 0x53, 0x41, 0x29,
					  0x2D, 0x30, 0x33, 0x2D, 0x53, 0x57, 0x20, 0x53, 0x4D,
					  0x2D, 0x42, 0x44, 0x50, 0x30, 0x34, 0x56, 0x30, 0x32,
					  0x32, 0x2D, 0x32, 0x33, 0x20, 0x30, 0x31, 0x4D, 0x41,
					  0x52, 0x31, 0x39, 0x20, 0x20, 0x20, 0x20, 0x20, 0x00,
					  0x00
					};
			}

			public byte[] ENABLE;
			public byte[] ACCEPTING;
			public byte[] ESCROW_BILL;
			public byte[] ESCROW_TICKET;
			public byte[] STAKING;
			public byte[] VEND_VALID;
			public byte[] STACKED;
			public byte[] REJECTING;
			public byte[] RETURNING;
			public byte[] HOLDING;
			public byte[] DISABLE;
			public byte[] INITIALIZE;
			public byte[] POWER_UP;
			public byte[] POWER_UP_BILL_IN_ACCEPTOR;
			public byte[] POWER_UP_BILL_IN_STACKER;
			public byte[] ERROR_STACKER_FULL;
			public byte[] ERROR_STACKER_OPEN;
			public byte[] ERROR_JAMMED_ACCEPTOR;
			public byte[] ERROR_JAMMED_STACKER;
			public byte[] ERROR_PAUSE;
			public byte[] ERROR_CHEATED;
			public byte[] ERROR_FAILURE;
			public byte[] ERROR_COMM_ERROR;
			public byte[] ACK;
			public byte[] ENQ;
			public byte[] INVALID;
			public byte[] SETTINGS_ENABLE;
			public byte[] SETTINGS_DISABLE;
			public byte[] SECURITY;
			public byte[] COMM_MODE;
			public byte[] INHIBIT;
			public byte[] DIRECTION;
			public byte[] OPTIONAL;
			public byte[] BARCODE;
			public byte[] COMMUNICATION_MODE;
			public byte[] BAR_INHIBIT;
			public byte[] OPTIONAL_FUNCTION;
			public byte[] BARCODE_FUNCTION;
			public byte[] VERSION_INFORMATION;
		};

		void BuildCashcodeResponses ()
		{
			byte[] crc = new byte[2];
			cashcodeResponse = new CashcodeResponse (true);

			cashcodeResponse.ENABLE[0] = Constants.STX;
			cashcodeResponse.ENABLE[1] = Constants.STANDARDLENGTH;
			cashcodeResponse.ENABLE[2] = 0x11;
			crc = DriverUtils.CalcCRC (cashcodeResponse.ENABLE);
			cashcodeResponse.ENABLE[3] = crc[0];
			cashcodeResponse.ENABLE[4] = crc[1];

			cashcodeResponse.ACCEPTING[0] = Constants.STX;
			cashcodeResponse.ACCEPTING[1] = Constants.STANDARDLENGTH;
			cashcodeResponse.ACCEPTING[2] = 0x12;
			crc = DriverUtils.CalcCRC (cashcodeResponse.ACCEPTING);
			cashcodeResponse.ACCEPTING[3] = crc[0];
			cashcodeResponse.ACCEPTING[4] = crc[1];

			cashcodeResponse.ESCROW_BILL[0] = Constants.STX;
			cashcodeResponse.ESCROW_BILL[1] = (byte) cashcodeResponse.ESCROW_BILL.Length;
			cashcodeResponse.ESCROW_BILL[2] = 0x13;

			cashcodeResponse.ESCROW_TICKET[0] = Constants.STX;
			cashcodeResponse.ESCROW_TICKET[1] = (byte) cashcodeResponse.ESCROW_TICKET.Length;
			cashcodeResponse.ESCROW_TICKET[2] = 0x13;
			cashcodeResponse.ESCROW_TICKET[3] = 0x6F;

			cashcodeResponse.STAKING[0] = Constants.STX;
			cashcodeResponse.STAKING[1] = Constants.STANDARDLENGTH;
			cashcodeResponse.STAKING[2] = 0x14;
			crc = DriverUtils.CalcCRC (cashcodeResponse.STAKING);
			cashcodeResponse.STAKING[3] = crc[0];
			cashcodeResponse.STAKING[4] = crc[1];

			cashcodeResponse.VEND_VALID[0] = Constants.STX;
			cashcodeResponse.VEND_VALID[1] = Constants.STANDARDLENGTH;
			cashcodeResponse.VEND_VALID[2] = 0x15;
			crc = DriverUtils.CalcCRC (cashcodeResponse.VEND_VALID);
			cashcodeResponse.VEND_VALID[3] = crc[0];
			cashcodeResponse.VEND_VALID[4] = crc[1];

			cashcodeResponse.STACKED[0] = Constants.STX;
			cashcodeResponse.STACKED[1] = Constants.STANDARDLENGTH;
			cashcodeResponse.STACKED[2] = 0x16;
			crc = DriverUtils.CalcCRC (cashcodeResponse.STACKED);
			cashcodeResponse.STACKED[3] = crc[0];
			cashcodeResponse.STACKED[4] = crc[1];

			cashcodeResponse.REJECTING[0] = Constants.STX;
			cashcodeResponse.REJECTING[1] = (byte) cashcodeResponse.REJECTING.Length;
			cashcodeResponse.REJECTING[2] = 0x17;
			//TODO data
			cashcodeResponse.REJECTING[3] = 0xFF;
			crc = DriverUtils.CalcCRC (cashcodeResponse.REJECTING);
			cashcodeResponse.REJECTING[4] = crc[0];
			cashcodeResponse.REJECTING[5] = crc[1];

			cashcodeResponse.RETURNING[0] = Constants.STX;
			cashcodeResponse.RETURNING[1] = Constants.STANDARDLENGTH;
			cashcodeResponse.RETURNING[2] = 0x18;
			crc = DriverUtils.CalcCRC (cashcodeResponse.RETURNING);
			cashcodeResponse.RETURNING[3] = crc[0];
			cashcodeResponse.RETURNING[4] = crc[1];

			cashcodeResponse.HOLDING[0] = Constants.STX;
			cashcodeResponse.HOLDING[1] = Constants.STANDARDLENGTH;
			cashcodeResponse.HOLDING[2] = 0x19;
			crc = DriverUtils.CalcCRC (cashcodeResponse.HOLDING);
			cashcodeResponse.HOLDING[3] = crc[0];
			cashcodeResponse.HOLDING[4] = crc[1];

			cashcodeResponse.DISABLE[0] = Constants.STX;
			cashcodeResponse.DISABLE[1] = Constants.STANDARDLENGTH;
			cashcodeResponse.DISABLE[2] = 0x1A;
			crc = DriverUtils.CalcCRC (cashcodeResponse.DISABLE);
			cashcodeResponse.DISABLE[3] = crc[0];
			cashcodeResponse.DISABLE[4] = crc[1];

			cashcodeResponse.INITIALIZE[0] = Constants.STX;
			cashcodeResponse.INITIALIZE[1] = Constants.STANDARDLENGTH;
			cashcodeResponse.INITIALIZE[2] = 0x1B;
			crc = DriverUtils.CalcCRC (cashcodeResponse.INITIALIZE);
			cashcodeResponse.INITIALIZE[3] = crc[0];
			cashcodeResponse.INITIALIZE[4] = crc[1];

			cashcodeResponse.POWER_UP[0] = Constants.STX;
			cashcodeResponse.POWER_UP[1] = Constants.STANDARDLENGTH;
			cashcodeResponse.POWER_UP[2] = 0x40;
			crc = DriverUtils.CalcCRC (cashcodeResponse.POWER_UP);
			cashcodeResponse.POWER_UP[3] = crc[0];
			cashcodeResponse.POWER_UP[4] = crc[1];

			cashcodeResponse.POWER_UP_BILL_IN_ACCEPTOR[0] = Constants.STX;
			cashcodeResponse.POWER_UP_BILL_IN_ACCEPTOR[1] = Constants.STANDARDLENGTH;
			cashcodeResponse.POWER_UP_BILL_IN_ACCEPTOR[2] = 0x41;
			crc = DriverUtils.CalcCRC (cashcodeResponse.POWER_UP_BILL_IN_ACCEPTOR);
			cashcodeResponse.POWER_UP_BILL_IN_ACCEPTOR[3] = crc[0];
			cashcodeResponse.POWER_UP_BILL_IN_ACCEPTOR[4] = crc[1];

			cashcodeResponse.POWER_UP_BILL_IN_STACKER[0] = Constants.STX;
			cashcodeResponse.POWER_UP_BILL_IN_STACKER[1] = Constants.STANDARDLENGTH;
			cashcodeResponse.POWER_UP_BILL_IN_STACKER[2] = 0x42;
			crc = DriverUtils.CalcCRC (cashcodeResponse.POWER_UP_BILL_IN_STACKER);
			cashcodeResponse.POWER_UP_BILL_IN_STACKER[3] = crc[0];
			cashcodeResponse.POWER_UP_BILL_IN_STACKER[4] = crc[1];

			cashcodeResponse.ERROR_STACKER_FULL[0] = Constants.STX;
			cashcodeResponse.ERROR_STACKER_FULL[1] = Constants.STANDARDLENGTH;
			cashcodeResponse.ERROR_STACKER_FULL[2] = 0x43;
			crc = DriverUtils.CalcCRC (cashcodeResponse.ERROR_STACKER_FULL);
			cashcodeResponse.ERROR_STACKER_FULL[3] = crc[0];
			cashcodeResponse.ERROR_STACKER_FULL[4] = crc[1];

			cashcodeResponse.ERROR_STACKER_OPEN[0] = Constants.STX;
			cashcodeResponse.ERROR_STACKER_OPEN[1] = Constants.STANDARDLENGTH;
			cashcodeResponse.ERROR_STACKER_OPEN[2] = 0x44;
			crc = DriverUtils.CalcCRC (cashcodeResponse.ERROR_STACKER_OPEN);
			cashcodeResponse.ERROR_STACKER_OPEN[3] = crc[0];
			cashcodeResponse.ERROR_STACKER_OPEN[4] = crc[1];

			cashcodeResponse.ERROR_JAMMED_ACCEPTOR[0] = Constants.STX;
			cashcodeResponse.ERROR_JAMMED_ACCEPTOR[1] = Constants.STANDARDLENGTH;
			cashcodeResponse.ERROR_JAMMED_ACCEPTOR[2] = 0x45;
			crc = DriverUtils.CalcCRC (cashcodeResponse.ERROR_JAMMED_ACCEPTOR);
			cashcodeResponse.ERROR_JAMMED_ACCEPTOR[3] = crc[0];
			cashcodeResponse.ERROR_JAMMED_ACCEPTOR[4] = crc[1];

			cashcodeResponse.ERROR_JAMMED_STACKER[0] = Constants.STX;
			cashcodeResponse.ERROR_JAMMED_STACKER[1] = Constants.STANDARDLENGTH;
			cashcodeResponse.ERROR_JAMMED_STACKER[2] = 0x46;
			crc = DriverUtils.CalcCRC (cashcodeResponse.ERROR_JAMMED_STACKER);
			cashcodeResponse.ERROR_JAMMED_STACKER[3] = crc[0];
			cashcodeResponse.ERROR_JAMMED_STACKER[4] = crc[1];

			cashcodeResponse.ERROR_PAUSE[0] = Constants.STX;
			cashcodeResponse.ERROR_PAUSE[1] = Constants.STANDARDLENGTH;
			cashcodeResponse.ERROR_PAUSE[2] = 0x47;
			crc = DriverUtils.CalcCRC (cashcodeResponse.ERROR_PAUSE);
			cashcodeResponse.ERROR_PAUSE[3] = crc[0];
			cashcodeResponse.ERROR_PAUSE[4] = crc[1];

			cashcodeResponse.ERROR_CHEATED[0] = Constants.STX;
			cashcodeResponse.ERROR_CHEATED[1] = Constants.STANDARDLENGTH;
			cashcodeResponse.ERROR_CHEATED[2] = 0x48;
			crc = DriverUtils.CalcCRC (cashcodeResponse.ERROR_CHEATED);
			cashcodeResponse.ERROR_CHEATED[3] = crc[0];
			cashcodeResponse.ERROR_CHEATED[4] = crc[1];

			cashcodeResponse.ERROR_FAILURE[0] = Constants.STX;
			cashcodeResponse.ERROR_FAILURE[1] = (byte) cashcodeResponse.ERROR_FAILURE.Length;
			cashcodeResponse.ERROR_FAILURE[2] = 0x49;
			//TODO data
			cashcodeResponse.ERROR_FAILURE[3] = 0xFF;
			crc = DriverUtils.CalcCRC (cashcodeResponse.ERROR_FAILURE);
			cashcodeResponse.ERROR_FAILURE[4] = crc[0];
			cashcodeResponse.ERROR_FAILURE[5] = crc[1];

			cashcodeResponse.ERROR_COMM_ERROR[0] = Constants.STX;
			cashcodeResponse.ERROR_COMM_ERROR[1] = Constants.STANDARDLENGTH;
			cashcodeResponse.ERROR_COMM_ERROR[2] = 0x4A;
			crc = DriverUtils.CalcCRC (cashcodeResponse.ERROR_COMM_ERROR);
			cashcodeResponse.ERROR_COMM_ERROR[3] = crc[0];
			cashcodeResponse.ERROR_COMM_ERROR[4] = crc[1];

			cashcodeResponse.ACK[0] = Constants.STX;
			cashcodeResponse.ACK[1] = Constants.STANDARDLENGTH;
			cashcodeResponse.ACK[2] = Constants.ACK;
			crc = DriverUtils.CalcCRC (cashcodeResponse.ACK);
			cashcodeResponse.ACK[3] = crc[0];
			cashcodeResponse.ACK[4] = crc[1];

			cashcodeResponse.ENQ[0] = Constants.STX;
			cashcodeResponse.ENQ[1] = Constants.STANDARDLENGTH;
			cashcodeResponse.ENQ[2] = 0x05;
			crc = DriverUtils.CalcCRC (cashcodeResponse.ENQ);
			cashcodeResponse.ENQ[3] = crc[0];
			cashcodeResponse.ENQ[4] = crc[1];

			cashcodeResponse.INVALID[0] = Constants.STX;
			cashcodeResponse.INVALID[1] = Constants.STANDARDLENGTH;
			cashcodeResponse.INVALID[2] = 0x4B;
			crc = DriverUtils.CalcCRC (cashcodeResponse.INVALID);
			cashcodeResponse.INVALID[3] = crc[0];
			cashcodeResponse.INVALID[4] = crc[1];

			//cashcodeResponse.VERSION_INFORMATION[0] = Constants.STX;
			//cashcodeResponse.VERSION_INFORMATION[1] = (byte) cashcodeResponse.VERSION_INFORMATION.Length;
			//cashcodeResponse.VERSION_INFORMATION[2] = 0x88;
			////todo get actual data for the cashcode version
			//cashcodeResponse.VERSION_INFORMATION[3] = 0x0F;
			//cashcodeResponse.VERSION_INFORMATION[4] = 0xFF;
			//cashcodeResponse.VERSION_INFORMATION[5] = 0xF0;
			crc = DriverUtils.CalcCRC (cashcodeResponse.VERSION_INFORMATION);
			cashcodeResponse.VERSION_INFORMATION[44] = crc[0];
			cashcodeResponse.VERSION_INFORMATION[45] = crc[1];

			cashcodeResponse.COMMUNICATION_MODE[0] = Constants.STX;
			cashcodeResponse.COMMUNICATION_MODE[1] = (byte) cashcodeResponse.COMMUNICATION_MODE.Length;
			cashcodeResponse.COMMUNICATION_MODE[2] = 0xC2;
			cashcodeResponse.COMMUNICATION_MODE[3] = 0x01;
			crc = DriverUtils.CalcCRC (cashcodeResponse.COMMUNICATION_MODE);
			cashcodeResponse.COMMUNICATION_MODE[4] = crc[0];
			cashcodeResponse.COMMUNICATION_MODE[5] = crc[1];

			cashcodeResponse.INHIBIT[0] = Constants.STX;
			cashcodeResponse.INHIBIT[1] = (byte) cashcodeResponse.INHIBIT.Length;
			cashcodeResponse.INHIBIT[2] = 0xC3;
			cashcodeResponse.INHIBIT[3] = 0x00;
			crc = DriverUtils.CalcCRC (cashcodeResponse.INHIBIT);
			cashcodeResponse.INHIBIT[4] = crc[0];
			cashcodeResponse.INHIBIT[5] = crc[1];

			cashcodeResponse.OPTIONAL_FUNCTION[0] = Constants.STX;
			cashcodeResponse.OPTIONAL_FUNCTION[1] = (byte) cashcodeResponse.OPTIONAL_FUNCTION.Length;
			cashcodeResponse.OPTIONAL_FUNCTION[2] = 0xC5;
			cashcodeResponse.OPTIONAL_FUNCTION[3] = 0x00;
			cashcodeResponse.OPTIONAL_FUNCTION[4] = 0x00;
			crc = DriverUtils.CalcCRC (cashcodeResponse.OPTIONAL_FUNCTION);
			cashcodeResponse.OPTIONAL_FUNCTION[5] = crc[0];
			cashcodeResponse.OPTIONAL_FUNCTION[6] = crc[1];

			cashcodeResponse.BARCODE_FUNCTION[0] = Constants.STX;
			cashcodeResponse.BARCODE_FUNCTION[1] = (byte) cashcodeResponse.BARCODE_FUNCTION.Length;
			cashcodeResponse.BARCODE_FUNCTION[2] = 0xC6;
			cashcodeResponse.BARCODE_FUNCTION[3] = 0x01;
			cashcodeResponse.BARCODE_FUNCTION[4] = 0x12;
			crc = DriverUtils.CalcCRC (cashcodeResponse.BARCODE_FUNCTION);
			cashcodeResponse.BARCODE_FUNCTION[5] = crc[0];
			cashcodeResponse.BARCODE_FUNCTION[6] = crc[1];

			cashcodeResponse.BAR_INHIBIT[0] = Constants.STX;
			cashcodeResponse.BAR_INHIBIT[1] = (byte) cashcodeResponse.BAR_INHIBIT.Length;
			cashcodeResponse.BAR_INHIBIT[2] = 0xC7;
			cashcodeResponse.BAR_INHIBIT[3] = 0x00;
			crc = DriverUtils.CalcCRC (cashcodeResponse.BAR_INHIBIT);
			cashcodeResponse.BAR_INHIBIT[4] = crc[0];
			cashcodeResponse.BAR_INHIBIT[5] = crc[1];
		}

		/// <summary>Cashcode error code.</summary>
		class CashcodeErrorCode
		{
			public const string OK = "0";
			public const string StackerOpen = "1";
			public const string JammedAcceptor = "2";
			public const string JammedStacker = "3";
		}

		/// <summary>Constants.</summary>
		class Constants
		{
			public const byte ESC = 0x1B;
			public const byte STX = 0xFC;
			public const byte ETX = 0x03;
			public const byte US = 0x1F;
			public const byte Percent = 0x25;
			public const byte STANDARDLENGTH = 0x05;
			public const byte ACK = 0x50;
		}

		/// <summary>Cashcode current state. </summary>
		public enum CashcodeState : int
		{
			Unknown = 0,
			Off = 1,
			Idling = 2,
			FirstIdling = 3,
			IdlingEnabled = 4,
			IdlingDisabled = 5,
			Accepting = 6,
			Returning = 7,
			Rejecting = 8,
			Escrow = 9,
			Stacking = 10,
			VendValid = 11,
			Stacked = 12,
			JammedInAcceptor = 13,
			StackedFull = 14,
			Disable = 15,
			Initializing = 16,
			PoweringUp = 17,
			InsertingBill = 18,
		}


		#endregion
	}

}