﻿using AutoTestingService;

namespace AuSy.Modules.PeripheralMediator.Drivers
{
	public interface ICardReaderDriver
	{
		void Init (string port);

		void Terminate ();

		InsertCardError InsertCard (string number);

		RemoveCardError RemoveCard ();
	}

	public class Status
	{
		// Connection status
		public bool connected { get; set; }
		// Default model = PI65C-120-RSA-DFR
		public string model { get; set; }
		// Default version = 0091A
		public string version { get; set; }
		// Default setup = SC2,SF10,SD11,SA010
		public string setup { get; set; }
		// Default card = 00000000000000000000
		public string card { get; set; }
		// Default cardDetect = 0  [0, 1, 2, 3]
		public char cardDetect { get; set; }
		// Default lampState = 1  [0, 1, 2]
		public char lampState { get; set; }
		// Default lampColour = 1  [1, 2, 3]
		public char lampColour { get; set; }
		// Default format = A [A, B, F, N]
		public string format { get; set; }
		// Default error = 0 [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
		public string error { get; set; }
		// Default cardIn = false
		public bool cardIn { get; set; }
	}

	class Constants
	{
		public const int CARDREADER_MAX_NUMBER_OF_DIGITS_ON_A_CARD_NUMBER = 40 + 1;

		//TODO: define on Magtek Driver
		//public const int CARDREADER_DRIVER_MAGTEK_MAX_LEGAL_FRAME_SIZE = 87;
		//40+40+2+2+2+1
	}
}

