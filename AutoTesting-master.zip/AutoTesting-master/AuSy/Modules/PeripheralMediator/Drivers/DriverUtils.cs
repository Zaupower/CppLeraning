﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Text;

namespace AuSy.Modules.PeripheralMediator.Drivers
{
	public class DriverUtils
	{
		#region Singleton

		public static DriverUtils Instance { get; private set; } = new DriverUtils ();

		private DriverUtils ()
		{
		}

		#endregion

		public Dictionary<float, byte> BillDict = new Dictionary<float, byte> ()
		{
			{1,0x61},
			{2,0x62},
			{3,0x63},
			{4,0x64},
			{5,0x65},
			{6,0x66},
			{7,0x67},
			//{8,0x68},
		};



		/// <summary>Parses the parity.</summary>
		/// <returns>Parity.</returns>
		/// <param name="parity">Parity.</param>
		public Parity ParseParity (string parity)
		{
			switch (parity.ToLower ())
			{
			case "even":
				return Parity.Even;
			case "mark":
				return Parity.Mark;
			case "odd":
				return Parity.Odd;
			case "space":
				return Parity.Space;
			default:
				return Parity.None;
			}
		}

		/// <summary>Parses the stop bits.</summary>
		/// <returns>Stop bits.</returns>
		/// <param name="stopBits">Stop bits.</param>
		public StopBits ParseStopBits (string stopBits)
		{
			switch (stopBits.ToLower ())
			{
			case "0":
				return StopBits.None;
			case "1":
				return StopBits.One;
			case "1.5":
				return StopBits.OnePointFive;
			default:
				return StopBits.Two;
			}
		}

		// Parse defined Handshake
		public Handshake ParseHandshake (string handshake)
		{
			switch (handshake.ToLower ())
			{
			case "requesttosend":
				return Handshake.RequestToSend;
			case "requesttosendxonxoff":
				return Handshake.RequestToSendXOnXOff;
			case "xonxoff":
				return Handshake.XOnXOff;
			default:
				return Handshake.None;
			}
		}

		// Convert ASCII string to HEX
		public string ConvertToHex (string asciiString)
		{
			string hex = "";
			foreach (char c in asciiString)
			{
				int tmp = c;
				hex += String.Format ("{0:x2}", (uint) System.Convert.ToUInt32 (tmp.ToString ()));
			}
			return hex;
		}

		// Convery ASCII string to Binary
		public String ConvertToBinary (string asciiString)
		{
			Byte[] data = ConvertToByteArray (asciiString, Encoding.ASCII);
			return string.Join (" ", data.Select (byt => Convert.ToString (byt, 2).PadLeft (8, '0')));
		}

		// Convert string to Byte Array
		public byte[] ConvertToByteArray (string str, Encoding encoding)
		{
			return encoding.GetBytes (str);
		}


		public static byte[] CalcCRC (byte[] pBuff)
		{
			uint i;
			ushort c, q, crc = 0;
			byte[] final_crc = new byte[2];
			for (i = 0; i < pBuff.Length - 2; i++)
			{
				c = pBuff[i];
				q = (ushort) ((crc ^ c) & 0x0F);
				crc = (ushort) ((crc >> 4) ^ (q * '\x1081'));
				q = (ushort) ((crc ^ (c >> 4)) & '\x0F');
				crc = (ushort) ((crc >> 4) ^ (q * '\x1081'));
			}
			final_crc[0] = BitConverter.GetBytes (crc)[0];
			final_crc[1] = BitConverter.GetBytes (crc)[1];
			//Console.WriteLine (final_crc[0]);
			//Console.WriteLine (final_crc[1]);
			return final_crc;
		}
	}
}

