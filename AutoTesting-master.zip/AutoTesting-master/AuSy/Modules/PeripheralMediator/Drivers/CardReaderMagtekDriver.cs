﻿using System;
using System.IO.Ports;
using System.Threading;
using AutoTestingService;
using AutoTestingService.Logging;

namespace AuSy.Modules.PeripheralMediator.Drivers
{
	/// <summary>Card reader Magtek driver.</summary>
	public class CardReaderMagtekDriver : ICardReaderDriver
	{
		#region Variables

		public bool QuitCardReaderMagtekWorkerThread;
		public Status Status;

		private SerialPort _serialPort;
		private Track _track1;
		private MagtekCommand _magtekCommand;
		private bool _initialized = false;
		private string _rxData;
		private int _bytes;
		private int _loopTime;

		Thread _processThread;

		#endregion

		/// <summary>Initializes a new instance of the <see cref="CardReaderMagtekDriver"/> class.</summary>
		public CardReaderMagtekDriver ()
		{
			QuitCardReaderMagtekWorkerThread = false;
		}

		/// <summary>Releases unmanaged resources and performs other cleanup operations before the
		/// <see cref="CardReaderMagtekDriver"/> is reclaimed by garbage collection.</summary>
		~CardReaderMagtekDriver ()
		{
			Terminate ();
		}

		#region Init

		/// <summary>Initializes this instance.</summary>
		public void Init (string port)
		{
			_loopTime = 25;

			BuildMagtekCommands ();     // Build the Magtek Commmands

			setupSerialPort (port);         // Serial Port Initialization

			initializeStatus ();        // Define default status values

			_processThread = new Thread (CRMagtekthread)
			{
				Name = "Magtek Card Reader Thread"
			};

			try
			{
				_serialPort.Open ();
				Logger.Instance.UpdateLog ("Card reader opened serial port " + port + " successfully.", LoggerType.Develop);
			}
			catch (Exception ex)
			{
				Logger.Instance.UpdateLog ("Card reader could not open serial port " + port + ": " + ex, LoggerType.Error);
				Environment.Exit (1);
			}

			_processThread.Start ();

			_initialized = true;
		}

		/// <summary>Terminates this instance.</summary>
		public void Terminate ()
		{
			try
			{
				if (_serialPort.IsOpen)
				{
					_serialPort.DtrEnable = false;
					_serialPort.RtsEnable = false;
					_serialPort.DiscardInBuffer ();
					_serialPort.DiscardOutBuffer ();
					_serialPort.Close ();
				}
			}
			catch (Exception ex)
			{
				Logger.Instance.UpdateLog ("Serial Port closing Exception: " + ex, LoggerType.Warning);
			}

			QuitCardReaderMagtekWorkerThread = true;
			if (_initialized)
			{
				_processThread.Join ();
			}
		}

		/// <summary>Setups the Serial Port.</summary>
		private void setupSerialPort (string port)
		{
			// Create a new SerialPort object with default settings.
			_serialPort = new SerialPort ();

			// Set the appropriate properties for a Magtek card reader.
			_serialPort.PortName = port;
			_serialPort.BaudRate = 9600;
			_serialPort.Parity = DriverUtils.Instance.ParseParity ("even");
			_serialPort.DataBits = 7;
			_serialPort.StopBits = DriverUtils.Instance.ParseStopBits ("1");
			_serialPort.Handshake = DriverUtils.Instance.ParseHandshake ("none");
			_serialPort.RtsEnable = true;
			_serialPort.DtrEnable = true;
			_serialPort.ReadTimeout = 250;
			_serialPort.WriteTimeout = 250;
		}

		/// <summary>Initializes the status with the default values.</summary>
		private void initializeStatus ()
		{
			Status = new Status ();
			Status.connected = false;
			Status.model = "";
			Status.version = "21088842A01";
			Status.setup = "";
			Status.card = "00000000000000000000";
			Status.cardDetect = '0';
			Status.lampState = '1';
			Status.lampColour = '1';
			Status.error = MagtekErrorCode.OK;
			Status.cardIn = false;

			_track1 = new Track ();
			_track1.SetCard (Status.card);
		}

		#endregion

		#region Input

		/// <summary> Card Reader Magtek worker thread.</summary>
		private void CRMagtekthread ()
		{
			if (!_serialPort.IsOpen)
			{
				return;
			}

			_serialPort.DiscardInBuffer ();
			_serialPort.DiscardOutBuffer ();
			while (!QuitCardReaderMagtekWorkerThread)
			{
				try
				{
					_rxData = _serialPort.ReadExisting ();
					_bytes = _rxData.Length;
					if (_bytes > 0)
					{
						Logger.Instance.UpdateLog ("Serial port got: [" + Helper.Instance.StringToHex (_rxData) + "] (" + _rxData + ")", LoggerType.Develop);
					}
					if (checkFrameIntegrity ())
					{   // Check frame integrity
						if (!Status.connected)
						{
							Status.connected = true;
							Logger.Instance.UpdateLog ("Connection established with Serial Port.", LoggerType.Develop);
						}
						if (processNewFrame ())
						{
							//UpdateCardReaderDriverErrorState(); ??
						}
					}
				}
				catch (Exception ex)
				{
					if (ex.Message.Equals ("The operation has timed out."))
					{
					}
				}
				Thread.Sleep (_loopTime);
			}
		}

		/// <summary>Checks the frame integrity.</summary>
		/// <returns><c>true</c>, if frame integrity was ok, <c>false</c> otherwise.</returns>
		private bool checkFrameIntegrity ()
		{
			if (_bytes <= 0)
			{   // 1 - Nothin read or read failed
				return false;
			}

			if (_bytes > Constants.CARDREADER_DRIVER_MAGTEK_MAX_LEGAL_FRAME_SIZE)
			{   //Frame is too large
				return false;
			}

			return true;
		}

		/// <summary>Processes the new frame. </summary>
		/// <returns><c>true</c>, if new frame was processed successfully, <c>false</c> otherwise.</returns>
		private bool processNewFrame ()
		{
			bool result = false;

			if (_bytes > 1)
			{
				char frameHeader0 = _rxData[0];
				char frameHeader1 = _rxData[1];
				if (frameHeader1 == _magtekCommand.VersionRequest[1])
				{
					sendResponse (Status.version + '\r');
					result = true;
				}
				else if (frameHeader1 == _magtekCommand.InquireCommand[1])
				{
					if (!Status.cardIn)
					{
						sendResponse ("" + Constants.STX + Status.cardDetect + Constants.ETX);
					}
					else
					{
						sendResponse ("" + Constants.STX + Constants.Percent + _track1.GetCard () + Constants.US + " 1" + Constants.ETX);
					}
					result = true;
				}
				else if (frameHeader1 == _magtekCommand.SetLampsOff[1])
				{
					//sendResponse (new string (_magtekResponse.AckValidChar)); ??
					result = true;
				}
				else if (frameHeader1 == _magtekCommand.SetLampsGreen[1])
				{
					//sendResponse (new string (_magtekResponse.AckValidChar)); ??
					result = true;
				}
				else if (frameHeader1 == _magtekCommand.SetLampsRed[1])
				{
					//sendResponse (new string (_magtekResponse.AckValidChar)); ??
					result = true;
				}
			}

			if (!result)
			{
				//sendResponse (new string (_magtekResponse.ReceivedCommandIsNotValid)); ??
				Logger.Instance.UpdateLog ("CRMagtekDriver processNewFrame NO RESULT FOR FRAME: " + DriverUtils.Instance.ConvertToHex (_rxData), LoggerType.Develop, true);
			}

			return result;
		}

		#endregion

		#region Output

		/// <summary> Sends the response to the Serial Port.</summary>
		/// <param name="response">Response.</param>
		private void sendResponse (string response)
		{
			if (_serialPort.IsOpen)
			{
				try
				{
					_serialPort.Write (response);
					Logger.Instance.UpdateLog ("Serial port wrote: [" + Helper.Instance.StringToHex (response) + "] (" + response + ")", LoggerType.Develop);
				}
				catch (Exception ex)
				{
					Logger.Instance.UpdateLog ("Serial port write exception: " + ex, LoggerType.Error);
				}
			}
		}

		#endregion

		#region Interface Methods

		/// <summary>Inserts the card.</summary>
		/// <returns>The operation result.</returns>
		/// <param name="number">Card number.</param>
		public InsertCardError InsertCard (string number)
		{
			if (Status.connected)
			{   // Check connection
				if (!Status.cardIn)
				{   // Check card status
					string card = "";
					if (number != "")
					{
						Status.card = number;
					}

					//TODO error situations
					if (Status.error == MagtekErrorCode.OK)
					{
						card = Status.card;
					}/* else {
						//Status.format = MagtekFormat.Failed;
					}*/

					_track1.SetError (Status.error);
					_track1.SetCard (card);
					Status.cardDetect = '1';
					sendResponse ("" + Constants.STX + Status.cardDetect + Constants.ETX);
					Status.cardIn = true;
					return InsertCardError.None;
				}
				else
				{
					Logger.Instance.UpdateLog ("CardReader InsertCard() card is already inside.", LoggerType.Warning);
					return InsertCardError.CardAlreadyInside;
				}
			}
			else
			{
				Logger.Instance.UpdateLog ("CardReader InsertCard() called but Status.connected is false.", LoggerType.Warning);
			}
			return InsertCardError.NoCommunication;
		}

		/// <summary>Removes the card.</summary>
		/// <returns>The operation result.</returns>
		public RemoveCardError RemoveCard ()
		{
			if (Status.connected)
			{       // Check connection
				if (Status.cardIn)
				{   // Check card status
					Status.cardDetect = '0';
					sendResponse ("" + Constants.STX + Constants.Percent + Status.card + Constants.US + " 0" + Constants.ETX);
					Status.cardIn = false;
					return RemoveCardError.None;
				}
				else
				{
					return RemoveCardError.NoCardInside;
				}
			}
			return RemoveCardError.NoCommunication;
		}

		#endregion

		#region MAGTEK specific

		void BuildMagtekCommands ()
		{
			_magtekCommand = new MagtekCommand (true);

			_magtekCommand.VersionRequest[0] = Constants.ESC;
			_magtekCommand.VersionRequest[1] = 'V';

			_magtekCommand.InquireCommand[0] = Constants.ESC;
			_magtekCommand.InquireCommand[1] = 'I';

			_magtekCommand.SetLampsOff[0] = Constants.ESC;
			_magtekCommand.SetLampsOff[1] = 'O';

			_magtekCommand.SetLampsGreen[0] = Constants.ESC;
			_magtekCommand.SetLampsGreen[1] = 'G';

			_magtekCommand.SetLampsRed[0] = Constants.ESC;
			_magtekCommand.SetLampsRed[1] = 'L';
		}

		struct MagtekCommand
		{
			public MagtekCommand (bool notUsed = true)
			{
				VersionRequest = new char[4];
				InquireCommand = new char[4];
				SetLampsOff = new char[4];
				SetLampsGreen = new char[4];
				SetLampsRed = new char[4];
			}

			public char[] VersionRequest;
			public char[] InquireCommand;
			public char[] SetLampsOff;
			public char[] SetLampsGreen;
			public char[] SetLampsRed;
		};

		//TODO
		class MagtekErrorCode
		{
			public const string OK = "0";
			/*public const string NoLeadingZeros = "1";
			public const string NoStartSentinal = "2";
			public const string ParityError = "3";
			public const string NoEndSentinal = "4";
			public const string LRCCheckFailed = "5";
			public const string TrackNotInstalled = "6";
			public const string NoData = "9";*/
		}

		class Constants
		{
			public const char ESC = '\x1B';
			public const char STX = '\x02';
			public const char ETX = '\x03';
			public const char US = '\x1F';
			public const char Percent = '\x25';

			public const int CARDREADER_DRIVER_MAGTEK_MAX_LEGAL_FRAME_SIZE = 87;
			//40+40+2+2+2+1
		}

		#endregion
	}
}