﻿using System;
using System.IO.Ports;
using System.Threading;
using AutoTestingService;
using AutoTestingService.Logging;

namespace AuSy.Modules.PeripheralMediator.Drivers
{
	/// <summary>Card reader XST driver.</summary>
	public class CardReaderXSTDriver : ICardReaderDriver
	{
		#region Variables

		public bool QuitCardReaderXstWorkerThread;
		public Status Status;

		private SerialPort _serialPort;
		private Track _track1;
		private Track _track2;
		private XstCommand _xstCommand;
		private XstResponse _xstResponse;
		private bool _initialized = false;
		private string _rxData;
		private int _bytes;
		private int _loopTime;
		private int _maxConnectionTimeout;

		Thread _processThread;

		#endregion

		/// <summary>Initializes a new instance of the <see cref="CardReaderXSTDriver"/> class.</summary>
		public CardReaderXSTDriver ()
		{
			QuitCardReaderXstWorkerThread = false;
		}

		/// <summary>Releases unmanaged resources and performs other cleanup operations before the
		/// <see cref="CardReaderXSTDriver"/> is reclaimed by garbage collection.</summary>
		~CardReaderXSTDriver ()
		{
			Terminate ();
		}

		#region Init

		/// <summary>Initializes this instance.</summary>
		public void Init (string port)
		{
			_loopTime = 25;
			_maxConnectionTimeout = 50;

			BuildXstCommands ();        // Build the XST Commmands

			BuildXstResponses ();       // Build the XST responses

			setupSerialPort (port);         // Serial Port Initialization

			initializeStatus ();        // Define default status values

			_processThread = new Thread (CRXsthread)
			{
				Name = "XST Card Reader Thread"
			};

			try
			{
				_serialPort.Open ();
				Logger.Instance.UpdateLog ("Card reader opened serial port " + port + " successfully.", LoggerType.Develop);
			}
			catch (Exception ex)
			{
				Logger.Instance.UpdateLog ("Card reader could not open serial port " + port + ": " + ex, LoggerType.Error);
				Environment.Exit (1);
			}

			_processThread.Start ();

			_initialized = true;
		}

		/// <summary>Terminates this instance.</summary>
		public void Terminate ()
		{
			try
			{
				if (_serialPort.IsOpen)
				{
					_serialPort.DtrEnable = false;
					_serialPort.RtsEnable = false;
					_serialPort.DiscardInBuffer ();
					_serialPort.DiscardOutBuffer ();
					_serialPort.Close ();
				}
			}
			catch (Exception ex)
			{
				Logger.Instance.UpdateLog ("Serial Port closing Exception: " + ex, LoggerType.Warning);
			}

			QuitCardReaderXstWorkerThread = true;
			if (_initialized)
			{
				_processThread.Join ();
			}
		}

		/// <summary>Setups the Serial Port.</summary>
		private void setupSerialPort (string port)
		{
			// Create a new SerialPort object with default settings.
			_serialPort = new SerialPort ();

			// Set the appropriate properties for a XST card reader.
			_serialPort.PortName = port;
			_serialPort.BaudRate = 9600;
			_serialPort.Parity = DriverUtils.Instance.ParseParity ("none");
			_serialPort.DataBits = 7;
			_serialPort.StopBits = DriverUtils.Instance.ParseStopBits ("2");
			_serialPort.Handshake = DriverUtils.Instance.ParseHandshake ("none");
			_serialPort.RtsEnable = true;
			_serialPort.DtrEnable = true;
			_serialPort.ReadTimeout = 250;
			_serialPort.WriteTimeout = 250;
		}

		/// <summary>Initializes the status with the default values.</summary>
		private void initializeStatus ()
		{
			Status = new Status ();
			Status.connected = false;
			Status.model = "PI65C-120-RSA-DFR";
			Status.version = "0091A";
			Status.setup = "SC2,SF10,SD11,SA010";
			Status.card = "00000000000000000000";
			Status.cardDetect = '0';
			Status.lampState = '1';
			Status.lampColour = '1';
			Status.format = XstFormat.Alpha;
			Status.error = XstErrorCode.OK;
			Status.cardIn = false;

			_track1 = new Track ();
			_track2 = new Track ();
			_track1.SetCard (Status.card);
			_track2.SetCard (Status.card);
		}

		#endregion

		#region Input

		/// <summary> Card Reader XST worker thread.</summary>
		private void CRXsthread ()
		{
			if (!_serialPort.IsOpen)
			{
				return;
			}

			_serialPort.DiscardInBuffer ();
			_serialPort.DiscardOutBuffer ();
			int timeout = 0;
			while (!QuitCardReaderXstWorkerThread)
			{
				try
				{
					_rxData = _serialPort.ReadExisting ();
					_bytes = _rxData.Length;
					if (_bytes > 0)
					{
						Logger.Instance.UpdateLog ("Serial port got: [" + Helper.Instance.StringToHex (_rxData) + "] (" + _rxData + ")", LoggerType.Develop);
					}
					if (checkFrameIntegrity ())
					{   // Check frame integrity
						timeout = 0;
						if (!Status.connected)
						{
							Status.connected = true;
							Logger.Instance.UpdateLog ("Connection established with Serial Port.", LoggerType.Develop);
						}
						if (processNewFrame ())
						{
							//UpdateCardReaderDriverErrorState(); ??
						}
					}
					else
					{
						Logger.Instance.UpdateLog ("CRXSTDriver checkFrameIntegrity FAILED FOR FRAME: " + DriverUtils.Instance.ConvertToHex (_rxData), LoggerType.Develop, true);
					}
				}
				catch (Exception ex)
				{
					if (ex.Message.Equals ("The operation has timed out."))
					{
						timeout++;
					}
				}
				if (timeout > _maxConnectionTimeout && Status.connected)
				{
					Status.connected = false;
					Logger.Instance.UpdateLog ("Connection lost with Serial Port; haven't received any command in a while.", LoggerType.Develop);
				}
				Thread.Sleep (_loopTime);
			}
		}

		/// <summary>Checks the frame integrity.</summary>
		/// <returns><c>true</c>, if frame integrity was ok, <c>false</c> otherwise.</returns>
		private bool checkFrameIntegrity ()
		{
			if (_bytes <= 0)
			{   // 1 - Nothin read or read failed
				return false;
			}

			if (_bytes > Constants.CARDREADER_DRIVER_XST_MAX_LEGAL_FRAME_SIZE)
			{   //Frame is too large
				return false;
			}

			if (!(_rxData[0] == _xstCommand.SetLampsState[0] && _rxData[1] == _xstCommand.SetLampsState[1]))
			{
				if (_rxData[_bytes - 1] != '\n')
				{   // No \n found
					//return false;
				}

				if (_rxData[_bytes - 2] != '\r')
				{ // No \r found
				  //	return false;
				}
			}

			return true;
		}

		/// <summary>Processes the new frame. </summary>
		/// <returns><c>true</c>, if new frame was processed successfully, <c>false</c> otherwise.</returns>
		private bool processNewFrame ()
		{
			bool result = false;

			if (_bytes > 2)
			{
				char frameHeader0 = _rxData[0];
				char frameHeader1 = _rxData[1];
				if (frameHeader0 == _xstCommand.ResetReader[0])
				{
					sendResponse (new string (_xstResponse.HardwareReset));
					result = true;
				}
				else if (frameHeader0 == _xstCommand.ReadModelNumber[0] && frameHeader1 == _xstCommand.ReadModelNumber[1])
				{
					sendResponse (Status.model + '\r' + '\n');
					result = true;
				}
				else if (frameHeader0 == _xstCommand.ReadCodeVersion[0] && frameHeader1 == _xstCommand.ReadCodeVersion[1])
				{
					sendResponse (Status.version + '\r' + '\n');
					result = true;
				}
				else if (frameHeader0 == _xstCommand.ReadUnitInformation[0] && frameHeader1 == _xstCommand.ReadUnitInformation[1])
				{
					string information = "iiiiiiiiii";
					sendResponse (information + '\r' + '\n');
					result = true;
				}
				else if (frameHeader0 == _xstCommand.ReadFormattingAndReadOperationSetup[0] && frameHeader1 == _xstCommand.ReadFormattingAndReadOperationSetup[1])
				{
					sendResponse (Status.setup + '\r' + '\n');
					result = true;
				}
				else if (frameHeader0 == _xstCommand.ReadFormatingSettings[0] && frameHeader1 == _xstCommand.ReadFormatingSettings[1])
				{
					string formats = string.Format ("{0}{1}", _track1.GetFormat (), _track2.GetFormat ());
					sendResponse (formats + '\r' + '\n');
					result = true;
				}
				else if (frameHeader0 == _xstCommand.ReadCardDetects[0] && frameHeader1 == _xstCommand.ReadCardDetects[1])
				{
					sendResponse ("" + Status.cardDetect + '\r' + '\n');
					result = true;
				}
				else if (frameHeader0 == _xstCommand.TransmitAllTracks[0] && frameHeader1 == _xstCommand.TransmitAllTracks[1])
				{
					string tracks = string.Format ("|1{0}{1}{2}|2{3}{4}{5}", _track1.GetFormat (), _track1.GetError (), _track1.GetCard (), _track2.GetFormat (), _track2.GetError (), _track2.GetCard ());
					sendResponse (tracks + '\r' + '\n');
					result = true;
				}
				else if (frameHeader0 == _xstCommand.TransmitTrack1[0] && frameHeader1 == _xstCommand.TransmitTrack1[1])
				{
					sendResponse (_track1.GetCard () + '\r' + '\n');
					result = true;
				}
				else if (frameHeader0 == _xstCommand.TransmitTrack2[0] && frameHeader1 == _xstCommand.TransmitTrack2[1])
				{
					sendResponse (_track2.GetCard () + '\r' + '\n');
					result = true;
				}
				else if (frameHeader0 == _xstCommand.TransmitTrack1RawInBinary[0] && frameHeader1 == _xstCommand.TransmitTrack1RawInBinary[1])
				{
					sendResponse (DriverUtils.Instance.ConvertToBinary (_track1.GetCard ()) + '\r' + '\n');
					result = true;
				}
				else if (frameHeader0 == _xstCommand.TransmitTrack2RawInBinary[0] && frameHeader1 == _xstCommand.TransmitTrack2RawInBinary[1])
				{
					sendResponse (DriverUtils.Instance.ConvertToBinary (_track2.GetCard ()) + '\r' + '\n');
					result = true;
				}
				else if (frameHeader0 == _xstCommand.TransmitTrack1RawInHex[0] && frameHeader1 == _xstCommand.TransmitTrack1RawInHex[1])
				{
					sendResponse (DriverUtils.Instance.ConvertToHex (_track1.GetCard ()) + '\r' + '\n');
					result = true;
				}
				else if (frameHeader0 == _xstCommand.TransmitTrack2RawInHex[0] && frameHeader1 == _xstCommand.TransmitTrack2RawInHex[1])
				{
					sendResponse (DriverUtils.Instance.ConvertToHex (_track2.GetCard ()) + '\r' + '\n');
					result = true;
				}
				else if (frameHeader0 == _xstCommand.SetLampsState[0])
				{
					if (frameHeader1 == _xstCommand.SetLampsState[1])
					{
						Status.lampState = _rxData[2];
						if (_rxData[3] != '\r')
						{
							Status.lampColour = _rxData[3];
						}
					}
					sendResponse (new string (_xstResponse.AckValidChar));
					result = true;
				}
			}

			if (!result)
			{
				sendResponse (new string (_xstResponse.ReceivedCommandIsNotValid));
				Logger.Instance.UpdateLog ("CRXSTDriver processNewFrame NO RESULT FOR FRAME: " + DriverUtils.Instance.ConvertToHex (_rxData), LoggerType.Develop, true);
			}

			return result;
		}

		#endregion

		#region Output

		/// <summary> Sends the response to the Serial Port.</summary>
		/// <param name="response">Response.</param>
		private void sendResponse (string response)
		{
			if (_serialPort.IsOpen)
			{
				try
				{
					_serialPort.Write (response);
					Logger.Instance.UpdateLog ("Serial port wrote: [" + Helper.Instance.StringToHex (response) + "] (" + response + ")", LoggerType.Develop);
				}
				catch (Exception ex)
				{
					Logger.Instance.UpdateLog ("Serial port write exception: " + ex, LoggerType.Error);
				}
			}
		}

		#endregion

		#region Interface Methods

		/// <summary>Inserts the card.</summary>
		/// <returns>The operation result.</returns>
		/// <param name="number">Card number.</param>
		public InsertCardError InsertCard (string number)
		{
			if (Status.connected)
			{   // Check connection
				if (!Status.cardIn)
				{   // Check card status
					string card = "";
					if (number != "")
					{
						Status.card = number;
					}
					if (Status.error == XstErrorCode.OK)
					{
						card = Status.card;
					}
					else
					{
						Status.format = XstFormat.Failed;
					}
					_track1.SetFormat (Status.format);
					_track1.SetError (Status.error);
					_track1.SetCard (card);
					_track2.SetFormat (Status.format);
					_track2.SetError (Status.error);
					_track2.SetCard (card);
					Status.cardDetect = '1';
					sendResponse (string.Format ("!{0}", Status.cardDetect) + '\r' + '\n');
					Status.cardDetect = '3';
					sendResponse (string.Format ("!{0}", Status.cardDetect) + '\r' + '\n');
					Status.cardIn = true;
					return InsertCardError.None;
				}
				else
				{
					Logger.Instance.UpdateLog ("CardReader InsertCard() card is already inside.", LoggerType.Warning);
					return InsertCardError.CardAlreadyInside;
				}

			}
			else
			{
				Logger.Instance.UpdateLog ("CardReader InsertCard() called but Status.connected is false.", LoggerType.Warning);
			}
			return InsertCardError.NoCommunication;
		}

		/// <summary>Removes the card.</summary>
		/// <returns>The operation result.</returns>
		public RemoveCardError RemoveCard ()
		{
			if (Status.connected)
			{       // Check connection
				if (Status.cardIn)
				{   // Check card status
					Status.cardDetect = '1';
					sendResponse (string.Format ("!{0}", Status.cardDetect) + '\r' + '\n');
					Status.cardDetect = '0';
					sendResponse (string.Format ("!{0}", Status.cardDetect) + '\r' + '\n');
					Status.cardIn = false;
					return RemoveCardError.None;
				}
				else
				{
					return RemoveCardError.NoCardInside;
				}
			}
			return RemoveCardError.NoCommunication;
		}

		#endregion

		#region XST specific

		void BuildXstCommands ()
		{
			_xstCommand = new XstCommand (true);

			_xstCommand.ResetReader[0] = 'X';
			_xstCommand.ResetReader[1] = 'R';
			_xstCommand.ResetReader[2] = '\r';
			_xstCommand.ResetReader[3] = '\n';

			_xstCommand.ResetReaderToDefaultSettings[0] = 'X';
			_xstCommand.ResetReaderToDefaultSettings[1] = 'D';
			_xstCommand.ResetReaderToDefaultSettings[2] = '\r';
			_xstCommand.ResetReaderToDefaultSettings[3] = '\n';

			_xstCommand.ResetReadDataBuffers[0] = 'X';
			_xstCommand.ResetReadDataBuffers[1] = 'B';
			_xstCommand.ResetReadDataBuffers[2] = '\r';
			_xstCommand.ResetReadDataBuffers[3] = '\n';

			_xstCommand.ReadModelNumber[0] = 'R';
			_xstCommand.ReadModelNumber[1] = 'M';
			_xstCommand.ReadModelNumber[2] = '\r';
			_xstCommand.ReadModelNumber[3] = '\n';

			_xstCommand.ReadCodeVersion[0] = 'R';
			_xstCommand.ReadCodeVersion[1] = 'V';
			_xstCommand.ReadCodeVersion[2] = '\r';
			_xstCommand.ReadCodeVersion[3] = '\n';

			_xstCommand.ReadUnitInformation[0] = 'R';
			_xstCommand.ReadUnitInformation[1] = 'I';
			_xstCommand.ReadUnitInformation[2] = '\r';
			_xstCommand.ReadUnitInformation[3] = '\n';

			_xstCommand.ReadFormattingAndReadOperationSetup[0] = 'R';
			_xstCommand.ReadFormattingAndReadOperationSetup[1] = 'S';
			_xstCommand.ReadFormattingAndReadOperationSetup[2] = '\r';
			_xstCommand.ReadFormattingAndReadOperationSetup[3] = '\n';

			_xstCommand.ReadFormatingSettings[0] = 'R';
			_xstCommand.ReadFormatingSettings[1] = 'F';
			_xstCommand.ReadFormatingSettings[2] = '\r';
			_xstCommand.ReadFormatingSettings[3] = '\n';

			_xstCommand.ReadCardDetects[0] = 'R';
			_xstCommand.ReadCardDetects[1] = 'D';
			_xstCommand.ReadCardDetects[2] = '\r';
			_xstCommand.ReadCardDetects[3] = '\n';

			_xstCommand.TransmitAllTracks[0] = 'T';
			_xstCommand.TransmitAllTracks[1] = '0';
			_xstCommand.TransmitAllTracks[2] = '\r';
			_xstCommand.TransmitAllTracks[3] = '\n';

			_xstCommand.TransmitTrack1[0] = 'T';
			_xstCommand.TransmitTrack1[1] = '1';
			_xstCommand.TransmitTrack1[2] = '\r';
			_xstCommand.TransmitTrack1[3] = '\n';

			_xstCommand.TransmitTrack2[0] = 'T';
			_xstCommand.TransmitTrack2[1] = '2';
			_xstCommand.TransmitTrack2[2] = '\r';
			_xstCommand.TransmitTrack2[3] = '\n';

			_xstCommand.TransmitTrack1RawInBinary[0] = 'B';
			_xstCommand.TransmitTrack1RawInBinary[1] = '1';
			_xstCommand.TransmitTrack1RawInBinary[2] = '\r';
			_xstCommand.TransmitTrack1RawInBinary[3] = '\n';

			_xstCommand.TransmitTrack2RawInBinary[0] = 'B';
			_xstCommand.TransmitTrack2RawInBinary[1] = '2';
			_xstCommand.TransmitTrack2RawInBinary[2] = '\r';
			_xstCommand.TransmitTrack2RawInBinary[3] = '\n';

			_xstCommand.TransmitTrack1RawInHex[0] = 'H';
			_xstCommand.TransmitTrack1RawInHex[1] = '1';
			_xstCommand.TransmitTrack1RawInHex[2] = '\r';
			_xstCommand.TransmitTrack1RawInHex[3] = '\n';

			_xstCommand.TransmitTrack2RawInHex[0] = 'H';
			_xstCommand.TransmitTrack2RawInHex[1] = '2';
			_xstCommand.TransmitTrack2RawInHex[2] = '\r';
			_xstCommand.TransmitTrack2RawInHex[3] = '\n';

			_xstCommand.SetTransmitionLineTermination[0] = 'S';
			_xstCommand.SetTransmitionLineTermination[1] = 'E';
			_xstCommand.SetTransmitionLineTermination[2] = '1'; //All commands terminate with <CR><LF> ('\r' '\n') [Default]
			_xstCommand.SetTransmitionLineTermination[3] = '\r';
			_xstCommand.SetTransmitionLineTermination[4] = '\n';

			_xstCommand.SetFormat[0] = 'S';
			_xstCommand.SetFormat[1] = 'F';
			_xstCommand.SetFormat[2] = '1'; //Track 1 with format ANSI/ISO/ALPHA [Default]
			_xstCommand.SetFormat[3] = '0'; //Track 2 with format ANSI/ISO/BCD [Default]
			_xstCommand.SetFormat[4] = '\r';
			_xstCommand.SetFormat[5] = '\n';

			_xstCommand.SetCardReadDiretion[0] = 'S';
			_xstCommand.SetCardReadDiretion[1] = 'C';
			_xstCommand.SetCardReadDiretion[2] = '2';   //Read the card on insertion (out to in) [Default]
			_xstCommand.SetCardReadDiretion[3] = '\r';
			_xstCommand.SetCardReadDiretion[4] = '\n';

			_xstCommand.SetDataDirection[0] = 'S';
			_xstCommand.SetDataDirection[1] = 'D';
			_xstCommand.SetDataDirection[2] = '1';  //Track 1 reads Data Forward [Default]
			_xstCommand.SetDataDirection[3] = '1';  //Track 2 reads Data Forward [Default]
			_xstCommand.SetDataDirection[4] = '\r';
			_xstCommand.SetDataDirection[5] = '\n';

			_xstCommand.SetLampsState[0] = 'S';
			_xstCommand.SetLampsState[1] = 'L';
			_xstCommand.SetLampsState[2] = '0'; //Turn off leds
			_xstCommand.SetLampsState[3] = '\r';
			_xstCommand.SetLampsState[4] = '\n';

			_xstCommand.SetLampsStateAndColor[0] = 'S';
			_xstCommand.SetLampsStateAndColor[1] = 'L';
			_xstCommand.SetLampsStateAndColor[2] = '1'; //Turn on leds
			_xstCommand.SetLampsStateAndColor[3] = '1'; //Turn Red color leds
			_xstCommand.SetLampsStateAndColor[4] = '\r';
			_xstCommand.SetLampsStateAndColor[5] = '\n';

			_xstCommand.SetLampsRed[0] = 'S';
			_xstCommand.SetLampsRed[1] = 'L';
			_xstCommand.SetLampsRed[2] = '1'; //Turn on leds
			_xstCommand.SetLampsRed[3] = '1'; //Turn Red color leds
			_xstCommand.SetLampsRed[4] = '\r';
			_xstCommand.SetLampsRed[5] = '\n';

			_xstCommand.SetLampsGreen[0] = 'S';
			_xstCommand.SetLampsGreen[1] = 'L';
			_xstCommand.SetLampsGreen[2] = '1'; //Turn on leds
			_xstCommand.SetLampsGreen[3] = '2'; //Turn Green color leds
			_xstCommand.SetLampsGreen[4] = '\r';
			_xstCommand.SetLampsGreen[5] = '\n';

			_xstCommand.SetLampsOff[0] = 'S';
			_xstCommand.SetLampsOff[1] = 'L';
			_xstCommand.SetLampsOff[2] = '0'; //Turn on leds
			_xstCommand.SetLampsOff[3] = '2'; //Turn Green color leds
			_xstCommand.SetLampsOff[4] = '\r';
			_xstCommand.SetLampsOff[5] = '\n';

			// SArcl : r = ”0” Turn OFF automatic valid read transmissions. r = ”1” Turn ON automatic valid read transmissions. c = ”0” Turn OFF automatic card detect status change transmissions. c = ”1” Turn ON automatic card detect status change transmissions. l = ”0” Turn OFF Automatic Lamp function. l = ”1” Turn ON Automatic Lamp function.
			_xstCommand.SetAutoTransmissions[0] = 'S';
			_xstCommand.SetAutoTransmissions[1] = 'A';
			_xstCommand.SetAutoTransmissions[2] = '0';  //Turn off auto send of the card read
			_xstCommand.SetAutoTransmissions[3] = '1';  //Turn off the auto send of the sensor states
			_xstCommand.SetAutoTransmissions[4] = '0';  //Turn off the aut0 led state
			_xstCommand.SetAutoTransmissions[5] = '\r';
			_xstCommand.SetAutoTransmissions[6] = '\n';
		}

		void BuildXstResponses ()
		{
			_xstResponse = new XstResponse (true);

			_xstResponse.AckValidChar[0] = '^';
			_xstResponse.AckValidChar[1] = '\r';
			_xstResponse.AckValidChar[2] = '\n';

			_xstResponse.AutoValidCardHeader[0] = '|';
			_xstResponse.AutoValidCardHeader[1] = '\r';
			_xstResponse.AutoValidCardHeader[2] = '\n';

			_xstResponse.AutoCardDetectChangeHeader[0] = '!';
			_xstResponse.AutoCardDetectChangeHeader[1] = '\r';
			_xstResponse.AutoCardDetectChangeHeader[2] = '\n';

			_xstResponse.ReceivedCommandIsNotValid[0] = '?';
			_xstResponse.ReceivedCommandIsNotValid[1] = '\r';
			_xstResponse.ReceivedCommandIsNotValid[2] = '\n';

			_xstResponse.ParatyErrorDetected[0] = '+';
			_xstResponse.ParatyErrorDetected[1] = '\r';
			_xstResponse.ParatyErrorDetected[2] = '\n';

			_xstResponse.FrammingError[0] = '*';
			_xstResponse.FrammingError[1] = '\r';
			_xstResponse.FrammingError[2] = '\n';

			_xstResponse.CommunicationTimeout[0] = '%';
			_xstResponse.CommunicationTimeout[1] = '\r';
			_xstResponse.CommunicationTimeout[2] = '\n';

			_xstResponse.HardwareReset[0] = '#';
			_xstResponse.HardwareReset[1] = '\r';
			_xstResponse.HardwareReset[2] = '\n';

		}

		struct XstCommand
		{
			public XstCommand (bool notUsed = true)
			{
				ResetReader = new char[4];
				ResetReaderToDefaultSettings = new char[4];
				ResetReadDataBuffers = new char[4];
				ReadModelNumber = new char[4];
				ReadCodeVersion = new char[4];
				ReadUnitInformation = new char[4];
				ReadFormattingAndReadOperationSetup = new char[4];
				ReadFormatingSettings = new char[4];
				ReadCardDetects = new char[4];
				TransmitAllTracks = new char[4];
				TransmitTrack1 = new char[4];
				TransmitTrack2 = new char[4];
				TransmitTrack1RawInBinary = new char[4];
				TransmitTrack2RawInBinary = new char[4];
				TransmitTrack1RawInHex = new char[4];
				TransmitTrack2RawInHex = new char[4];
				SetTransmitionLineTermination = new char[5];
				SetFormat = new char[6];
				SetCardReadDiretion = new char[5];
				SetDataDirection = new char[6];
				SetLampsState = new char[5];
				SetLampsRed = new char[6];
				SetLampsGreen = new char[6];
				SetLampsOff = new char[6];
				SetLampsStateAndColor = new char[6];
				SetAutoTransmissions = new char[7];
			}

			public char[] ResetReader;
			public char[] ResetReaderToDefaultSettings;
			public char[] ResetReadDataBuffers;

			public char[] ReadModelNumber;
			public char[] ReadCodeVersion;
			public char[] ReadUnitInformation;
			public char[] ReadFormattingAndReadOperationSetup;
			public char[] ReadFormatingSettings;
			public char[] ReadCardDetects;

			public char[] TransmitAllTracks;
			public char[] TransmitTrack1;
			public char[] TransmitTrack2;
			public char[] TransmitTrack1RawInBinary;
			public char[] TransmitTrack2RawInBinary;
			public char[] TransmitTrack1RawInHex;
			public char[] TransmitTrack2RawInHex;

			public char[] SetTransmitionLineTermination;
			public char[] SetFormat;
			public char[] SetCardReadDiretion;
			public char[] SetDataDirection;
			public char[] SetLampsState;
			public char[] SetLampsRed;
			public char[] SetLampsGreen;
			public char[] SetLampsOff;
			public char[] SetLampsStateAndColor;
			public char[] SetAutoTransmissions;
		};

		struct XstResponse
		{
			public XstResponse (bool notUsed = true)
			{
				AckValidChar = new char[3];
				AutoValidCardHeader = new char[3];
				AutoCardDetectChangeHeader = new char[3];
				ReceivedCommandIsNotValid = new char[3];
				ParatyErrorDetected = new char[3];
				FrammingError = new char[3];
				CommunicationTimeout = new char[3];
				HardwareReset = new char[3];
			}

			public char[] AckValidChar;
			public char[] AutoValidCardHeader;
			public char[] AutoCardDetectChangeHeader;
			public char[] ReceivedCommandIsNotValid;
			public char[] ParatyErrorDetected;
			public char[] FrammingError;
			public char[] CommunicationTimeout;
			public char[] HardwareReset;
		};

		class XstFormat
		{
			public const string Alpha = "A";
			public const string BCD = "B";
			public const string Failed = "F";
			public const string NoData = "N";
		}

		class XstErrorCode
		{
			public const string OK = "0";
			public const string NoLeadingZeros = "1";
			public const string NoStartSentinal = "2";
			public const string ParityError = "3";
			public const string NoEndSentinal = "4";
			public const string LRCCheckFailed = "5";
			public const string TrackNotInstalled = "6";
			public const string NoData = "9";
		}

		class Constants
		{
			public const int CARDREADER_DRIVER_XST_MAX_LEGAL_FRAME_SIZE = 74;
			//21+3+45+3+2
		}

		#endregion
	}
}

