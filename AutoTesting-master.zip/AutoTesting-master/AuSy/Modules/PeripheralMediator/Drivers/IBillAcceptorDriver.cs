﻿using AutoTestingService;

namespace AuSy.Modules.PeripheralMediator.Drivers
{
	public interface IBillAcceptorDriver
	{
		void Init (string port);

		void Terminate ();

		InsertBillError InsertBill (int value);

		InsertTicketError InsertTicket (string code);
	}
}
