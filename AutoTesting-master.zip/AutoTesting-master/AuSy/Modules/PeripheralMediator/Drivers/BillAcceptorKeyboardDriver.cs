using AutoTestingService;

namespace AuSy.Modules.PeripheralMediator.Drivers
{
    public class BillAcceptorKeyboardDriver : IBillAcceptorDriver
    {
        public BillAcceptorKeyboardDriver()
        {
        }

        #region Interface methods
        
        public void Init(string _)
        {
        }

        public void Terminate()
        {
            
        }

        public InsertBillError InsertBill(int _)
        {
            EventHandler.Instance.Trigger("PressKey", "5 8 1");

            return InsertBillError.None;
        }

        public InsertTicketError InsertTicket(string _)
        {
            return InsertTicketError.None;
        }
        
        #endregion
        
    }
}