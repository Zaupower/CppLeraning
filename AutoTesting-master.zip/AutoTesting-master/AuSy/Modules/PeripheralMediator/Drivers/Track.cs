﻿namespace AuSy.Modules.PeripheralMediator.Drivers
{
	public class Track
	{
		#region Variables

		private string _enabled;
		private string _format;
		private string _error;
		private string _card;

		#endregion

		#region Init

		// Constructor
		public Track ()
		{
			initializeTrack ();
		}

		/// <summary>Initializes the track with default values. </summary>
		private void initializeTrack ()
		{
			_enabled = "true";
			_format = "A";
			_error = "0";
			_card = "";
		}

		#endregion

		#region Access

		/// <summary> Gets the enabled variable.</summary>
		/// <returns>Enabled variable.</returns>
		public string GetEnabled ()
		{
			return _enabled;
		}

		/// <summary>Sets the enabled variable.</summary>
		/// <param name="enabled">Enabled variable state.</param>
		public void SetEnabled (string enabled)
		{
			_enabled = enabled;
		}

		/// <summary> Gets the format variable.</summary>
		/// <returns>Format variable.</returns>
		public string GetFormat ()
		{
			return _format;
		}

		/// <summary>Sets the format variable.</summary>
		/// <param name="format">Format variable state.</param>
		public void SetFormat (string format)
		{
			_format = format;
		}

		/// <summary> Gets the error variable.</summary>
		/// <returns>Error variable.</returns>
		public string GetError ()
		{
			return _error;
		}

		/// <summary>Sets the error variable.</summary>
		/// <param name="error">Error variable state.</param>
		public void SetError (string error)
		{
			_error = error;
		}

		/// <summary> Gets the card variable.</summary>
		/// <returns>Card variable.</returns>
		public string GetCard ()
		{
			return _card;
		}

		/// <summary>Sets the card variable.</summary>
		/// <param name="card">Card variable state.</param>
		public void SetCard (string card)
		{
			_card = card;
		}

		#endregion
	}
}

