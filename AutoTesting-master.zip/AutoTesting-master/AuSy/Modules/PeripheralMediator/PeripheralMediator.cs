﻿using System;
using System.Collections.Generic;
using AuSy.Modules.PeripheralMediator.Peripherals;
using AutoTestingService;
using AutoTestingService.Configuration.AusyConfig;
using AutoTestingService.Logging;
using EventHandler = AutoTestingService.EventHandler;

namespace AuSy.Modules.PeripheralMediator
{
	public class PeripheralMediator
	{
		#region Singleton

		public static PeripheralMediator Instance { get; } = new PeripheralMediator ();

		private PeripheralMediator ()
		{
		}

		#endregion
		
		#region Members

		CardReaderManager cardReaderManager = new CardReaderManager ();
		BillAcceptorManager billAcceptorManager = new BillAcceptorManager ();

		private bool _enableKeyboardAcceptor;
		private List<Peripheral> _requiredPeripherals;

		#endregion
		

		// TODO quando passarem a existir periféricos que não sejam de Accounting, pensar em alterar este Init (para não depender de Accounting, com o param requiredPeripherals)
		/// <summary>Initializes the peripheral mediator, also initializing the necessary peripheral managers.</summary>
		public void Init (AusyPeripheralConfig ausyPeripheralConfig, bool enableKeyboardAcceptor, List<Peripheral> requiredPeripherals)
		{
			_enableKeyboardAcceptor = enableKeyboardAcceptor;
			_requiredPeripherals = requiredPeripherals;
			if (!ausyPeripheralConfig.UsePeripherals)
			{
				return;
			}
			
			if (requiredPeripherals.Contains (Peripheral.CardReader))
			{
				cardReaderManager.Init (CardReaderDriver.Magtek, ausyPeripheralConfig.CardReaderPort);
				EventHandler.Instance.AddCallback("S2SInsertCard", InsertCard);
				EventHandler.Instance.AddCallback("S2SRemoveCard", RemoveCard);
			}
			if (requiredPeripherals.Contains (Peripheral.BillAcceptor) || enableKeyboardAcceptor)
			{
				billAcceptorManager.Init (enableKeyboardAcceptor, ausyPeripheralConfig.BillAcceptorPort, ausyPeripheralConfig.DebugCashCode);
				EventHandler.Instance.AddCallback("TITOInsertBill", InsertBill);
				EventHandler.Instance.AddCallback("TITOInsertTicket", InsertTicket);
			}
		}

		/// <summary>Terminate the peripheral mediator, also closing the necessary peripheral managers.</summary>
		public void Terminate ()
		{
			cardReaderManager.Terminate ();
			billAcceptorManager.Terminate ();
			if (_requiredPeripherals.Contains (Peripheral.CardReader))
			{
				EventHandler.Instance.RemoveCallback("S2SInsertCard", InsertCard);
				EventHandler.Instance.RemoveCallback("S2SRemoveCard", RemoveCard);
			}
			if (_requiredPeripherals.Contains (Peripheral.BillAcceptor) || _enableKeyboardAcceptor)
			{
				EventHandler.Instance.RemoveCallback("TITOInsertBill", InsertBill);
				EventHandler.Instance.RemoveCallback("TITOInsertTicket", InsertTicket);
			}
		}

		/// <summary>Asks the Bill Acceptor Manager to insert a bill.</summary>
		/// <param name="value">Value of the bill.</param>
		public void InsertBill (string value, EventInfo? _)
		{
			if (billAcceptorManager.IsInitialized())
			{
				billAcceptorManager.InsertBill(Int32.Parse(value));
			}
			else
			{
				Logger.Instance.UpdateLog("InsertBill error: AuSy's bill acceptor was never initialized.");
			}
		}

		/// <summary>Asks the Bill Acceptor Manager to insert a ticket.</summary>
		/// <param name="code">Code of the ticket.</param>
		public void InsertTicket (string code, EventInfo? _)
		{
			if (billAcceptorManager.IsInitialized())
			{
				billAcceptorManager.InsertTicket (code);
			}
			else
			{
				Logger.Instance.UpdateLog("InsertTicket error: AuSy's bill acceptor was never initialized.");
			}
		}

		/// <summary>Asks the Card Reader Manager to insert a card.</summary>
		/// <param name="nr">Card number.</param>
		public void InsertCard (string nr, EventInfo? _)
		{
			InsertCardError result;
			if (cardReaderManager.IsInitialized())
			{
				result = cardReaderManager.InsertCard (nr);
			}
			else
			{
				Logger.Instance.UpdateLog("InsertCard error: AuSy's card reader was never initialized.");
				result = InsertCardError.NoDriver;
			}

			if (result == InsertCardError.CardAlreadyInside)
			{
				Logger.Instance.UpdateLog ("Card already inside!", LoggerType.Warning, true);
				EventDistributor.Instance.Trigger("S2SCardAlreadyInside", "");
			}
			else
			{
				Logger.Instance.UpdateLog ("Card inserted!", LoggerType.Info, true);
			}
		}

		/// <summary>Asks the Card Reader Manager to remove the card.</summary>
		public void RemoveCard (string _, EventInfo? __)
		{
			if (cardReaderManager.IsInitialized())
			{
				cardReaderManager.RemoveCard ();
			}
			else
			{
				Logger.Instance.UpdateLog("RemoveCard error: AuSy's card reader was never initialized.");
			}
		}
	}
}

