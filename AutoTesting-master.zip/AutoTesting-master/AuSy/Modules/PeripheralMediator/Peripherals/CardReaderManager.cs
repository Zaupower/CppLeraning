﻿using AuSy.Modules.PeripheralMediator.Drivers;
using AutoTestingService;
using AutoTestingService.Logging;

namespace AuSy.Modules.PeripheralMediator.Peripherals
{
	public class CardReaderManager
	{
		private ICardReaderDriver _driver;

		/// <summary>Initializes the card reader manager, creating the instance of the correct driver.</summary>
		public void Init (CardReaderDriver driver, string port)
		{
			switch (driver)
			{
			case CardReaderDriver.Magtek:
				_driver = new CardReaderMagtekDriver ();
				break;
			}

			_driver.Init (port);
		}

		/// <summary>Terminate the card reader manager and the initialized driver.</summary>
		public void Terminate ()
		{
			_driver?.Terminate();
		}

		/// <summary>Inserts a card using the current card reader driver.</summary>
		public InsertCardError InsertCard (string nr)
		{
			Logger.Instance.UpdateLog ("Inserting card " + nr + "...");
			return _driver.InsertCard (nr);
		}

		/// <summary>Removes the current card using the current card reader driver.</summary>
		public RemoveCardError RemoveCard ()
		{
			Logger.Instance.UpdateLog ("Removing card...");
			return _driver.RemoveCard ();
		}
		
		/// <summary>Returns whether the manager has been initialized.</summary>
		/// <returns>Whether the manager has been initialized.</returns>
		public bool IsInitialized ()
		{
			return _driver != null;
		}
	}
}

