﻿using AuSy.Modules.PeripheralMediator.Drivers;
using AutoTestingService;
using AutoTestingService.Logging;

namespace AuSy.Modules.PeripheralMediator.Peripherals
{
	public class BillAcceptorManager
	{
		private Drivers.IBillAcceptorDriver _driver;

		/// <summary>Initializes the bill acceptor manager, creating the instance of the correct driver.</summary>
		public void Init (bool useKeyboardAcceptor, string port, bool debugCashCode)
		{
			if (useKeyboardAcceptor)
				_driver = new BillAcceptorKeyboardDriver ();
			else
			{
				BillAcceptorCashCodeDriver.Instance.DebugCashCode = debugCashCode;
				_driver = BillAcceptorCashCodeDriver.Instance;
			}
			

			_driver.Init (port);
		}

		/// <summary>Terminate the bill acceptor manager and the initialized driver.</summary>
		public void Terminate ()
		{
			_driver?.Terminate ();
		}

		/// <summary>Inserts a bill using the current bill acceptor driver.</summary>
		/// <param name="value">Value of the bill.</param>
		public InsertBillError InsertBill (int value)
		{
			Logger.Instance.UpdateLog ("Inserting bill with value " + value + "...");
			InsertBillError result = _driver.InsertBill (value);
			if(result != InsertBillError.None && _driver == BillAcceptorCashCodeDriver.Instance)
				BillAcceptorCashCodeDriver.Instance.resetStateToIdling();
			if(result == InsertBillError.BillRejectedBadState) {
				Logger.Instance.UpdateLog("Bill rejected because the acceptor is not in a state that can handle it.");
			}

			return result;
		}

		/// <summary>Inserts a ticket using the current bill acceptor driver.</summary>
		/// <param name="code">Code of the ticket.</param>
		public InsertTicketError InsertTicket (string code)
		{
			Logger.Instance.UpdateLog ("Inserting ticket with code " + code + "...");
			return _driver.InsertTicket (code);
		}
		
		/// <summary>Returns whether the manager has been initialized.</summary>
		/// <returns>Whether the manager has been initialized.</returns>
		public bool IsInitialized ()
		{
			return _driver != null;
		}
	}
}


