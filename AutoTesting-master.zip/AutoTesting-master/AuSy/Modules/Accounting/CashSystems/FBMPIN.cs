using System.Collections.Generic;
using AutoTestingService;
using AutoTestingService.Logging;

namespace AuSy.Modules.Accounting.CashSystems
{
    public class FBMPIN : ICashSystem
    {
        /// <summary>Initializes a new instance of the <see cref="T:AuSy.Modules.Accounting.CashSystems.FBMPIN"/> class.</summary>
        public FBMPIN ()
        {
        }

        /// <summary>Initializes the FBM PIN cash system.</summary>
        public void Init()
        {
        }
        
        /// <summary>Destroys the TITO cash system.</summary>
        public void Destroy()
        {
        }

        /// <summary>This method only exists because of the ICashSystem Interface. There are no peripherals in Ausy for the FBM PIN cash system.</summary>
        public List<Peripheral> GetRequiredPeripherals ()
        {
            return new List<Peripheral>();
        }

        /// <summary>Inserts credits by sending StartAFTCashIn message to SAS.</summary>
        public void InsertCredits ()
        {
            // To Implement!!
            Logger.Instance.UpdateLog ("InsertCredits for FBM PIN cash system is not implemented yet.", LoggerType.Warning);
        }

        public void InsertCard(string number)
        {
            Logger.Instance.UpdateLog ("Can't InsertCard using FBM PIN cash system.", LoggerType.Warning);
        }

        /// <summary>Inserts a bill. For FBM PIN cash system this method can't be used.</summary>
        /// <param name="value">Value of the bill.</param>
        public void InsertBill (int value)
        {
            Logger.Instance.UpdateLog ("Can't InsertBill using FBM PIN cash system.", LoggerType.Warning);
        }


        /// <summary>Inserts a ticket.</summary>
        /// <param name="code">Code of the ticket.</param>
        public void InsertTicket (string code)
        {
            Logger.Instance.UpdateLog ("Can't InsertTicket using FBM PIN cash system.", LoggerType.Warning);
        }


        /// <summary>Removes credits</summary>
        public void RemoveCredits ()
        {
            // To Implement
            Logger.Instance.UpdateLog ("RemoveCredits for FBM PIN cash system is not implemented yet.", LoggerType.Warning);
        }
    }
}