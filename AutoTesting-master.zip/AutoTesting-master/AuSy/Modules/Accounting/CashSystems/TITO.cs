﻿using System.Collections.Generic;
using AutoTestingService;
using AutoTestingService.Logging;

namespace AuSy.Modules.Accounting.CashSystems
{
	public class TITO : ICashSystem
	{
		/// <summary>Initializes a new instance of the <see cref="T:AuSy.Modules.Accounting.CashSystems.TITO"/> class.</summary>
		/// <param name="peripheralMediator">Peripheral mediator.</param>
		public TITO ()
		{
		}
		
		/// <summary>Initializes the TITO cash system.</summary>
		public void Init()
		{
		}

		/// <summary>Destroys the TITO cash system.</summary>
		public void Destroy()
		{
		}

		/// <summary>What peripherals this cash system needs.</summary>
		/// <returns>A list of peripherals that are required.</returns>
		public List<Peripheral> GetRequiredPeripherals ()
		{
			return new List<Peripheral>
			{
				Peripheral.BillAcceptor
			};
		}

		/// <summary>Inserts credits by inserting bills.</summary>
		public void InsertCredits ()
		{
			InsertBill(5);
		}

		public void InsertCard(string _)
		{
			Logger.Instance.UpdateLog ("Can't InsertCard using TITO cash system.", LoggerType.Warning);
		}

		/// <summary>Inserts a bill.</summary>
		/// <param name="value">Value of the bill.</param>
		public void InsertBill (int value)
		{
			Logger.Instance.UpdateLog ("Attempting to insert bill of value " + value + "...", LoggerType.Info, true);
			EventDistributor.Instance.Trigger("TITOInsertBill", value.ToString());
		}


		/// <summary>Inserts a ticket.</summary>
		/// <param name="code">Code of the ticket.</param>
		public void InsertTicket (string code)
		{
			Logger.Instance.UpdateLog ("Attempting to insert ticket with code " + code + "...", LoggerType.Info, true);
			EventDistributor.Instance.Trigger("TITOInsertTicket", code);
		}


		/// <summary>Removes credits by issuing a payment from the EGM.</summary>
		public void RemoveCredits ()
		{
			Logger.Instance.UpdateLog ("Attempting to cash out via keyboard (P)...", LoggerType.Info, true);
			EventHandler.Instance.Trigger("PressKey", "p 1");
		}
	}
}
