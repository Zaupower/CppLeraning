using System.Collections.Generic;
using AutoTestingService;
using AutoTestingService.Logging;

namespace AuSy.Modules.Accounting.CashSystems
{
    public class NoCashSystem : ICashSystem
    {
        /// <summary>Initializes No cash system.</summary>
        public void Init()
        {
            
        }
        
        public void Destroy()
        {

        }

        /// <summary>This method only exists because of the ICashSystem Interface. There are no peripherals in Ausy for the cash system NONE.</summary>
        public List<Peripheral> GetRequiredPeripherals ()
        {
            return new List<Peripheral>();
        }

        /// <summary>Does nothing for no cashSystem.</summary>
        public void InsertCredits ()
        {
            Logger.Instance.UpdateLog ("InsertCredits: cannot insert credits when cashSystem is defined as NONE (=99) in Ausy config.json", LoggerType.Warning);
        }

        public void InsertCard(string number)
        {
            Logger.Instance.UpdateLog ("InsertCard: cannot insert card when cashSystem is defined as NONE (=99) in Ausy config.json", LoggerType.Warning);
        }

        /// <summary>Inserts a bill. For cash system NONE this method can't be used.</summary>
        /// <param name="value">Value of the bill.</param>
        public void InsertBill (int value)
        {
            Logger.Instance.UpdateLog ("InsertBill: cannot insert bill when cashSystem is defined as NONE (=99) in Ausy config.json", LoggerType.Warning);
        }


        /// <summary>Inserts a ticket. For cash system NONE this method can't be used.</summary>
        /// <param name="code">Code of the ticket.</param>
        public void InsertTicket (string code)
        {
            Logger.Instance.UpdateLog ("InsertTicket: cannot insert ticket when cashSystem is defined as NONE (=99) in Ausy config.json", LoggerType.Warning);
        }


        /// <summary>For cash system NONE this method can't be used.</summary>
        public void RemoveCredits ()
        {
            Logger.Instance.UpdateLog ("RemoveCredits: cannot remove credits when cashSystem is defined as NONE (=99) in Ausy config.json", LoggerType.Warning);
        }
    }
}