﻿using System.Collections.Generic;
using AutoTestingService;

namespace AuSy.Modules.Accounting.CashSystems
{
	public interface ICashSystem
	{
		void Init();

		void Destroy();
		
		List<Peripheral> GetRequiredPeripherals ();

		void InsertCredits ();
		
		void InsertCard (string number);

		void InsertBill (int value);

		void InsertTicket (string code);

		void RemoveCredits ();

	}
}

