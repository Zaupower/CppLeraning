using System.Collections.Generic;
using AutoTestingService;
using AutoTestingService.Logging;
using libFmqSasHost;
using Newtonsoft.Json;
using WebSockets;

namespace AuSy.Modules.Accounting.CashSystems
{
    public class SAS : ICashSystem
    {
        private string _sasPort;
        private bool _started = false;

        /// <summary>Initializes a new instance of the <see cref="T:AuSy.Modules.Accounting.CashSystems.SAS"/> class.</summary>
        public SAS (string sasPort)
        {
            _sasPort = sasPort;
        }

        /// <summary>Initializes the SAS cash system.</summary>
        public void Init()
        {
            EventHandler.Instance.AddCallback("StartAusy2", StartFmqSasHost);
            FmqSasHost.Instance.Init(_sasPort, "");
        }

        /// <summary>Destroys the SAS cash system.</summary>
        public void Destroy()
        {
            if (_started)
            {
                FmqSasHost.Instance.Stop();
            }
            EventHandler.Instance.RemoveCallback("StartAusy2", StartFmqSasHost);
            FmqSasHost.Instance.Destroy();
        }

        /// <summary>This method only exists because of the ICashSystem Interface. There are no peripherals in Ausy for the SAS cash system.</summary>
        public List<Peripheral> GetRequiredPeripherals ()
        {
            return new List<Peripheral>
            {
                Peripheral.BillAcceptor
            };
        }

        /// <summary>Inserts credits by sending StartAFTCashIn message to SAS.</summary>
        public void InsertCredits ()
        {
            Logger.Instance.UpdateLog ("InsertCredits: Attempting to cash in via SAS Host...", LoggerType.Info, true);
            Dictionary<string, object> fields = new Dictionary<string, object>();
            fields.Add("cashable", 50000);
            string jsonStrFields = JsonConvert.SerializeObject (fields);
            
            EventHandler.Instance.Trigger("StartAFTCashIn", jsonStrFields);
        }

        public void InsertCard(string number)
        {
            Logger.Instance.UpdateLog ("Can't InsertCard using SAS cash system.", LoggerType.Warning);
        }

        /// <summary>Inserts a bill. For SAS cash system this method can't be used.</summary>
        /// <param name="value">Value of the bill.</param>
        public void InsertBill (int value)
        {
            Logger.Instance.UpdateLog("Attempting to insert bill of value " + value + "...", LoggerType.Info, true);
            EventDistributor.Instance.Trigger("TITOInsertBill", value.ToString());
        }


        /// <summary>Inserts a ticket.</summary>
        /// <param name="code">Code of the ticket.</param>
        public void InsertTicket (string code)
        {
            Logger.Instance.UpdateLog ("Attempting to insert ticket with code " + code + "...", LoggerType.Info, true);
            EventDistributor.Instance.Trigger("TITOInsertTicket", code);
        }


        /// <summary>Removes credits by sending StartAFTCashOut message to SAS</summary>
        public void RemoveCredits ()
        {
            Logger.Instance.UpdateLog ("RemoveCredits: Attempting to cash out via SAS Host...", LoggerType.Info, true);
            EventHandler.Instance.Trigger("StartAFTCashOut", "StartAFTCashOut;");
        }

        private void StartFmqSasHost(string _, EventInfo? __)
        {
            FmqSasHost.Instance.Start();
            Communication.Communication.Instance.hub.EstablishDirectConnection(Apps.Ausy, Apps.Sas, 
                FmqSasHost.Instance.GetCommunicationManager());
            _started = true;
        }
    }
}