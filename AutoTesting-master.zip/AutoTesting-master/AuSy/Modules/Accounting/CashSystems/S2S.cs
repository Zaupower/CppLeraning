﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Net;
using System.Threading;
using AutoTestingService;
using AutoTestingService.Configuration.AusyConfig;
using AutoTestingService.Logging;
using EventHandler = AutoTestingService.EventHandler;

namespace AuSy.Modules.Accounting.CashSystems
{
	public class S2S : ICashSystem
	{

		private string _dbIP;
		private string _dbUser;
		private string _dbPassword;
		private string _dbName;

		private string _cardNumber;
		private bool _allowRecharge;
		private int _rechargeAmount;
		private int _rechargeWait;

		/// <summary>Initializes a new instance of the <see cref="S2S"/> class.</summary>
		/// <param name="config">Configuration to use.</param>
		public S2S (AusyS2SConfig config)
		{
			_dbIP = config.DatabaseIP;
			_dbUser = config.DatabaseUser;
			_dbPassword = config.DatabasePassword;
			_dbName = config.DatabaseName;

			if (config.CardNumberFromIP)
			{
				_cardNumber = GenerateCardNumberFromIP ();
			}
			else
			{
				_cardNumber = config.CardNumber;
			}

			_allowRecharge = config.AllowRecharge;
			_rechargeAmount = config.RechargeAmount;
			_rechargeWait = config.RechargeWait;

			if (_allowRecharge)
			{
				EventHandler.Instance.AddCallback("S2SCardAlreadyInside", (s, e) => RechargeCard());
			}
		}

		/// <summary>Initializes the TITO cash system.</summary>
		public void Init()
		{
		}

		/// <summary>Destroys the TITO cash system.</summary>
		public void Destroy()
		{
		}

		/// <summary>Inserts credits by inserting a card.</summary>
		public void InsertCredits ()
		{
			Logger.Instance.UpdateLog ("Attempting to cash in via card insertion...", LoggerType.Info, true);

			EventDistributor.Instance.Trigger("S2SInsertCard", _cardNumber);
		}
		
		public void InsertCard (string number)
		{
			EventDistributor.Instance.Trigger("S2SInsertCard", _cardNumber);
		}
		
		/// <summary>Inserts a bill. Not applicable for S2S.</summary>
		/// <param name="value">Value of the bill.</param>
		public void InsertBill (int value)
		{
		}


		/// <summary>Inserts a ticket. Not applicable for S2S.</summary>
		/// <param name="code">Code of the ticket.</param>
		public void InsertTicket (string code)
		{
		}


		/// <summary>Generates a card number using the last octet of the local IP address.</summary>
		/// <returns>The generated card number.</returns>
		private string GenerateCardNumberFromIP ()
		{
			string result;
			String strHostName = string.Empty;
			// Getting IP address of local machine...
			// First get the host name of local machine.
			// Then using host name, get the IP address list.
			strHostName = Dns.GetHostName ();
			//Console.WriteLine("Local Machine's Host Name: " + strHostName);
			IPHostEntry ipEntry = Dns.GetHostEntry (strHostName);
			IPAddress[] addr = ipEntry.AddressList;
			/*
			for (int i = 0; i < addr.Length; i++)
			{
				Console.WriteLine("IP Address {0}: {1} ", i, addr[i].ToString());
			}
			*/
			result = (IPAddress.Parse ((addr[0].ToString ())).GetAddressBytes ()[3]).ToString ();
			return result;
		}

		/// <summary>Removes credits by removing the card.</summary>
		public void RemoveCredits ()
		{
			Logger.Instance.UpdateLog ("Attempting to cash out via card removal...", LoggerType.Info, true);
			EventDistributor.Instance.Trigger("S2SRemoveCard", "");
		}

		/// <summary>What peripherals this cash system needs.</summary>
		/// <returns>A list of peripherals that are required.</returns>
		public List<Peripheral> GetRequiredPeripherals ()
		{
			return new List<Peripheral>
			{
				Peripheral.CardReader
			};
		}

		/// <summary>Recharges card and re-inserts it.</summary>
		public void RechargeCard()
		{
			if (!_allowRecharge)
			{
				return;
			}
			Logger.Instance.UpdateLog ("Recharging account via SQL!", LoggerType.Info, true);
			EventDistributor.Instance.Trigger("S2SRemoveCard", "");
			Thread.Sleep (_rechargeWait);
			RechargeAccount ();
			Thread.Sleep (_rechargeWait);
			EventDistributor.Instance.Trigger("S2SInsertCard", _cardNumber);
		}

		/// <summary>Recharges the account by accessing the SQL database.</summary>
		public void RechargeAccount ()
		{
			string conStr = null;
			SqlConnection connection;
			SqlCommand command;
			string sql = null;
			SqlDataReader dataReader;
			conStr = String.Format ("Data Source={0};Initial Catalog={1};User ID={2};Password={3}", _dbIP, _dbName, _dbUser, _dbPassword);
			sql = String.Format ("UPDATE dbo.account SET Balance = {0}.00 WHERE AccountID = '{1}';", _rechargeAmount, _cardNumber);
			connection = new SqlConnection (conStr);
			try
			{
				connection.Open ();
				command = new SqlCommand (sql, connection);
				dataReader = command.ExecuteReader ();
				dataReader.Close ();
				command.Dispose ();
				connection.Close ();
			}
			catch (Exception ex)
			{
				Logger.Instance.UpdateLog ("Error while trying to recharge account via SQL: " + ex, LoggerType.Error);
			}

			return;
		}
	}
}

