﻿using System;
using System.Timers;
using System.Collections.Generic;
using AuSy.Modules.Accounting.CashSystems;
using AutoTestingService;
using AutoTestingService.Configuration.AusyConfig;
using AutoTestingService.Logging;
using EventHandler = AutoTestingService.EventHandler;

namespace AuSy.Modules.Accounting
{
	public class Accounting
	{
		#region Singleton

		public static Accounting Instance { get; } = new Accounting ();

		private Accounting ()
		{
		}

		#endregion
		
		private ICashSystem _cashSystem;

		#region Flags e timers

		private static Timer CooldownTimer;
		private bool BILL_ACCEPTOR_COOLDOWN = false;
		
		#endregion
		
		#region Init and Terminate

		/// <summary>Initializes the accounting system, creating the instance of the correct cash system.</summary>
		public void Init (CashSystem cashSystem, AusyS2SConfig s2sConfig, string sasPort)
		{
			switch (cashSystem)
			{
				case CashSystem.TITO:
					_cashSystem = new TITO ();
					break;
				case CashSystem.S2S:
					_cashSystem = new S2S (s2sConfig);
					break;
				case CashSystem.SAS:
					_cashSystem = new SAS (sasPort);
					break;
				case CashSystem.FBMPIN:
					_cashSystem = new FBMPIN ();
					break;
				case CashSystem.NONE:
					_cashSystem = new NoCashSystem ();
					break;
			}
			
			_cashSystem?.Init();

			EventHandler.Instance.AddCallback("InsertCredits", InsertCredits);
			EventHandler.Instance.AddCallback("InsertBill", InsertBill);
			EventHandler.Instance.AddCallback("InsertCard", InsertCard);
			EventHandler.Instance.AddCallback("InsertTicket", InsertTicket);
			EventHandler.Instance.AddCallback("RemoveCredits", RemoveCredits);
		}
		
		/// <summary>Terminates the accounting system, destroying the instance.</summary>
		public void Terminate ()
		{
			_cashSystem.Destroy();
			_cashSystem = null;

			EventHandler.Instance.RemoveCallback("InsertCredits", InsertCredits);
			EventHandler.Instance.RemoveCallback("InsertBill", InsertBill);
			EventHandler.Instance.RemoveCallback("InsertCard", InsertCard);
			EventHandler.Instance.RemoveCallback("InsertTicket", InsertTicket);
			EventHandler.Instance.RemoveCallback("RemoveCredits", RemoveCredits);
		}
		
		#endregion

		private void ReenableBillAcceptor(Object source, ElapsedEventArgs e)
		{
			Logger.Instance.UpdateLog("Bill acceptor re-enabled!",
				LoggerType.Info, true);
			BILL_ACCEPTOR_COOLDOWN = false;
			CooldownTimer.Stop();
			CooldownTimer.Dispose();
		}

		/// <summary>Sets the timer for the bill acceptor cooldown.</summary>
		private void BillAcceptorTimer()
		{
			BILL_ACCEPTOR_COOLDOWN = true;
			CooldownTimer = new Timer(3000);
			CooldownTimer.Elapsed += ReenableBillAcceptor;
			CooldownTimer.Start();

		}
		
		/// <summary>Asks the current cash system to inserts credits.</summary>
		private void InsertCredits (string _, EventInfo? __)
		{
			Logger.Instance.UpdateLog ("InsertCredits", LoggerType.Info, true);
			_cashSystem.InsertCredits ();
		}

		/// <summary>Asks the current cash system to inserts credits.</summary>
		private void InsertCard (string number, EventInfo? _)
		{
			if (!BILL_ACCEPTOR_COOLDOWN)
			{
				BillAcceptorTimer();
				Logger.Instance.UpdateLog ("InsertCard", LoggerType.Info, true);
				_cashSystem.InsertCard (number);
			}
			else
			{
				Logger.Instance.UpdateLog("Card: " + number + " - Bill acceptor in cooldown. Unable to send command",
					LoggerType.Info, true);
			}
		}

		/// <summary>Asks the current cash system to insert a bill.</summary>
		/// <param name="value">Value of the bill.</param>
		private void InsertBill (string value, EventInfo? _)
		{
			if (!BILL_ACCEPTOR_COOLDOWN)
			{
				BillAcceptorTimer();
				Logger.Instance.UpdateLog ("InsertBill: " + value, LoggerType.Info, true);
				_cashSystem.InsertBill (int.Parse(value));
			}
			else
			{
				Logger.Instance.UpdateLog("Bill: " + value + " - Bill acceptor in cooldown. Unable to send command",
					LoggerType.Info, true);
			}
		}

		/// <summary>Asks the current cash system to insert a ticket.</summary>
		/// <param name="code">Code of the ticket.</param>
		private void InsertTicket(string code, EventInfo? _)
		{
			if (!BILL_ACCEPTOR_COOLDOWN)
			{
				BillAcceptorTimer();
				Logger.Instance.UpdateLog("InsertTicket: " + code, LoggerType.Info, true);
				_cashSystem.InsertTicket(code);
			}
			else
			{
				Logger.Instance.UpdateLog("Ticket: " + code + " - Bill acceptor in cooldown. Unable to send command",
					LoggerType.Info, true);
			}
		}

		/// <summary>Asks the current cash system to remove credits.</summary>
		private void RemoveCredits (string _, EventInfo? __)
		{
			Logger.Instance.UpdateLog ("RemoveCredits", LoggerType.Info, true);
			_cashSystem.RemoveCredits ();
		}

		/// <summary>Asks the cash system what peripherals it needs.</summary>
		/// <returns>A list of necessary peripherals.</returns>
		public List<Peripheral> GetRequiredPeripherals ()
		{
			if (_cashSystem == null)
			{
				Logger.Instance.UpdateLog("Can't get required peripherals: no cash system loaded (Accounting module not loaded or cash system not defined in Ausy config).", LoggerType.Warning);
				return new List<Peripheral>();
			}
			return _cashSystem.GetRequiredPeripherals ();
		}
	}
}

