using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Threading;
using AutoTestingService;
using AutoTestingService.Logging;
using AutoTestingService.Shared;
using Newtonsoft.Json;
using EventHandler = AutoTestingService.EventHandler;

namespace AuSy.Modules.ActionMediator
{
    /// <summary>Performs actions on the game/EGM.</summary>
	public class ActionMediator
    {
	    #region Singleton

	    public static ActionMediator Instance { get; } = new ActionMediator ();

	    private ActionMediator ()
	    {
	    }

	    #endregion
	    
	    #region Members

	    /// <summary>Configuration about how the Action Mediator should work.</summary>
        private ActionMediatorConfig _config;

	    /// <summary>Name of every button, and what keyboard key it maps to.</summary>
        private Dictionary<string, string> _buttonsMap = new Dictionary<string, string>();

        #endregion
	    
	    #region Init and terminate

	    /// <summary>Initializes the Action Mediator module.</summary>
	    /// <param name="config">Module configuration.</param>
	    public void Init (ActionMediatorConfig config)
        {
	        _config = config;
	        
	        EventHandler.Instance.AddCallback("BlockIP", BlockIP);
	        EventHandler.Instance.AddCallback("ChangeGalleryGame", ChangeGalleryGame);
	        EventHandler.Instance.AddCallback("ClearNVs", ClearNVs);
	        EventHandler.Instance.AddCallback("Click", Click);
	        EventHandler.Instance.AddCallback("FixMD5", FixMD5);
	        EventHandler.Instance.AddCallback("ForceBalls", ForceBalls);
	        EventHandler.Instance.AddCallback("ForceCards", ForceCards);
	        EventHandler.Instance.AddCallback("PressKey", PressKey);
	        EventHandler.Instance.AddCallback("Reboot", Reboot);
	        EventHandler.Instance.AddCallback("RestartGame", RestartGame);
	        EventHandler.Instance.AddCallback("SetVLT", SetVLT);
	        EventHandler.Instance.AddCallback("TakeScreenshot", TakeScreenshot);
	        EventHandler.Instance.AddCallback("UnblockIP", UnblockIP);
	        EventHandler.Instance.AddCallback("PressButton", PressButton);
	        EventHandler.Instance.AddCallback("StartAFTCashIn", StartAFTCashIn);
	        EventHandler.Instance.AddCallback("StartAFTCashOut", StartAFTCashOut);
	        EventHandler.Instance.AddCallback("SendSASLP", SendSASLP);
	        EventHandler.Instance.AddCallback("SendSASByteArray", SendSASByteArray);
	        EventHandler.Instance.AddCallback("GetSASMeter", GetSASMeter);
	        EventHandler.Instance.AddCallback("RemoteResetHandpay", RemoteResetHandpay);
	        
	        loadButtonsMap();
        }
	    
	    /// <summary>Terminates the Action Mediator module.</summary>
	    public void Terminate ()
	    {
		    _buttonsMap = null;
		    EventHandler.Instance.RemoveCallback("BlockIP", BlockIP);
		    EventHandler.Instance.RemoveCallback("ChangeGalleryGame", ChangeGalleryGame);
		    EventHandler.Instance.RemoveCallback("ClearNVs", ClearNVs);
		    EventHandler.Instance.RemoveCallback("Click", Click);
		    EventHandler.Instance.RemoveCallback("FixMD5", FixMD5);
		    EventHandler.Instance.RemoveCallback("ForceBalls", ForceBalls);
		    EventHandler.Instance.RemoveCallback("ForceCards", ForceCards);
		    EventHandler.Instance.RemoveCallback("PressKey", PressKey);
		    EventHandler.Instance.RemoveCallback("Reboot", Reboot);
		    EventHandler.Instance.RemoveCallback("RestartGame", RestartGame);
		    EventHandler.Instance.RemoveCallback("SetVLT", SetVLT);
		    EventHandler.Instance.RemoveCallback("TakeScreenshot", TakeScreenshot);
		    EventHandler.Instance.RemoveCallback("UnblockIP", UnblockIP);
		    EventHandler.Instance.RemoveCallback("PressButton", PressButton);
		    EventHandler.Instance.RemoveCallback("StartAFTCashIn", StartAFTCashIn);
		    EventHandler.Instance.RemoveCallback("StartAFTCashOut", StartAFTCashOut);
		    EventHandler.Instance.RemoveCallback("SendSASLP", SendSASLP);
		    EventHandler.Instance.RemoveCallback("SendSASByteArray", SendSASByteArray);
		    EventHandler.Instance.RemoveCallback("GetSASMeter", GetSASMeter);
		    EventHandler.Instance.RemoveCallback("RemoteResetHandpay", RemoteResetHandpay);
	    }
	    
	    /// <summary>Load buttons Mapping (with button name and keyboard key to press) into a dictionary.</summary>
	    private void loadButtonsMap ()
	    {
		    string buttonsMapFile;
			
		    switch (_config.LogType)
		    {
			    case LogType.Bingo:
				    buttonsMapFile = ATNames.Instance.ButtonsBingo;
				    break;
			    case LogType.Slots:
				    buttonsMapFile = ATNames.Instance.ButtonsSlots;
				    break;
			    default:
				    return;
		    }

		    if (!File.Exists(buttonsMapFile))
		    {
			    string newButtonsMapPath = Directory.GetCurrentDirectory().Split(new string[] {"AutoTesting"}, StringSplitOptions.None)[0] + "AutoTesting/AuSy/" + buttonsMapFile;
			    if (File.Exists(newButtonsMapPath))
				    buttonsMapFile = newButtonsMapPath;
			    else
			    {
				    Logger.Instance.UpdateLog("The file " + buttonsMapFile + " doesn't exist. The scripting function PressButton() won't work.", LoggerType.Warning);
				    return;
			    }
		    }
			
		    try
		    {
			    using (StreamReader fs = new StreamReader (buttonsMapFile))
			    {
				    var buttonsMapAux = JsonConvert.DeserializeObject<Dictionary<string, string>> (fs.ReadToEnd ());
				    _buttonsMap = new Dictionary<string, string>(buttonsMapAux, StringComparer.OrdinalIgnoreCase);
			    }
		    }
		    catch (Exception ex)
		    {
			    Logger.Instance.UpdateLog ("Failed to load " + buttonsMapFile + " file: " + ex.Message, LoggerType.Warning);
		    }
	    }
        
        #endregion

        #region Individual action routines

        /// <summary>Attempts to run the commands to block an IP.</summary>
		public void BlockIP (string ip, EventInfo? _)
		{
			try
			{
				Logger.Instance.UpdateLog ("BlockIP", LoggerType.Info, true);
				System.Diagnostics.Process.Start (new ProcessStartInfo () { FileName = "sudo", Arguments = "iptables -I OUTPUT -d " + ip + " -j DROP" });
			}
			catch (Exception ex)
			{
				Logger.Instance.UpdateLog ("BlockIP failed. Exception caught:\n" + ex.Message, LoggerType.Error);
			}
		}

		/// <summary>Goes to the multi-game gallery and picks the chosen game.</summary>
		public void ChangeGalleryGame (string galleryGameNumber, EventInfo? _)
		{
			Logger.Instance.UpdateLog ("ChangeGame", LoggerType.Info, true);
			PressKey ("F2 1", null);
			Thread.Sleep (1000);    // Wait 1 second for gallery to open.
			int x, y;
			switch (int.Parse(galleryGameNumber))
			{
			case 1:
				x = 470;
				y = 1280;
				break;
			case 2:
				x = 1196;
				y = 1280;
				break;
			case 3:
				x = 470;
				y = 1700;
				break;
			default:
				x = 1196;
				y = 1700;
				break;
			}
			Click (x + " " + y, null);
		}

		/// <summary>Attempts to run the commands to clear the NV files.</summary>
		public void ClearNVs (string _, EventInfo? __)
		{
			Logger.Instance.UpdateLog ("ClearNVs", LoggerType.Info, true);
			
			RunCommand shell = new RunCommand ();

			try
			{
				shell.RunExeCommand ("restart-admin", "", false);
				Thread.Sleep (1000);    // Wait 1 second for game to close
			}
			catch (Exception ex)
			{
				Logger.Instance.UpdateLog ("ClearNVs game shutdown failed. Exception caught:\n" + ex.Message, LoggerType.Error);
			}

			try
			{
				shell.RunExeCommand ("find", "\"" + _config.GamePath + "\" -type f -name *.nv* -delete", false);
				shell.RunExeCommand ("find", "\"" + _config.LogsPath + "\" -type f -name *.nv* -delete", false);
			}
			catch (Exception ex)
			{
				Logger.Instance.UpdateLog ("ClearNVs NV deletion failed. Exception caught:\n" + ex.Message, LoggerType.Error);
			}

			try
			{
				shell.RunExeCommand ("restart-game", "", false);
			}
			catch (Exception ex)
			{
				Logger.Instance.UpdateLog ("ClearNVs game restart failed. Exception caught:\n" + ex.Message, LoggerType.Error);
			}
		}

		/// <summary>Forces a mouse click on the specified coordinates.</summary>
		/// <returns><c>true</c>, if click was successful, <c>false</c> otherwise.</returns>
		/// <param name="coords">Coordinates, separated by space.</param>
		public void Click (string coords, EventInfo? _)
		{
			int x = int.Parse(coords.Split(' ')[0]);
			int y = int.Parse(coords.Split(' ')[1]);
			try
			{
				if (_config.ApplicationDebugLevel > 0)
				{
					Logger.Instance.UpdateLog ("ForceClick: " + x + ", " + y, LoggerType.Debug, true);
				}
				RunCommand shell = new RunCommand ();
				shell.RunExeCommand ("xdotool", String.Format ("mousemove {0} {1} click 1", x, y), false);
			}
			catch (Exception ex)
			{
				Logger.Instance.UpdateLog ("ForceClick failed. Exception caught:\n" + ex.Message, LoggerType.Error);
			}
		}
		
		/// <summary>Alters sums.md5 in the game's directory to match the edited files's MD5 hashes.</summary>
		public void FixMD5 (string _, EventInfo? __)
		{
			try
			{
				Helper.Bash(
					"cd \"" + _config.GamePath + "\"; " +
					"rm sums.md5; " +
					"find * -maxdepth 100 -type f ! \\( -path \"*/.config/*\" -o -path \"log*\" -o -iname \".gitignore\" -o -iname \"sums.md5*\" -o -iname \"*.nv*\" -o -iname \"*.7z\" \\) -exec md5sum {} >> sums.md5 \\;"
				);
			}
			catch (Exception ex)
			{
				Logger.Instance.UpdateLog ("FixMD5 failed. Exception caught:\n" + ex.Message, LoggerType.Error);
			}
		}

		/// <summary>Forces the extraction to use the specified balls, via balls.txt.</summary>
		/// <param name="balls">Balls to use, in the same format as balls.txt.</param>
		public void ForceBalls (string balls, EventInfo? _)
		{
			Logger.Instance.UpdateLog ("ForceBalls: " + balls, LoggerType.Info, true);
			try
			{
				string path = _config.GamePath + "/balls.txt";
				if (balls.Length > 0)
				{
					File.WriteAllText (path, balls);
				}
				else
				{
					if (File.Exists(path))
					{
						File.Delete(path);
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Instance.UpdateLog ("ForceBalls failed. Exception caught:\n" + ex.Message, LoggerType.Error);
			}
		}

		/// <summary>Forces the play to use the specified cards, via cards.txt.</summary>
		/// <param name="cards">Cards to use, in the same format as cards.txt.</param>
		public void ForceCards (string cards, EventInfo? _)
		{
			Logger.Instance.UpdateLog ("ForceCards: " + cards, LoggerType.Info, true);
			try
			{
				string path = _config.GamePath + "/cards.txt";
				if (cards.Length > 0)
				{
					File.WriteAllText (path, cards);
				}
				else
				{
					if (File.Exists(path))
					{
						File.Delete(path);
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Instance.UpdateLog ("ForceCards failed. Exception caught:\n" + ex.Message, LoggerType.Error);
			}
		}

		/// <summary>Presses keyboard keys.</summary>
		/// <returns><c>true</c>, if key presses were successful, <c>false</c> otherwise.</returns>
		/// <param name="keysAndTimes">String indicating the keys, and finally the number of times to press them, separated by space.</param>
		public void PressKey (string keysAndTimes, EventInfo? _)
		{
			List<string> keys = new List<string>(keysAndTimes.Split(' '));
			int times = int.Parse(keys[keys.Count - 1]);
			keys.RemoveAt(keys.Count - 1);

			try
			{
				if (_config.ApplicationDebugLevel > 0)
				{
					Logger.Instance.UpdateLog ("PressInput: " + keys + " (x" + times + ")", LoggerType.Debug, true);
				}
				for (int t = 0; t < times; t++)
				{
					for (int k = 0; k < keys.Count; k++)
					{
						RunCommand shell = new RunCommand ();
						shell.RunExeCommand ("xdotool", String.Format ("key {0}", keys[k]), true);
						Thread.Sleep (_config.InputDelay);
					}
				}
			}
			catch (Exception ex)
			{
				Logger.Instance.UpdateLog ("PressInput failed. Exception caught:\n" + ex.Message, LoggerType.Error);
			}
		}

		/// <summary>Attempts to run the Reboot command.</summary>
		public void Reboot (string _, EventInfo? __)
		{
			Logger.Instance.UpdateLog ("Reboot", LoggerType.Info, true);
			try
			{
				// Quixant 7000. Try this first since this will fail on Q200, allowing us to run the other one. The opposite is not true, though.
				System.Diagnostics.Process.Start (new ProcessStartInfo () { FileName = "sudo", Arguments = "reboot -f -d --no-wall" }).WaitForExit ();

				// Quixant 200.
				System.Diagnostics.Process.Start (new ProcessStartInfo () { FileName = "sudo", Arguments = "reboot -f -n" }).WaitForExit ();
			}
			catch (Exception ex)
			{
				Logger.Instance.UpdateLog ("Reboot failed. Exception caught:\n" + ex.Message, LoggerType.Error);
			}
		}

		/// <summary>Attempts to run the Restart Game command.</summary>
		public void RestartGame (string _, EventInfo? __)
		{
			Logger.Instance.UpdateLog ("RestartGame", LoggerType.Info, true);
			try
			{
				RunCommand shell = new RunCommand ();
				shell.RunExeCommand ("restart-game", "", false);
			}
			catch (Exception ex)
			{
				Logger.Instance.UpdateLog ("RestartGame failed. Exception caught:\n" + ex.Message, LoggerType.Error);
			}
		}

		/// <summary>Runs keyboard/mouse inputs to enter the supervisor screens, and change the VLT.</summary>
		/// <param name="vltAndPassword">Vlt and supervisor password, separated by space.</param>
		public void SetVLT (string vltAndPassword, EventInfo? _)
		{
			Logger.Instance.UpdateLog ("SetVLT", LoggerType.Info, true);
			
			string vlt = vltAndPassword.Split(' ')[0];
			string password = vltAndPassword.Split(' ')[1];
			try
			{
				// Supervisor buttons to click.
				List<string> buttons = new List<string> ();
				buttons.Add ("bt_confi");
				buttons.Add ("bt_set_g");
				foreach (Char c in password)
				{
					buttons.Add ("bt_cal_0" + c);
				}
				buttons.Add ("bt_cal_ac");
				buttons.Add ("bt_n_vlt");
				foreach (Char c in vlt)
				{
					buttons.Add ("bt_cal_0" + c);
				}
				buttons.Add ("bt_cal_ac");
				buttons.Add ("bt__exit");
				buttons.Add ("bt__exit");
				buttons.Add ("bt__exit");

				// Press some necessary keys first.
				PressKey ("l 1", null);
				PressKey ("d 1", null);

				// Then click the buttons.
				foreach (string b in buttons)
				{
					string xy = ATNames.Instance.SUPERVISOR_BUTTONS[b];
					int x = int.Parse (xy.Split ()[0]);
					int y = int.Parse (xy.Split ()[1]);
					x += 10; // So it doesn't click on the very top-left corner.
					y += 10;
					y += 1050; // Dual screen.

					Click(x + " " + y, null);
					Thread.Sleep (750);
				}

				// More necessary keys.
				PressKey("d 1", null);

				Logger.Instance.UpdateLog ("SetVLT finished successfully.", LoggerType.Debug);

			}
			catch (Exception ex)
			{
				Logger.Instance.UpdateLog ("SetVLT failed. Exception caught:\n" + ex.Message, LoggerType.Error);
			}
		}

		/// <summary>Attempts to run the commands to take a screenshot.</summary>
		public void TakeScreenshot (string cropInfo, EventInfo? _)
		{
			string x1 = cropInfo.Split(' ')[0];
			string y1 = cropInfo.Split(' ')[1];
			string x2 = cropInfo.Split(' ')[2];
			string y2 = cropInfo.Split(' ')[3];
			string fileName = cropInfo.Split(' ')[4];

			int width = Convert.ToInt32(x2) - Convert.ToInt32(x1);
			int heigth = Convert.ToInt32(y2) - Convert.ToInt32(y1);
			
			Logger.Instance.UpdateLog ("TakeScreenshot", LoggerType.Info, true);
			try
			{
				RunCommand shell = new RunCommand ();
				// Move the window to refresh the framebuffer on the window manager.
				shell.RunExeCommand ("xdotool", "getactivewindow windowmove 1 1", true);
				shell.RunExeCommand ("xdotool", "getactivewindow windowmove 0 0", true);
				if (fileName == String.Empty)
					fileName = "screenshot " +
					           DateTime.Now.ToString(AutoTestingService.Shared.ATNames.Instance.DateTimePattern) +
					           ".png";
				else
					fileName = fileName + ".png";

				if (Convert.ToInt32(x1) == 0 && Convert.ToInt32(y1) == 0 && Convert.ToInt32(x2) == 0 &&
				    Convert.ToInt32(y2) == 0)
				{
					shell.RunExeCommand ("import", "-window root \"/storage/ausy/" + fileName + "\"", false);
				}
				else
				{
					shell.RunExeCommand ("import", "-window root " + "-crop " + width + "x" + heigth + "+" + x1 + "+" + y1 + " \"/storage/ausy/" + fileName + "\"", false);
				}
					
			}
			catch (Exception ex)
			{
				Logger.Instance.UpdateLog ("TakeScreenshot failed. Exception caught:\n" + ex.Message, LoggerType.Error);
			}
		}

		/// <summary>Attempts to run the commands to unblock an IP.</summary>
		public void UnblockIP (string ip, EventInfo? _)
		{
			try
			{
				System.Diagnostics.Process.Start (new ProcessStartInfo () { FileName = "sudo", Arguments = "iptables -D OUTPUT -d " + ip + " -j DROP" });
			}
			catch (Exception ex)
			{
				Logger.Instance.UpdateLog ("UnblockIP failed. Exception caught:\n" + ex.Message, LoggerType.Error);
			}
		}

		/// <summary>Presses the specified button. Each button name is associated with the respective keyboard key that is pressed.</summary>
		public void PressButton (string button, EventInfo? _)
		{
			try
			{

				if (_buttonsMap.ContainsKey(button))
				{
					PressKey(_buttonsMap[button] + " 1", null);
				}
				else
				{
					string message = "Failed to execute PressButton('" + button + "'): the argument '" + button + "' is not recognized as a button (e.g. play, handpay...)";
					Logger.Instance.UpdateLog(message, LoggerType.Error);
					EventDistributor.Instance.Trigger("DoJsPrint", message);
				}
			}
			catch (Exception ex)
			{
				Logger.Instance.UpdateLog ("PressButton failed. Exception caught:\n" + ex.Message, LoggerType.Error);
			}
		}

		/// <summary>Sends a StartAFTCashIn message to the SasHost.</summary>
		public void StartAFTCashIn (string cashInInfoJson, EventInfo? _)
		{
			try
			{
				IDictionary<string, object> fullMsg = new Dictionary<string, object>();
				fullMsg.Add("message", "StartAFTCashIn");
				fullMsg.Add("data", JsonConvert.DeserializeObject(cashInInfoJson));
				EventHandler.Instance.Trigger("SendSasMessage", JsonConvert.SerializeObject(fullMsg));
			}
			catch (Exception ex)
			{
				Logger.Instance.UpdateLog ("StartAFTCashIn failed. Exception caught:\n" + ex, LoggerType.Error);
			}
		}
		
		/// <summary>Sends a StartAFTCashIn message to the SasHost.</summary>
		public void StartAFTCashOut (string _, EventInfo? __)
		{
			try
			{
				IDictionary<string, object> fullMsg = new Dictionary<string, object>();
				fullMsg.Add("message", "StartAFTCashOut");
				fullMsg.Add("data", "");
				EventHandler.Instance.Trigger("SendSasMessage", JsonConvert.SerializeObject(fullMsg));
			}
			catch (Exception ex)
			{
				Logger.Instance.UpdateLog ("StartAFTCashOut failed. Exception caught:\n" + ex.Message, LoggerType.Error);
			}
		}
		
		/// <summary>Sends a SendSASLP message to the SasHost.</summary>
		public void SendSASLP (string lpInfoJson, EventInfo? _)
		{
			try
			{
				IDictionary<string, object> fullMsg = new Dictionary<string, object>();
				fullMsg.Add("message", "SendSASLP");
				fullMsg.Add("data", JsonConvert.DeserializeObject(lpInfoJson));
				EventHandler.Instance.Trigger("SendSasMessage", JsonConvert.SerializeObject(fullMsg));
			}
			catch (Exception ex)
			{
				Logger.Instance.UpdateLog ("SendSASLP failed. Exception caught:\n" + ex.Message, LoggerType.Error);
			}
		}
		
		/// <summary>Sends a bytearray to the SasHost to be processed.</summary>
		public void SendSASByteArray (string bytesJson, EventInfo? _)
		{
			try
			{
				IDictionary<string, object> fullMsg = new Dictionary<string, object>();
				fullMsg.Add("message", "SendSASByteArray");
				fullMsg.Add("data", JsonConvert.DeserializeObject(bytesJson));
				EventHandler.Instance.Trigger("SendSasMessage", JsonConvert.SerializeObject(fullMsg));
			}
			catch (Exception ex)
			{
				Logger.Instance.UpdateLog ("SendSASByteArray failed. Exception caught:\n" + ex.Message, LoggerType.Error);
			}
		}
		
		/// <summary>Asks for the information of a specific sas meter.</summary>
		public void GetSASMeter (string meterInfoJson, EventInfo? _)
		{
			try
			{
				IDictionary<string, object> fullMsg = new Dictionary<string, object>();
				fullMsg.Add("message", "GetSASMeter");
				fullMsg.Add("data", JsonConvert.DeserializeObject(meterInfoJson));
				EventHandler.Instance.Trigger("SendSasMessage", JsonConvert.SerializeObject(fullMsg));
			}
			catch (Exception ex)
			{
				Logger.Instance.UpdateLog ("GetSASMeter failed. Exception caught:\n" + ex.Message, LoggerType.Error);
			}
		}
		
		/// <summary>Sends the remote request to the SAS host in order to perform a remote handpay reset.</summary>
		public void RemoteResetHandpay (string Message, EventInfo? _)
		{
			try
			{
				IDictionary<string, object> fullMsg = new Dictionary<string, object>();
				fullMsg.Add("message", "RemoteResetHandpay");
				EventHandler.Instance.Trigger("SendSasMessage", JsonConvert.SerializeObject(fullMsg));
			}
			catch (Exception ex)
			{
				Logger.Instance.UpdateLog ("RemoteResetHandpay failed. Exception caught:\n" + ex.Message, LoggerType.Error);
			}
		}
        #endregion
        
    }

    /// <summary>Configuration about how the Action Mediator should work.</summary>
    public struct ActionMediatorConfig
    {
	    /// <summary>Path the game folder.</summary>
	    public string GamePath;
	    /// <summary>Path to the game logs folder.</summary>
	    public string LogsPath;
	    /// <summary>Type of game logs.</summary>
	    public LogType LogType;
	    /// <summary>Delay between inputs.</summary>
	    public int InputDelay;
	    /// <summary>The application's debug level.</summary>
	    public int ApplicationDebugLevel;
    }
}