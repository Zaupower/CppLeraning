using System;
using System.Collections.Generic;
using System.Threading;
using AutoTestingService;
using AutoTestingService.Logging;
using AutoTestingService.Shared;
using Newtonsoft.Json;
using EventHandler = AutoTestingService.EventHandler;

namespace AuSy.Modules.Scripter
{
    /// <summary>Responsible for running JS scripts.</summary>
    public class Scripter
    {
        #region Singleton

        public static Scripter Instance { get; } = new Scripter ();

        private Scripter ()
        {
        }

        #endregion

        #region Members
        
        public JsEngineWrapper jsEngineWrapper;

        /// <summary>Standalone Mode (true if standalone mode, false if distributed mode)</summary>
        private bool _isStandalone;
        
        /// <summary>Path to game folder.</summary>
        private string _gamePath;

        /// <summary>Script to run when the scripter starts.</summary>
        private string _startupScript;
        
        /// <summary>Signal to raise when event/timer processing is needed.</summary>
        private AutoResetEvent _processingSignal;

        /// <summary>Stores the current machine.</summary>
        private Machine _currentMachine;
        
        /// <summary>Flag that indicates that the Module processing should stop.</summary>
        private bool _stop = false;
        
        private ManualResetEvent _stopSignal = new ManualResetEvent(false);

        private Thread _timerElapsedThread;

        #endregion

        #region Init and Terminate

        public void Init(bool isStandaloneMode, string gamePath, string startupScript, ManualResetEvent stopSignal)
        {
            _stopSignal = stopSignal;
            _processingSignal = new AutoResetEvent (false);
            _isStandalone = isStandaloneMode;
            _gamePath = gamePath;
            _startupScript = startupScript;
            
            // TODO adicionar função de JSOutput ??
            jsEngineWrapper = new JsEngineWrapper(JSOutput, EngineResetCallback, SetCurrentMachine, _processingSignal);

            EventHandler.Instance.SetJsEventHandler(jsEngineWrapper);
        
            EventHandler.Instance.AddCallback("DoJsPrint", jsEngineWrapper.DoJsPrint);
            EventHandler.Instance.AddCallback("GotGameEvent", HandleGameEvent);
            EventHandler.Instance.AddCallback("RunJs", jsEngineWrapper.ExecuteJSWrapper);
            EventHandler.Instance.AddCallback("RunJsFile", jsEngineWrapper.ExecuteJsFileWrapper);
            EventHandler.Instance.AddCallback("ResetJsEngine", jsEngineWrapper.ResetEngineWrapper);
            EventHandler.Instance.AddCallback("SetAltIncludesFolder", jsEngineWrapper.SetAltIncludesFolderWrapper);
            EventHandler.Instance.AddCallback("JsOutput", jsEngineWrapper.JsOutputWrapper);
            EventHandler.Instance.AddCallback("SetJsLogFileLocation", jsEngineWrapper.SetLogFileLocation);
            
            EventHandler.Instance.AddCallback("StartAusy", jsEngineWrapper.ResetEngineWrapper);
            
            EventHandler.Instance.AddCallback("StartAusy", StartTimerElapsedThread);
            
            EventHandler.Instance.AddCallback("StartAusy", RunStartupScript);
        }

        public void Terminate()
        {
            _timerElapsedThread.Join();
            EventHandler.Instance.RemoveCallback("DoJsPrint", jsEngineWrapper.DoJsPrint);
            EventHandler.Instance.RemoveCallback("GotGameEvent", HandleGameEvent);
            EventHandler.Instance.RemoveCallback("RunJs", jsEngineWrapper.ExecuteJSWrapper);
            EventHandler.Instance.RemoveCallback("RunJsFile", jsEngineWrapper.ExecuteJsFileWrapper);
            EventHandler.Instance.RemoveCallback("ResetJsEngine", jsEngineWrapper.ResetEngineWrapper);
            EventHandler.Instance.RemoveCallback("SetAltIncludesFolder", jsEngineWrapper.SetAltIncludesFolderWrapper);
            EventHandler.Instance.RemoveCallback("JsOutput", jsEngineWrapper.JsOutputWrapper);
            EventHandler.Instance.RemoveCallback("SetJsLogFileLocation", jsEngineWrapper.SetLogFileLocation);
            EventHandler.Instance.RemoveCallback("StartAusy", jsEngineWrapper.ResetEngineWrapper);
            EventHandler.Instance.RemoveCallback("StartAusy", StartTimerElapsedThread);
            EventHandler.Instance.RemoveCallback("StartAusy", RunStartupScript);
            _isStandalone = false;
            _gamePath = null;
            jsEngineWrapper = null;
            _processingSignal = null;
            _currentMachine = null;
        }

        #endregion

        #region Thread Process Loop

        private void StartTimerElapsedThread(string _, EventInfo? __)
        {
            _timerElapsedThread = new Thread(ProcessLoop)
            {
                Name = "Scripter Thread"
            };
            _timerElapsedThread.Start();
        }

        /// <summary>Thread code that processes elapsed scripting timers.</summary>
        private void ProcessLoop()
        {
            while (!_stop)
            {
                int signalIndex = WaitHandle.WaitAny(new WaitHandle[] {_processingSignal, _stopSignal});
                
                switch (signalIndex)
                {
                    case 0:
                        jsEngineWrapper.ExecuteElapsedTimers();
                        jsEngineWrapper.ExecuteQueuedGameEvents();
                        break;
                    case 1:
                        _stop = true;
                        break;
                }
            }
        }

        #endregion

        #region Game event handling

        /// <summary>Callback for handling a game event.</summary>
        /// <param name="dataJson">Event JSON data.</param>
        /// <param name="_"></param>
        private void HandleGameEvent(string dataJson, EventInfo? _)
        {
            jsEngineWrapper.QueueGameEvent(dataJson);
        }

        #endregion

        #region Functions
        
        private void RunStartupScript(string _, EventInfo? __)
        {
            if (!String.IsNullOrEmpty(_startupScript))
            {
                EventHandler.Instance.Trigger("ResetJsEngine", "");
                EventHandler.Instance.Trigger("RunJsFile", _startupScript);
            }
        }

        public void SetCurrentMachine(Machine m)
        {
            if (jsEngineWrapper.JSEngine == null)
            {
                jsEngineWrapper.ResetEngine();
            }
            _currentMachine = m;
            jsEngineWrapper.JSEngine.SetValue ("machine", m.GamePlay);
        }
        
        public void SetCurrentMachine(int id)
        {
            Machine m = MachineManager.MachineManager.Instance.GetMachine(id);
            if(m != null) SetCurrentMachine(m);
        }
        
        /// <summary>Callback for when the scripter's JS engine is reset.</summary>
        private void EngineResetCallback (JsEngineWrapper jsEngineWrapper)
        {
            // TODO Decidir o que fazer com a função "installClient" que está comentada e era usada para Ausy Coordinator no modo distribuido 1.0
            // TODO Usar objetos machine e getMachines em JS para ambos os modos: standalone e distribuido??
            // Ausy operator (standalone)
            if (_currentMachine != null)
            {
                jsEngineWrapper.JSEngine.SetValue ("machine", _currentMachine.GamePlay);
            }
            jsEngineWrapper.JSEngine.SetValue ("getMachines", new Func<Dictionary<int, GameplayInfo>> (MachineManager.MachineManager.Instance.GetMachinesForJsEngine));
            jsEngineWrapper.JSEngine.SetValue ("includeFromGameFolder", new Action<string>(IncludeJSFileFromGameFolder));
            
            // Ausy Coordinator
            //scripter.JSEngine.SetValue ("getMachines", new Func<Dictionary<int, GameplayInfo>> (getMachinesForJSEngine));
            //scripter.JSEngine.SetValue ("installClient", new Action<string, string> (machineCommander.InstallAutoClient));
            //scripter.JSEngine.SetValue ("includeFromGameFolder", new Action<string>(IncludeJSFileFromGameFolder));
        }
        
        /// <summary>Includes a JavaScript file located in the game's "ausy_scripts" folder onto the currently running script.</summary>
        /// <param name="fileName">File name.</param>
        private void IncludeJSFileFromGameFolder (string fileName)
        {
            if (!_isStandalone)
            {
                // TODO Imprimir este log para JS também (pensar como serão logs de JS em modo standalone e distribuido)
                Logger.Instance.UpdateLog("Warning: includeFromGameFolder is not supported in distributed mode.", LoggerType.Warning);
                return;
            }
            string fullFilePath = _gamePath + "/" +
                                  ATNames.Instance.FolderGameFolderScripts + "/" + fileName;
            if (!jsEngineWrapper.ExecuteJsFile(fullFilePath, true))
            {
                // TODO Imprimir este log para JS também (pensar como serão logs de JS em modo standalone e distribuido)
                Logger.Instance.UpdateLog("Warning: failed to include file \"" + fullFilePath + "\" in game folder.", LoggerType.Warning);
            }
        }
        
        /// <summary>Write some output from the scripter.</summary>
        /// <param name="o">Text to write.</param>
        public void JSOutput (Object o)
        {
            string m = "[JS]" + " " + o;

            if (Communication.Communication.Instance.gui.remoteScriptingOutputActive)
            {
                try
                {
                    EventHandler.Instance.Trigger ("SendGuiMessage", "JSOutput;" + m);
                }
                catch (Exception)
                {
                    Console.WriteLine ("Failed to send JS output to remote scripter.");
                }
            }
            else
            {
                Console.WriteLine (m);
            }
        }

        #endregion
    }
}