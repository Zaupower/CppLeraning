using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading;
using AutoTestingService;
using AutoTestingService.Logging;
using AutoTestingService.Shared;
using Jint.Runtime;
using Newtonsoft.Json;
using EventHandler = AutoTestingService.EventHandler;

namespace AuSy.Modules.Scripter
{
    public class JsEngineWrapper : IJsEventHandler
    {
        public const string ScriptsFolder = "scripts";

		public delegate void JSOutputFunction (string o);
		public delegate void SetMachineCallbackDelegate (int id);
		public delegate void ResetCallbackDelegate (JsEngineWrapper jsEngineWrapper);

		/// <summary>Is a script currently running?</summary>
		public bool running { get; private set; } = false;
		
		/// <summary>Name of the file whose code is being run, if any.</summary>
		public string runningFileName { get; private set; }

		/// <summary>Context of the code currently being run.</summary>
		private string _runningContext = "";

		/// <summary>This machine's JavaScript engine.</summary>
		public Jint.Engine JSEngine;

		/// <summary>Test controller.</summary>
		public JsTestController testController;

		/// <summary>Alternative folder to search for includes in.</summary>
		public string altIncludesFolder;

		/// <summary>Random Number Generator.</summary>
		private Random _rng = new Random ();

		/// <summary>List of currently active JavaScript timers.</summary>
		private Dictionary<string, System.Timers.Timer> _jsTimers = new Dictionary<string, System.Timers.Timer> ();

		/// <summary>Mutex for the JavaScript engine.</summary>
		private Mutex _jsEngineMutex = new Mutex ();

		/// <summary>Function to run when outputting in JavaScript.</summary>
		public JSOutputFunction JsOutput = new JSOutputFunction (Console.WriteLine);

		/// <summary>Code to run when the JS engine requests the "machine" variable be updated.</summary>
		public SetMachineCallbackDelegate SetMachineCallback;

		/// <summary>Code to run when the JS engine is reset.</summary>
		public ResetCallbackDelegate ResetCallback;

		/// <summary>Signal to raise when there are events/timers that need to be handled.</summary>
		private AutoResetEvent _processingSignal;

		/// <summary>Game events queued to be processed.</summary>
		private List<string> _queuedGameEvents = new List<string>();

		/// <summary>List of timers that have elapsed, and whose code is ready to be executed.
		/// Format is name, code, machine index.</summary>
		private List<Tuple<string, string, int>> elapsedTimers = new List<Tuple<string, string, int>> ();

		public string logFileLocation = "";


		/// <summary>Initializes a new instance of the JsEngineWrapper class.</summary>
		/// <param name="JSOutputCode">Code to run when printing output. If null, prints to Console.WriteLine.</param>
		/// <param name="ResetCallback">Code to run when the JS engine is reset.</param>
		/// <param name="SetMachineCallback">Code to run when the JS engine requests the "machine" variable be updated.</param>
		/// <param name="timerElapsedSignal">Signal to raise when a timer has elapsed.</param>
		public JsEngineWrapper (JSOutputFunction JSOutputCode = null, ResetCallbackDelegate ResetCallback = null, SetMachineCallbackDelegate SetMachineCallback = null, AutoResetEvent timerElapsedSignal = null)
		{
			if (JSOutputCode != null)
			{
				JsOutput = JSOutputCode;
			}

			JsOutput += (o) => { LogJSOutput (o); };

			Directory.CreateDirectory (ATNames.Instance.FolderScriptLogs);

			if (ResetCallback != null)
			{
				this.ResetCallback = ResetCallback;
			}
			if (SetMachineCallback != null)
			{
				this.SetMachineCallback = SetMachineCallback;
			}

			if (timerElapsedSignal != null)
			{
				_processingSignal = timerElapsedSignal;
			}

			testController = new JsTestController();
			
			EventHandler.Instance.AddCallback("RemoveJSTimer", (s, e) => RemoveJsTimerCallback(s));
			
			EventHandler.Instance.AddCallback("CreateJSTimer", (s, e) => CreateJsTimerCallback(s));
		}


		/// <summary>Invokes a game event's callback into the JavaScript engine.</summary>
		/// <param name="eventCallback">Code to run.</param>
		/// <param name="eventParams">Event parameters.</param>
		public void InvokeGameEvent (Jint.Native.JsValue eventCallback, Jint.Native.JsValue[] eventParams)
		{
			try
			{
				eventCallback.Invoke (eventParams);
			}
			catch (Exception ex)
			{
				printException(ex);
			}
		}

		public void ExecuteJSWrapper(string code, EventInfo? _)
		{
			ExecuteJS(code);
		}

		/// <summary>Executes JavaScript code with the context of a specific JavaScript engine.</summary>
		/// <returns><c>true</c>, if the code was executed successfully, <c>false</c> otherwise.</returns>
		/// <param name="code">Code to run.</param>
		public bool ExecuteJS (string code)
		{
			try
			{
				JSEngine.Execute (code);
				running = true;
				return true;
			}
			catch (Exception ex)
			{
				printException(ex);
			}
			running = false;
			return false;
		}


		/// <summary>Returns when a script file was last modified.</summary>
		/// <returns>The script modify date, or null if the file does not exist.</returns>
		/// <param name="fileName">File name.</param>
		public DateTime? GetScriptModifyDate (string fileName)
		{
			if (!fileName.EndsWith (".js"))
			{
				fileName += ".js";
			}
			fileName = ScriptsFolder + "/" + fileName;

			if (!File.Exists (fileName))
			{
				return null;
			}

			return File.GetLastWriteTime (fileName);
		}

		public void ExecuteJsFileWrapper(string fileName, EventInfo? _)
		{
			ExecuteJsFile(fileName, false);
		}
		
		/// <summary>Reads a file and executes the code inside.</summary>
		/// <returns><c>true</c>, if the code in the file was executed, <c>false</c> otherwise.</returns>
		/// <param name="fileName">File name.</param>
		/// <param name="asInclude">If true, the file is run as an inclusion to a script that is already running.</param>
		public bool ExecuteJsFile (string fileName, bool asInclude)
		{
			if (!fileName.EndsWith (".js"))
			{
				fileName += ".js";
			}

			if (!fileName.StartsWith("/"))
			{
				fileName = ScriptsFolder + "/" + fileName;
			}

			if (!File.Exists (fileName))
			{
				return false;
			}

			using (StreamReader file = new StreamReader (fileName))
			{
				string oldRunningContext = _runningContext;
				if (asInclude)
				{
					_runningContext = "included file \"" + fileName + "\"";
				}
				else
				{
					runningFileName = fileName;
				}

				bool result = ExecuteJS (file.ReadToEnd ());
				_runningContext = oldRunningContext;
				
				return result;
			}
		}


		/// <summary>Includes a JavaScript file onto the currently running script.</summary>
		/// <param name="fileName">File name.</param>
		public void IncludeJSFile (string fileName)
		{
			if (altIncludesFolder != "" && ExecuteJsFile(altIncludesFolder + "/" + fileName, true))
			{
				return;
			}

			if (ExecuteJsFile(fileName, true))
			{
				return;
			}

			JsOutput("Warning: failed to include file \"" + fileName + "\".");
		}


		/// <summary>Logs the output of the JS engine into a log file.</summary>
		/// <param name="o">Text to output.</param>
		public void LogJSOutput (object o)
		{
			string filePath = logFileLocation + ATNames.Instance.FolderScriptLogs + "/" + DateTime.Now.ToString ("yyyy-MM-dd") + ".txt";
			StreamWriter file = File.AppendText (filePath);
			file.WriteLine ("[" + DateTime.Now.ToString ("HH:mm:ss") + "] " + o);
			file.Close ();
		}

		/// <summary>Waits for the JS engine mutex.</summary>
		private void jsMutexWait()
		{
			_jsEngineMutex.WaitOne();
		}

		/// <summary>Releases the JS engine mutex.</summary>
		private void jsMutexRelease()
		{
			_jsEngineMutex.ReleaseMutex ();
		}


		/// <summary>Creates a new JavaScript timer.</summary>
		/// <returns><c>true</c>, if the timer was created, <c>false</c> otherwise.</returns>
		/// <param name="name">Name of the new timer.</param>
		/// <param name="milliseconds">How long the new timer lasts for, in milliseconds.</param>
		/// <param name="code">String representing the JavaScript code to run when the timer hits.</param>
		/// <param name="machineIdx">Index of the machine that registered this timer. -1 for none.</param>
		/// <param name="repeats">If set to <c>true</c> this timer repeats when it reaches 0.</param>
		public bool CreateJSTimer (string name, int milliseconds, string code, int machineIdx, bool repeats)
		{
			if (name == null || milliseconds == 0 || code == null)
			{
				return false;
			}
			string key = name + machineIdx;
			System.Timers.Timer timer = new System.Timers.Timer (milliseconds);
			timer.Elapsed += (sender, e) =>
			{
				try
				{
					jsMutexWait ();
					elapsedTimers.Add (Tuple.Create (name, code, machineIdx));
					_processingSignal.Set ();
					jsMutexRelease ();
				}
				catch (Exception ex)
				{
					printException(ex);
				}
				
				if (!repeats)
				{
					RemoveJSTimer (name, machineIdx);
				}
			};
			timer.AutoReset = repeats;
			timer.Enabled = true;

			jsMutexWait ();
			if (_jsTimers.ContainsKey (key))
			{
				_jsTimers[key].Stop ();
				_jsTimers[key].Dispose ();
				_jsTimers.Remove (key);
			}
			_jsTimers[key] = timer;
			jsMutexRelease ();
			return true;
		}
		
		/// <summary>CreateJSTimer callback (for EventHandler).</summary>
		/// <param name="timerJson">Json with timer name (string), miliseconds (int), code (string), machineId (int) and repeat (bool).</param>
		public void CreateJsTimerCallback(string timerJson)
		{
			Tuple<string, int, string, int, bool> timerDict = JsonConvert.DeserializeObject<Tuple<string, int, string, int, bool>>(timerJson);
			CreateJSTimer(timerDict.Item1, timerDict.Item2, timerDict.Item3, timerDict.Item4, timerDict.Item5);
		}

		/// <summary>Removes an existing JavaScript timer.</summary>
		/// <returns><c>true</c>, if the timer was removed, <c>false</c> otherwise.</returns>
		/// <param name="name">Name of the timer to remove.</param>
		/// <param name="machineIdx">Index of the machine that registered this timer. -1 for none.</param>
		public bool RemoveJSTimer (string name, int machineIdx)
		{
			string key = name + machineIdx;
			jsMutexWait ();
			if (_jsTimers.ContainsKey (key))
			{
				_jsTimers[key].Stop ();
				_jsTimers[key].Dispose ();
				_jsTimers.Remove (key);
			}
			jsMutexRelease ();
			return true;
		}

		/// <summary>RemoveJSTimer callback (for EventHandler).</summary>
		/// <param name="jsonTimer">Json with timer name and machineIdx</param>
		private void RemoveJsTimerCallback(string timerJson)
		{
			Tuple<string, int> timerDict = JsonConvert.DeserializeObject<Tuple<string, int>>(timerJson);
			RemoveJSTimer(timerDict.Item1, timerDict.Item2);
		}

		/// <summary>Adds a game event to the queue, so it can be processed later.</summary>
		/// <param name="dataJson">JSON with the event's data.</param>
		public void QueueGameEvent(string dataJson)
		{
			jsMutexWait();
			_queuedGameEvents.Add(dataJson);
			_processingSignal.Set ();
			jsMutexRelease();
		}
		
		/// <summary>Executes the processing of all queued game events, if any.</summary>
		public void ExecuteQueuedGameEvents()
		{
			jsMutexWait();
			foreach (string evJson in _queuedGameEvents)
			{
				GameEvent ev = JsonConvert.DeserializeObject<GameEvent>(evJson);
				
				Machine m = MachineManager.MachineManager.Instance.GetMachine(ev.ip);
				if (m == null)
				{
					Logger.Instance.UpdateLog(
						"Tried to handle game event from an unknown machine with the IP \"" + ev.ip + "\"!",
						LoggerType.Warning);
					continue;
				}
				Scripter.Instance.SetCurrentMachine(m);
				
				//Send it to the Event Handler, since it has the logic to manage and run JS callbacks.
				EventHandler.Instance.TriggerForJs(ev.name, ev.parameters, ev.types);
			}
			_queuedGameEvents.Clear();
			jsMutexRelease();
		}

		/// <summary>Executes the code of all timers that have elapsed, if any.</summary>
		public void ExecuteElapsedTimers ()
		{
			jsMutexWait ();
			foreach (Tuple<string, string, int> t in elapsedTimers)
			{
				//ATS-223
				if (elapsedTimers.Count >= 3)
				{
					Logger.Instance.UpdateLog ("JS timer warning: More than 3 timers have elapsed at once.", LoggerType.Warning, true);
				}

				string oldRunningContext = _runningContext;
				try
				{
					_runningContext = "timer \"" + t.Item1 + "\"";
					JSEngine.Execute(t.Item2);
				}
				catch (Exception ex)
				{
					printException(ex);
				}
				finally
				{
					_runningContext = oldRunningContext;
				}
			}
			elapsedTimers.Clear ();
			jsMutexRelease ();
		}

		public void ResetEngineWrapper(string _, EventInfo? __)
		{
			ResetEngine();
		}
		
		/// <summary>Resets the JavaScript engine.</summary>
		public void ResetEngine ()
		{
			if (running)
			{
				Logger.Instance.UpdateLog ("JS script warning: There was a script running when the JS engine was reset.", LoggerType.Warning, true);
			}
			running = false;
			runningFileName = "";
			altIncludesFolder = "";
			
			JSEngine = new Jint.Engine ();

			JSEngine.SetValue ("events", new JSEventHandlerWrapper (EventHandler.Instance));
			JSEngine.SetValue ("tests", testController);

			JSEngine.SetValue ("print", new Action<string, EventInfo?> (DoJsPrint));
			JSEngine.SetValue ("restartCashcode", new Action<string> ((obj) => EventHandler.Instance.Trigger("RestartCashcode", obj)));
			JSEngine.SetValue ("include", new Action<string> (IncludeJSFile));
			JSEngine.SetValue ("random", new Func<Double> (_rng.NextDouble));
			JSEngine.SetValue ("setTimeout", new Func<string, int, string, bool> (
				(name, milliseconds, code) => { return CreateJSTimer (name, milliseconds, code, -1, false); }));
			JSEngine.SetValue ("setInterval", new Func<string, int, string, bool> (
				(name, milliseconds, code) => { return CreateJSTimer (name, milliseconds, code, -1, true); }));
			JSEngine.SetValue ("removeTimer", new Func<string, bool> (
				(name) => { return RemoveJSTimer (name, -1); }));
			JSEngine.SetValue ("SendEMU", new Action<string> ((obj) => EventHandler.Instance.Trigger("Send", obj)));
			JSEngine.SetValue ("RestartAusy", new Action<string> ((obj) => EventHandler.Instance.Trigger("RestartAusy", "placeholder")));
			JSEngine.SetValue("getAuSyVersion", new Func<string>(() => ProgramProperties.Version));

			EventHandler.Instance.ClearJSCallbacks ();
			EventHandler.Instance.Trigger("ClearCustomLineTypes", "");

			jsMutexWait ();
			foreach (var t in _jsTimers)
			{
				t.Value.Stop ();
				t.Value.Dispose ();
			}
			_jsTimers.Clear ();
			jsMutexRelease ();

			if (elapsedTimers.Count!=0)
			{
				Logger.Instance.UpdateLog ("JS elapsed timer warning: There were elapsed timers when the JS engine was reset.", LoggerType.Warning, true);
			}
			ResetCallback?.Invoke (this);
		}

		/// <summary>Helper function for JS printing, since we cannot call a delegate directly (ATS-192).</summary>
		/// <param name="s">String to print.</param>
		public void DoJsPrint (string s, EventInfo? _ = null)
		{
			JsOutput (s);
		}

		/// <summary>Prints information about an exception, and customizes the message with some tips, if possible.</summary>
		/// <param name="ex">The exception.</param>
		/// <param name="executionContext">If the code is inside a timer, an included file, etc., write a message that explains the context here.</param>
		private void printException(Exception ex)
		{
			string message = "";
			if (ex.GetType() == typeof(JavaScriptException))
			{
				// Build the basic error message.
				JavaScriptException jsEx = (JavaScriptException) ex;
				message = "Script error";
				if (_runningContext != "")
				{
					message += " in " + _runningContext;
				}
				message +=
					": " +
					(ex.ToString() == "SyntaxError" ? "Syntax error" : ex.Message) +
					" (" + jsEx.Location.Start.Line + "," + jsEx.Location.Start.Column +
					" - " + jsEx.Location.End.Line + "," + jsEx.Location.End.Column +
					")";
				
				// Try to find possible tips.
				Match undefinedNumberMatch = Regex.Match(jsEx.Error.ToString(),
					"TypeError: ([0-9]+) is undefined");
				if (undefinedNumberMatch.Success)
				{
					message += " (TIP: If you are accessing a list, that means the list has no index " + undefinedNumberMatch.Groups[1].Value + ".)";
				}

				Match methodArgumentsMatch = Regex.Match(jsEx.Error.ToString(),
					"TypeError: No public methods with the specified arguments were found.");
				if (methodArgumentsMatch.Success)
				{
					message += " (TIP: Are you forgetting a function argument? Or do you have too many?)";
				}

				Match machineNotFoundMatch = Regex.Match(jsEx.Error.ToString(),
					"machine is not defined");
				if (machineNotFoundMatch.Success)
				{
					message += " (TIP: If this is an AuSy Coordinator, then you need to refer to a specific machine.)";
				}
			}
			else
			{
				// Build the error message.
				message = "Error while trying to run script";
				if (_runningContext != "")
				{
					message += " in " + _runningContext;
				}
				message += ": " + ex.Message;
			}

			JsOutput(message);
		}

		public void SetAltIncludesFolderWrapper(string altIncludeFolder, EventInfo? _)
		{
			SetAltIncludesFolder(altIncludeFolder);
		}
		
		public void SetAltIncludesFolder(string altIncludeFolder)
		{
			this.altIncludesFolder = altIncludeFolder;
		}

		public void JsOutputWrapper(string logMessage, EventInfo? _)
		{
			JsOutput?.Invoke(logMessage);
		}

		public void SetLogFileLocation(string logFileLocation, EventInfo? __)
		{
			this.logFileLocation = logFileLocation;
		}
    }
}