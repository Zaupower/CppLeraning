using AutoTestingService;

namespace AuSy.Modules.Scripter
{
    /// <summary>Wrapper for the object used in JavaScript to control the tests.</summary>
    public class JsTestController
    {
        /// <summary>Registers the info for the current test.</summary>
        public void RegisterTest (string testName)
        {
            EventHandler.Instance.Trigger ("RegisterTest", testName);
        }

        /// <summary>Registers the info for the current step.</summary>
        public void RegisterStep (string stepName)
        {
            EventHandler.Instance.Trigger ("RegisterStep", stepName);
        }

        /// <summary>Signals the current test as having passed.</summary>
        public void Pass ()
        {
            EventHandler.Instance.Trigger ("PassTest", "");
        }

        /// <summary>Signals the current step as having passed.</summary>
        public void PassStep ()
        {
            EventHandler.Instance.Trigger ("PassStep", "");
        }

        /// <summary>Signals the current test as having failed.</summary>
        public void Fail ()
        {
            EventHandler.Instance.Trigger ("FailTest", "");
        }

        /// <summary>Signals the current step as having failed.</summary>
        public void FailStep ()
        {
            EventHandler.Instance.Trigger ("FailStep", "");
        }

        /// <summary>Stops the tests.</summary>
        public void StopTests ()
        {
            EventHandler.Instance.Trigger ("StopTests", "");
        }
    }
}