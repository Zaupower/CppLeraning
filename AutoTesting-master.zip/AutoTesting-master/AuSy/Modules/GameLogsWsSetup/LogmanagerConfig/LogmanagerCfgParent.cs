using Newtonsoft.Json;

namespace AuSy.WebsocketLogsSetup.LogmanagerConfig
{
    /// <summary>Class used for logmanager.cfg (json file) deserialize.</summary>
    public class LogmanagerCfgParent
    {
        #region JsonVariables

        [JsonProperty] 
        public logmanagerConfig LOGMANAGER_CFG = new logmanagerConfig();
        
        #endregion
    }
}