using System.Collections.Generic;
using Newtonsoft.Json;

namespace AuSy.WebsocketLogsSetup.LogmanagerConfig
{
    public class Filters
    {
        #region Variables

        [JsonIgnore]
        public readonly List<string> criticalLogModules = new List<string>()
        {
            "Accounting", "Buttons", "Buttons", "GAME", "GameController", "Gameplay", "GameplayButton", "Events", "Core", "ApplicationError"
        };
        
        #endregion
        
        #region JsonVariables

        [JsonProperty] 
        public LogModule Accounting { get; set; }
        
        [JsonProperty] 
        public LogModule Animation { get; set; }
        
        [JsonProperty] 
        public LogModule ApplicationError { get; set; }
        
        [JsonProperty] 
        public LogModule Auto { get; set; }
        
        [JsonProperty] 
        public LogModule BonusTypeChoice { get; set; }
        
        [JsonProperty] 
        public LogModule BonusTypeChoiceFSM { get; set; }
        
        [JsonProperty] 
        public LogModule Buttons { get; set; }
        
        [JsonProperty] 
        public LogModule Checksum { get; set; }
        
        [JsonProperty] 
        public LogModule Container { get; set; }
        
        [JsonProperty] 
        public LogModule Core { get; set; }
        
        [JsonProperty] 
        public LogModule DebugTools { get; set; }
        
        [JsonProperty] 
        public LogModule Drivers { get; set; }
        
        [JsonProperty] 
        public LogModule Engine { get; set; }
        
        [JsonProperty] 
        public LogModule EventManager { get; set; }
        
        [JsonProperty] 
        public LogModule Events { get; set; }
        
        [JsonProperty] 
        public LogModule GAME { get; set; }
        
        [JsonProperty] 
        public LogModule GameController { get; set; }
        
        [JsonProperty] 
        public LogModule Gameplay { get; set; }
        
        [JsonProperty] 
        public LogModule GameplayButton { get; set; }
        
        [JsonProperty] 
        public LogModule HwMediator { get; set; }
        
        [JsonProperty] 
        public LogModule JSScript { get; set; }
        
        [JsonProperty] 
        public LogModule Ledstrips { get; set; }
        
        [JsonProperty] 
        public LogModule LocaleManager { get; set; }
        
        [JsonProperty] 
        public LogModule LogManager { get; set; }
        
        [JsonProperty] 
        public LogModule Logger { get; set; }
        
        [JsonProperty] 
        public LogModule MachineBlocked { get; set; }
        
        [JsonProperty] 
        public LogModule MathGame { get; set; }
        
        [JsonProperty] 
        public LogModule Module { get; set; }
        
        [JsonProperty] 
        public LogModule Mystery { get; set; }
        
        [JsonProperty] 
        public LogModule MysteryController { get; set; }
        
        [JsonProperty] 
        public LogModule Network { get; set; }
        
        [JsonProperty] 
        public LogModule PIN { get; set; }
        
        [JsonProperty] 
        public LogModule Renderer { get; set; }
        
        [JsonProperty] 
        public LogModule Resource { get; set; }
        
        [JsonProperty] 
        public LogModule ResourceHandler { get; set; }
        
        [JsonProperty] 
        public LogModule ResourceLoader { get; set; }
        
        [JsonProperty] 
        public LogModule ResourceManager { get; set; }
        
        [JsonProperty] 
        public LogModule Scene { get; set; }
        
        [JsonProperty] 
        public LogModule SceneManager { get; set; }
        
        [JsonProperty] 
        public LogModule ScriptManager { get; set; }
        
        [JsonProperty] 
        public LogModule SettingsWindow { get; set; }
        
        [JsonProperty] 
        public LogModule SoundManager { get; set; }
        
        [JsonProperty] 
        public LogModule Sprite { get; set; }
        
        [JsonProperty] 
        public LogModule StateMachine { get; set; }
        
        [JsonProperty] 
        public LogModule Storage { get; set; }
        
        [JsonProperty] 
        public LogModule StringUtils { get; set; }
        
        [JsonProperty] 
        public LogModule System { get; set; }
        
        [JsonProperty] 
        public LogModule TCP { get; set; }
        
        [JsonProperty] 
        public LogModule TaskManager { get; set; }
        
        [JsonProperty] 
        public LogModule Texture { get; set; }
        
        [JsonProperty] 
        public LogModule Window { get; set; }
        
        [JsonProperty] 
        public LogModule XMLParser { get; set; }
        
        [JsonProperty(PropertyName = "JS -> Background Visible: true")] 
        public LogModule JSBackgroundVisible { get; set; }
        
        [JsonProperty(PropertyName = "JS -> Draw Last Bone 11")] 
        public LogModule JSDrawLastBone { get; set; }
        
        [JsonProperty(PropertyName = "JSON-Read")] 
        public LogModule JsonRead { get; set; }
        
        [JsonProperty(PropertyName = "Network-Recv")] 
        public LogModule NetWorkRecv { get; set; }
        
        [JsonProperty(PropertyName = "Network-Sent")] 
        public LogModule NetworkSent { get; set; }
        
        [JsonProperty(PropertyName = "Storage API")] 
        public LogModule StorageAPI { get; set; }

        #endregion
    }
}