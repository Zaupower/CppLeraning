using Newtonsoft.Json;

namespace AuSy.WebsocketLogsSetup.LogmanagerConfig
{
    /// <summary>Class used for logmanager.cfg (json file) deserialize.</summary>
    public class logmanagerConfig
    {
        #region JsonVariables

        [JsonProperty] 
        public Filters filters = new Filters();

        [JsonProperty]
        public Meta meta = new Meta();

        #endregion
    }
}