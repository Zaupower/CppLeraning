using Newtonsoft.Json;

namespace AuSy.WebsocketLogsSetup.LogmanagerConfig
{
    public class LogModule
    {
        #region Defaults

        private const bool _socketDefault = true;

        #endregion
        
        #region JsonVariables

        [JsonProperty] 
        public bool dbgtools { get; set; }
        
        [JsonProperty] 
        public bool file { get; set; }
        
        [JsonProperty] 
        public bool socket { get; set;  } = _socketDefault;
        
        [JsonProperty] 
        public bool term { get; set; }
        
        #endregion
    }
}