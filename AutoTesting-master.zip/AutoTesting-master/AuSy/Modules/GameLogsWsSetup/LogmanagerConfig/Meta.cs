using Newtonsoft.Json;

namespace AuSy.WebsocketLogsSetup.LogmanagerConfig
{
    public class Meta
    {
        #region JsonVariables

        [JsonProperty] 
        public string loggingip { get; set; }

        [JsonProperty] 
        public string loggingport { get; set; }

        [JsonProperty] 
        public string loggingsockettype { get; set; }

        #endregion
    }
}