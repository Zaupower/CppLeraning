using System;
using System.IO;
using System.Linq;
using AuSy.WebsocketLogsSetup.LogmanagerConfig;
using AutoTestingService.Logging;
using AutoTestingService.Shared;
using Newtonsoft.Json;

namespace AuSy.Modules.GameLogsWsSetup
{
    public class GameLogsWsSetup
    {
        #region Variables

        /// <summary>Ip of machine that reads logs via websocket (can be localhost).</summary>
        private string _logReaderIp;
        
        /// <summary>Object with game file logmanager.cfg Json information deserialized.</summary>
        private LogmanagerCfgParent _logmanagerConfig;
        
        #endregion
        
        #region Singleton

        /// <summary>Class instance (Singleton).</summary>
        public static GameLogsWsSetup Instance { get; } = new GameLogsWsSetup();

        private GameLogsWsSetup()
        {
        }

        #endregion
        
        #region Init and Terminate
		
        /// <summary>Initializer for module GameLogsWsSetup</summary>
        /// <param name="logsReceiverIp">Ip of machine that is going to read logs via websocket.</param>
        public void Init(string logReaderIp, string gameFolderPath)
        {
            _logReaderIp = logReaderIp;
            SetupLogManagerFile(gameFolderPath, logReaderIp);
        }

        /// <summary>Terminates GameLogsWsSetup module.</summary>
        public void Terminate()
        {
            _logReaderIp = null;
            _logmanagerConfig = null;
        }

        #endregion
        
        #region Setup

		/// <summary>Setups logmanager.cfg file to enable game logs via websockets</summary>
        /// <param name="gameFolderPath">Full path to game folder</param>
        /// <param name="loggingIp">IP addr where the game sends logs to via websockets.</param>
        private void SetupLogManagerFile(string gameFolderPath, string loggingIp)
        {
            string logmanagerFullPath = Path.Combine(gameFolderPath, ATNames.Instance.logmanagerFilePath);
            
            if (!File.Exists(logmanagerFullPath))
            {
                Logger.Instance.UpdateLog("Can't initialize Websockets LogReader: There's no logmanager.cfg file in the path: " + logmanagerFullPath, LoggerType.Warning);
                return;
            }

            deserializeLogManager(logmanagerFullPath);
            
            updateLogManagerObject(loggingIp);
            
            serializeLogManager(logmanagerFullPath);
        }
        
        
        /// <summary>Deserializes logmanager.cfg and stores it.</summary>
        /// <param name="logmanagerFullPath">Full path to logmanager.cfg</param>
        private void deserializeLogManager(string logmanagerFullPath)
        {
            using (StreamReader fs = new StreamReader(logmanagerFullPath))
            {
                _logmanagerConfig = JsonConvert.DeserializeObject<LogmanagerCfgParent>(fs.ReadToEnd());
            }
            
            if (_logmanagerConfig == null)
                _logmanagerConfig = new LogmanagerCfgParent();
        }

        /// <summary>Updates the logmanager object for enabling game logs via websocket.</summary>
        /// <param name="loggingIp">IP addr where the game sends logs to via websockets.</param>
        private void updateLogManagerObject(string loggingIp)
        {
            _logmanagerConfig.LOGMANAGER_CFG.meta.loggingip = loggingIp;
            _logmanagerConfig.LOGMANAGER_CFG.meta.loggingport = "4649"; // Em modo distribuido terá a porta do AusyServer (4650??)
            _logmanagerConfig.LOGMANAGER_CFG.meta.loggingsockettype = "web";

            Filters filters = _logmanagerConfig.LOGMANAGER_CFG.filters;
            foreach (var p in filters.GetType().GetProperties())
            {
                if (p.PropertyType == typeof(LogModule))
                {
                    LogModule logModule = (LogModule) p.GetValue(filters);
                    
                    if (logModule == null && filters.criticalLogModules.Contains(p.Name, StringComparer.OrdinalIgnoreCase))
                    {
                        p.SetValue(filters, new LogModule());
                        LogModule newLogModule = (LogModule) p.GetValue(filters);
                        newLogModule.dbgtools = true;
                        newLogModule.file = true;
                        newLogModule.socket = true;
                        newLogModule.term = true;
                    }
                    else if (logModule != null)
                    {
                        if (logModule.file)
                            logModule.socket = true;
                    }
                }
            }
        }

        /// <summary>Serializes the logmanager.cfg file with the new information updated.</summary>
        /// /// <param name="logmanagerFullPath">Full path to logmanager.cfg</param>
        private void serializeLogManager(string logmanagerFullPath)
        {
            using (StreamWriter fs = new StreamWriter(logmanagerFullPath))
            {
                fs.Write(JsonConvert.SerializeObject(_logmanagerConfig, Formatting.Indented, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }));
            }
        }

        #endregion
    }
}