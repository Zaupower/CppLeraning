using System;
using System.Collections.Generic;
using AutoTestingService;
using AutoTestingService.Logging;

namespace AuSy.Modules.MachineManager
{
    /// <summary>Machine Configuration class.</summary>
    /// <description>Stores the information about a Machine configuration. Like the ID, IP, Distro, etc.</description>
    [Serializable]
    public class MachineConfig
    {
        /// <summary>Gets or sets the machine unique ID number.</summary>
        public int UId { get; set; }

        /// <summary>Gets or sets the Network IP Address.</summary>
        public string Ip { get; set; }

        /// <summary>Gets or sets the current game's name.</summary>
        public string GameName { get; set; }

        /// <summary>Gets or sets the operative system's distribution version.</summary>
        public string Distro { get; set; }

        /// <summary>Gets or sets the currently configured country ID number.</summary>
        public int Country { get; set; }

        /// <summary>Gets or sets the currently configured cash system ID number.</summary>
        public int CashSystem { get; set; }

        /// <summary>Gets or sets the currently configured game server IP address.</summary>
        public string GameServerIP { get; set; }

        /// <summary>Gets or sets interpreter configuration</summary>
        public InterpreterConfiguration InterpreterConfig { get; set; }
    }

    /// <summary>Interpreter Configuration class.</summary>
    /// <description>Stores the information about an Interpreter configuration.</description>
    [Serializable]
    public class InterpreterConfiguration
    {
        /// <summary>Gets or sets the value of the Log Output control flag.</summary>
        public bool LogOutput { get; set; }
        
        /// <summary> Gets or sets the Type of the Log.</summary>
        public LogType LogType { get; set; }

        /// <summary>Gets or sets the Parser Configuration.</summary>
        public ParserConfiguration ParserConfig { get; set; }

        #region Methods
        public void FillGameplayInfo(List<GameEvent> gameEvents, GameplayInfo gameplay)
        {
            if (LogType == LogType.Bingo)
            {
	            FillGameplayInfoBingo(gameEvents, gameplay);
            }
            else if (LogType == LogType.Slots)
            {
	            FillGameplayInfoSlots(gameEvents, gameplay);
            }
        }

        public void FillGameplayInfoBingo(List<GameEvent> gameEvents, GameplayInfo gameplay)
        {
	        foreach (GameEvent e in gameEvents)
	        {
		        try
		        {
			        switch (e.name)
			        {
				        case "GameStart":
					        gameplay.Credits = double.Parse(e.parameters[1].ToString()) -
					                           double.Parse(e.parameters[2].ToString());
					        break;
				        case "InPlay":
					        List<List<int>> oldCards = null;
					        if (gameplay.Play != null)
					        {
						        oldCards = gameplay.Play.Cards;
					        }

					        gameplay.Play = new PlayInfo
					        {
						        Cards = oldCards
					        };
					        gameplay.Play.Balls.Clear();
					        string[] strList = e.parameters[0].ToString().Split(',');
					        foreach (string s in strList)
					        {
						        gameplay.Play.Balls.Add(int.Parse(s));
					        }

					        break;
				        case "GameEnd":
					        gameplay.Credits = double.Parse(e.parameters[0].ToString());
					        break;
				        case "ExtraBallPlayed":
					        gameplay.Credits -= double.Parse(e.parameters[1].ToString());
					        if (gameplay.Play == null)
					        {
						        gameplay.Play = new PlayInfo();
					        }

					        gameplay.Play.ExtraBalls.Add(new ExtraBall
					        {
						        number = int.Parse(e.parameters[0].ToString()),
						        cost = long.Parse(e.parameters[1].ToString())
					        });
					        break;
				        case "PrizeGot":
					        gameplay.Credits += double.Parse(e.parameters[2].ToString());
					        if (gameplay.Play == null)
					        {
						        gameplay.Play = new PlayInfo();
					        }

					        gameplay.Play.Prizes.Add(new Prize
					        {
						        card = int.Parse(e.parameters[0].ToString()),
						        id = int.Parse(e.parameters[1].ToString()),
						        value = int.Parse(e.parameters[2].ToString())
					        });
					        break;
				        case "BonusChance":
					        if (gameplay.Play == null)
					        {
						        gameplay.Play = new PlayInfo();
					        }

					        gameplay.Play.BonusPlays.Add(new BonusPlay());
					        break;
				        case "BonusOptionPlayed":
					        if (gameplay.Play == null)
					        {
						        gameplay.Play = new PlayInfo();
					        }

					        if (gameplay.Play.BonusPlays.Count == 0)
					        {
						        gameplay.Play.BonusPlays.Add(new BonusPlay());
					        }

					        gameplay.Play.BonusPlays[gameplay.Play.BonusPlays.Count - 1].pieceValues
						        .Add(int.Parse(e.parameters[1].ToString()));
					        break;
				        case "CardsChanged":
					        if (gameplay.Play == null)
					        {
						        gameplay.Play = new PlayInfo();
					        }

					        if (gameplay.Play.Cards == null)
					        {
						        gameplay.Play.Cards = new List<List<int>>();
					        }

					        gameplay.Play.Cards.Clear();
					        break;
				        case "CardValues":
					        if (gameplay.Play == null)
					        {
						        gameplay.Play = new PlayInfo();
					        }

					        if (gameplay.Play.Cards == null)
					        {
						        gameplay.Play.Cards = new List<List<int>>();
					        }

					        gameplay.Play.Cards.Add(new List<int>());
					        strList = e.parameters[1].ToString().Split(',');

					        foreach (string s in strList)
					        {
						        gameplay.Play.Cards[int.Parse(e.parameters[0].ToString()) - 1].Add(int.Parse(s));
					        }

					        break;
				        case "CashIn":
					        gameplay.Credits += long.Parse(e.parameters[0].ToString());
					        break;
				        case "CashOut":
					        gameplay.Credits = 0;
					        break;
				        case "ChangedGame":
					        gameplay.CurrentGame = e.parameters[0].ToString();
					        break;
			        }
		        }
		        catch (Exception ex)
		        {
			        string pStr = string.Join(", ", e.parameters);
			        Logger.Instance.UpdateLog(
				        "Error while filling gameplay info: " + ex + ". Event: " + e.name + ". Parameters: " + pStr +
				        ".", LoggerType.Develop);
		        }
	        }
        }

        public void FillGameplayInfoSlots(List<GameEvent> gameEvents, GameplayInfo gameplay)
        {
	        foreach (GameEvent e in gameEvents)
	        {
		        try
		        {
			        switch (e.name)
			        {
				        case "GameStart":
					        gameplay.Credits = double.Parse(e.parameters[1].ToString());
					        break;
				        case "GameEnd":
					        gameplay.Credits = double.Parse(e.parameters[0].ToString());
					        break;
				        case "CashIn":
					        gameplay.Credits += double.Parse(e.parameters[0].ToString());
					        break;
				        case "CashOut":
					        gameplay.Credits = 0;
					        break;
				        case "ChangedGame":
					        gameplay.CurrentGame = e.parameters[0].ToString();
					        break;
			        }
		        }
		        catch (Exception ex)
		        {
			        string pStr = string.Join(", ", e.parameters);
			        Logger.Instance.UpdateLog(
				        "Error while filling gameplay info: " + ex + ". Event: " + e.name + ". Parameters: " + pStr +
				        ".", LoggerType.Develop);
		        }
	        }
        }
        
        #endregion
    }

    /// <summary>Parser Configuration class.</summary>
    /// <description>Stores the information about the configuration of the Parser variables which will be used to
    /// control some of its behaviours.</description>
    [Serializable]
    public class ParserConfiguration
    {
        /// <summary>Email Sender receiver list.</summary>
        public string EmailSenderReceivers { get; set; }
    }
}