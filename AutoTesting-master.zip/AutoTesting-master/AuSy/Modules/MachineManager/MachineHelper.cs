using System;
using System.Net;
using AutoTestingService;

namespace AuSy.Modules.MachineManager
{
    public class MachineHelper
    {
        #region Singleton

        public static MachineHelper Instance { get; } = new MachineHelper ();

        private MachineHelper ()
        {
        }

        #endregion
        
        #region Get Config
        
        /// <summary>Get local machine configuration.</summary>
        /// <returns>The machine configuration's object.</returns>
        public MachineConfig GetLocalMachineConfig(LogType logType, string gamePath)
        {
	        MachineConfig machineCfg = new MachineConfig()
	        {
		        UId = Helper.Instance.GetIdFromNetWorkInterface(),
		        Ip = Helper.Instance.Ip,
		        GameName = Instance.GetGameName(gamePath),
		        Distro = Instance.GetDistro(),
		        Country = Instance.GetCountry(),
		        CashSystem = Instance.GetCashSystem(),
		        GameServerIP = Instance.GetGameServerIP(),
		        InterpreterConfig =  new InterpreterConfiguration
		        {
			        LogType = logType
		        }
	        };
	        return machineCfg;
        }

        #endregion

        #region Methods

        #region Information getters

        /// <summary>Finds and retrieves the name of the current game, from the file <c>game.info</c>.</summary>
        /// <returns>The game's name, or "-" if not found.</returns>
        public string GetGameName(string gamePath)
        {
	        string result = "-";
	        string gameName = Helper.Instance.GetLineInFile (gamePath + "/game.info", "GAME_NAME");

	        if (gameName != "-" && gameName.Length > 0)
	        {
		        result = gameName.Substring (gameName.IndexOf (":") + 1);
	        }
	        
	        return result;
        }

        /// <summary>Finds and retrieves the type of the current game, from the file <c>game.info</c>.</summary>
        /// <returns>The game's type, BINGO or SLOTS, or "-" if not found.</returns>
        public string GetGameType(string gamePath)
        {
	        string result = "-";
	        string gameType = Helper.Instance.GetLineInFile (gamePath + "/game.info", "GAME_TYPE");

	        if (gameType != "-" && gameType.Length > 0)
	        {
		        result = gameType.Substring (gameType.IndexOf (":") + 1);
	        }

	        return result;
        }

        /// <summary>Finds and retrieves the operative system distribution version.</summary>
        /// <returns>The distro version.</returns>
        public string GetDistro()
        {
	        string distro = Environment.GetEnvironmentVariable ("DIST_VERSION");
	        if (distro == null)
	        {
		        distro = "-";
	        }
	        return distro;
        }

        /// <summary>Finds and retrieves the number ID of the currently configured country.</summary>
        /// <returns>The country ID number.</returns>
        public int GetCountry()
        {
	        int i;
	        int.TryParse (Environment.GetEnvironmentVariable ("VAR_COUNTRY"), out i);
	        return i;
        }

        /// <summary>Finds and retrieves the number ID of the currently configured cash system.</summary>
        /// <returns>The cash system ID number.</returns>
        public int GetCashSystem()
        {
	        int i;
	        int.TryParse (Environment.GetEnvironmentVariable ("VAR_CASH_TYPE"), out i);
	        return i;
        }

        /// <summary>Finds and retrieves the currently configured game server IP address.</summary>
        /// <returns>The game server IP.</returns>
        public string GetGameServerIP()
        {
	        string gameServerIP = Environment.GetEnvironmentVariable ("VAR_GAMESERVER_IP_ADDR");
	        if (gameServerIP == null)
	        {
		        gameServerIP = "-";
	        }
	        return gameServerIP;
        }

        #endregion

        #endregion
    }
}