using System;
using System.Collections.Generic;
using System.Net;
using System.Threading;
using AutoTestingService;
using AutoTestingService.Configuration;
using AutoTestingService.Configuration.AusyConfig;
using AutoTestingService.Configuration.EGMConfig;
using AutoTestingService.Logging;
using AutoTestingService.Machine;
using Newtonsoft.Json;
using EventHandler = AutoTestingService.EventHandler;

namespace AuSy.Modules.MachineManager
{
    /// <summary>Contains a list of every machine in the system, and is responsible for
    /// keeping track of new machines and disconnections.</summary>
	public class MachineManager
    {
        #region Singleton

        public static MachineManager Instance { get; } = new MachineManager ();

        private MachineManager ()
        {
        }

        #endregion
        
        #region Members

        /// <summary>List of registered machines.</summary>
		private Dictionary<int, Machine> _machines;

        private Machine _standaloneMachine;
        
        /// <summary>Access mutex.</summary>
		private Mutex _machineAccessMutex;

        /// <summary>Is the program in standalone mode?</summary>
        private bool _isStandalone;

        #endregion

		#region Init and Terminate

		/// <summary>Initializes the Machine Manager.</summary>
		/// <param name="standalone">True if the application is in standalone operator mode.</param>
		public void Init(bool isStandalone, LogType logType, string gamePath)
		{
			_machines = new Dictionary<int, Machine> ();
			_machineAccessMutex = new Mutex ();
			
			_isStandalone = isStandalone;

			EventHandler.Instance.AddCallback("RegisterMachine", RegisterMachineWrapper);
			EventHandler.Instance.AddCallback("ConnectionToAusyLost", HandleAusyConnectionLostWrapper);
			EventHandler.Instance.AddCallback("LoadedAusyConfig", GotLoadedAusyConfigWrapper);
			EventHandler.Instance.AddCallback("LoadedEGMConfig", GotLoadedEGMConfigWrapper);

			if (_isStandalone)
			{
				MachineConfig config = MachineHelper.Instance.GetLocalMachineConfig(logType, gamePath);

				_standaloneMachine = RegisterMachine(JsonConvert.SerializeObject(config), config.Ip);
				EventHandler.Instance.AddCallback("StartAusy", SetCurrentScripterMachine);
			}
		}

		/// <summary>Terminates MachineManager module.</summary>
		public void Terminate()
		{
			_machines = null;
			_machineAccessMutex = null;
			_isStandalone = default(bool);
			EventHandler.Instance.RemoveCallback("RegisterMachine", RegisterMachineWrapper);
			EventHandler.Instance.RemoveCallback("ConnectionToAusyLost", HandleAusyConnectionLostWrapper);
			EventHandler.Instance.RemoveCallback("LoadedAusyConfig", GotLoadedAusyConfigWrapper);
			EventHandler.Instance.RemoveCallback("LoadedEGMConfig", GotLoadedEGMConfigWrapper);
			if (_isStandalone)
			{
				EventHandler.Instance.RemoveCallback("StartAusy", SetCurrentScripterMachine);
			}
		}

		#endregion

		#region Machine control

		private void SetCurrentScripterMachine(string _, EventInfo? __)
		{
			if (_standaloneMachine != null)
			{
				Scripter.Scripter.Instance.SetCurrentMachine(_standaloneMachine);
			}
			else
			{
				Logger.Instance.UpdateLog("SetCurrentScripterMachine: standalone machine object is null", LoggerType.Error);
			}
		}

		private void RegisterMachineWrapper(string machineConfigJson, EventInfo? info)
		{
			RegisterMachine(machineConfigJson, info != null ? info.Value.originIp : "");
		}

		private void HandleAusyConnectionLostWrapper(string machineConfigJson, EventInfo? info)
		{
			HandleAusyConnectionLost(machineConfigJson);
		}

		/// <summary>Registers a new machine into the system, if it is not already registered.</summary>
		/// <param name="machineConfigJson">JSON with the machine config information.</param>
		/// <param name="ip">IP of the registering machine.</param>
		/// <returns>The newly registered machine.</returns>
		private Machine RegisterMachine(string machineConfigJson, string ip)
		{
			MachineConfig machineConfig = JsonConvert.DeserializeObject<MachineConfig>(machineConfigJson);
			// Use the event sender's IP. The other one could be empty, or could be a different IP from what the AuSy coordinator expects.
			machineConfig.Ip = ip;
			Machine machine = null;
			
			WaitOne();
			
			try
			{
				bool found = false;
				foreach (KeyValuePair<int,Machine> m in _machines)
				{
					if (m.Value.Config.Ip == machineConfig.Ip)
					{
						machine = m.Value;
						found = true;
						break;
					}
				}

				if (!found)
				{
					machine = new Machine(machineConfig, GetFreeSessionIdx(), true);
					_machines.Add (machine.Config.UId, machine);
				}
				else
				{
					machine.IsOnline = true;
				}
			}
			catch (Exception ex)
			{
				Logger.Instance.UpdateLog ("RegisterMachine exception caught:\n" + ex.Message, LoggerType.Error);
				ReleaseMutex ();
			}
			
			ReleaseMutex();

			return machine;
		}

		/// <summary>Returns an existing machine.</summary>
		/// <returns>The requested machine.</returns>
		/// <param name="id">Machine identifier.</param>
		public Machine GetMachine (int id)
		{
			Machine result = null;
			WaitOne ();
			foreach (var machine in _machines)
			{
				if (machine.Value.SessionIdx == id)
				{
					result = machine.Value;
					break;
				}
			}
			ReleaseMutex ();
			return result;
		}

		/// <summary>Returns an existing machine.</summary>
		/// <returns>The requested machine.</returns>
		/// <param name="ip">Machine IP.</param>
		public Machine GetMachine (string ip)
		{
			Machine result = null;
			WaitOne ();
			foreach (KeyValuePair<int,Machine> m in _machines)
			{
				if (Helper.Instance.IpsMatch(ip, m.Value.Config.Ip))
				{
					result = m.Value;
				}
			}
			ReleaseMutex ();
			return result;
		}

		/// <summary>Returns how many machines exist.</summary>
		/// <returns>Machine count.</returns>
		public int GetMachineCount ()
		{
			return _machines.Count;
		}

		/// <summary>Returns the whole dictionary of machines.</summary>
		/// <returns>Dictionary of machines.</returns>
		public Dictionary<int, Machine> GetMachines ()
		{
			return _machines;
		}
		
		/// <summary>
		/// Returns a dictionary of machines for the JavaScript engine.
		/// </summary>
		public Dictionary<int, GameplayInfo> GetMachinesForJsEngine ()
		{
			Dictionary<int, GameplayInfo> list = new Dictionary<int, GameplayInfo> ();
			if (WaitOne ())
			{
				foreach (KeyValuePair<int, Machine> m in GetMachines ())
				{
					list.Add (m.Value.SessionIdx, m.Value.GamePlay);
				}
				ReleaseMutex ();
			}
			return list;
		}

		/// <summary>Handles a connection with an AuSy machine being lost.</summary>
		/// <param name="ip">IP of the machine with AuSy</param>
		private void HandleAusyConnectionLost(string ip)
		{
			WaitOne();
			foreach (KeyValuePair<int,Machine> m in _machines)
			{
				if (Helper.Instance.IpsMatch(ip, m.Value.Config.Ip))
				{
					m.Value.IsOnline = false;
				}
			}
			ReleaseMutex();
		}

		/// <summary>Attempts to aquire the machine access mutex.</summary>
		/// <returns><c>true</c>, if it was aquired, <c>false</c> otherwise.</returns>
		/// <param name="millisecondsTimeout">Milliseconds timeout.</param>
		public bool WaitOne (int millisecondsTimeout = -1)
		{
			if (millisecondsTimeout == -1)
			{
				if (_machineAccessMutex.WaitOne ())
				{
					return true;
				}
			}
			else if (_machineAccessMutex.WaitOne (millisecondsTimeout))
			{
				return true;
			}
			return false;
		}

		/// <summary>Releases the machine access mutex.</summary>
		public void ReleaseMutex ()
		{
			_machineAccessMutex.ReleaseMutex ();
		}

		/// <summary>Returns a session index that is not in use.</summary>
		/// <returns>A free session index.</returns>
		public int GetFreeSessionIdx ()
		{
			WaitOne ();
			bool found = false;
			int result = 1;
			while (!found)
			{
				found = true;
				foreach (var m in _machines)
				{
					if (m.Value.SessionIdx == result)
					{
						found = false;
						break;
					}
				}
				if (!found)
				{
					result++;
				}
			}

			ReleaseMutex ();
			return result;
		}
		
		#endregion

		#region Machine configs

		public void GotLoadedAusyConfigWrapper(string ausyConfigJson, EventInfo? info)
		{
			GotLoadedAusyConfig(ausyConfigJson, info != null ? info.Value.originIp : "localhost");
		}
		
		/// <summary>Stores loaded Ausy config and triggers JS event "GotAusyConfig".</summary>
		/// <param name="ausyConfigJson">Ausy config json.</param>
		/// <param name="machineIp">Ip of machine that loaded ausy config.</param>
		public void GotLoadedAusyConfig(string ausyConfigJson, string machineIp)
		{
			AusyConfiguration ausyConfig = JsonConvert.DeserializeObject<AusyConfiguration>(ausyConfigJson);
			Machine mach = GetMachine(machineIp);
			mach.GamePlay.AusyConfig = ausyConfig;
			mach.GamePlay.AusyConfig.SetMachineIp(mach.Config.Ip);
			EventDistributor.Instance.Trigger("GotAusyConfig", "");
		}

		public void GotLoadedEGMConfigWrapper(string EgmConfig, EventInfo? info)
		{
			GotLoadedEGMConfig(EgmConfig, info != null ? info.Value.originIp : "localhost");
		}
		
		/// <summary>Stores loaded EGM config and triggers JS event "GotEGMConfig".</summary>
		/// <param name="EgmConfig"></param>
		/// <param name="machineIp"></param>
		public void GotLoadedEGMConfig(string EgmConfig, string machineIp)
		{
			EGMConfig egmConfig = JsonConvert.DeserializeObject<EGMConfig>(EgmConfig);
			Machine mach = GetMachine(machineIp);
			mach.GamePlay.Config = egmConfig;
			mach.GamePlay.Config.SetMachineIp(mach.Config.Ip);
			EventDistributor.Instance.Trigger("GotEGMConfig", "");
		}

		#endregion

    }
}