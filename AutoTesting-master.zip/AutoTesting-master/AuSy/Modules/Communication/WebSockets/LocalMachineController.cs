﻿using System;
using System.Collections.Generic;
using AutoTestingService;
using AutoTestingService.Configuration.AusyConfig;
using AutoTestingService.Logging;
using AutoTestingService.Machine;
using Newtonsoft.Json;
using Logger = AutoTestingService.Logging.Logger;
using EventHandler = AutoTestingService.EventHandler;

namespace AuSy.Modules.Communication.WebSockets
{
	//TODO Mudar esta classe de sítio (para Service onde está class parent MachineController??); passar os comments para código
	public class LocalMachineController : MachineController
	{
		public override bool IsReady ()
		{
			return true;
		}


		public override void BlockIP (string ip)
		{
			EventHandler.Instance.Trigger("BlockIP", ip);
		}

		public override void ChangeGame (int galleryGameNumber)
		{
			EventHandler.Instance.Trigger("ChangeGalleryGame", galleryGameNumber.ToString());
		}

		public override void ClearNVs ()
		{
			EventHandler.Instance.Trigger("ClearNVs", "");
		}

		public override void DoInputs (string inputs, int times)
		{
			EventHandler.Instance.Trigger("PressKey", inputs + " " + times);
		}

		public override void PressButton (string button)
		{
			EventHandler.Instance.Trigger("PressButton", button);
		}

		public override void DoTouch (int x, int y)
		{
			EventHandler.Instance.Trigger("Click", x + " " + y);
		}

		public override void FixMD5 ()
		{
			EventHandler.Instance.Trigger("FixMD5", "");
		}

		public override void ForceBalls (string balls)
		{
			EventHandler.Instance.Trigger("ForceBalls", balls);
		}

		public override void ForceCards (string cards)
		{
			EventHandler.Instance.Trigger("ForceCards", cards);
		}

		public override string GetIp ()
		{
			/*return AutoTestingClient.Instance.Ip;*/
			return String.Empty;
		}

		public override MachineConfiguration GetConfig ()
		{
			return new MachineConfiguration ()
			{
				/*CashSystem = AutoTestingClient.Instance.actionMediator.GetCashSystem(),
				Country = AutoTestingClient.Instance.actionMediator.GetCountry (),
				Distro = AutoTestingClient.Instance.actionMediator.GetDistro (),
				GameName = AutoTestingClient.Instance.actionMediator.GetGameName (),
				GameServerIP = AutoTestingClient.Instance.actionMediator.GetGameServerIP ()*/
			};
		}

		public override int GetSessionIdx ()
		{
			return 0;
		}

		public override void LoadAusyConfig ()
		{
			/*AutoTestingClient.Instance.LoadAusyConfig (AutoTestingClient.Instance.gameplay.AusyConfig);
			AutoTestingClient.Instance.scripter.eventHandler.Handle ("GotAusyConfig", new List<object> ());*/
		}
		
		public override void LoadEGMConfig ()
		{
			/*AutoTestingClient.Instance.LoadEGMConfig (AutoTestingClient.Instance.gameplay.Config);
			AutoTestingClient.Instance.scripter.eventHandler.Handle ("GotEGMConfig", new List<object> ());*/
		}

		public override void InsertCredits ()
		{
			EventHandler.Instance.Trigger("InsertCredits", "");
		}
		public override void RestartCashcode ()
		{
			EventHandler.Instance.Trigger("RestartCashcode", "");
		}

		public override void InsertBill (int value)
		{
			EventHandler.Instance.Trigger("InsertBill", value.ToString());
		}

		public override void InsertCard(string number)
		{
			EventHandler.Instance.Trigger("InsertCard", number);
		}

		public override void InsertTicket (string validationCode)
		{
			EventHandler.Instance.Trigger("InsertTicket", validationCode);
		}

		public override void RebootMachine ()
		{
			EventHandler.Instance.Trigger("Reboot", "");
		}

		public override void RemoveCredits ()
		{
			EventHandler.Instance.Trigger("RemoveCredits", "");
		}

		public override void RemoveTimer (string name)
		{
			/*AutoTestingClient.Instance.scripter.RemoveJSTimer (name, GetSessionIdx ());*/
		}

		public override void RestartGame ()
		{
			EventHandler.Instance.Trigger("RestartGame", "");
		}

		public override void SaveAusyConfig (AusyConfiguration config)
		{
			/*AutoTestingClient.Instance.SaveAusyConfig (config);*/
		}
		
		public override void SaveEGMConfig (EGMConfig config)
		{
			/*AutoTestingClient.Instance.SaveEGMConfig (config);*/
		}

		public override void SetInterval (string name, int milliseconds, string code)
		{
			/*AutoTestingClient.Instance.scripter.CreateJSTimer (name, milliseconds, code, GetSessionIdx (), true);*/
		}

		public override void SetTimeout (string name, int milliseconds, string code)
		{
			/*AutoTestingClient.Instance.scripter.CreateJSTimer (name, milliseconds, code, GetSessionIdx (), false);*/
		}

		public override void SetVLT (int vlt, int password)
		{
			EventHandler.Instance.Trigger("SetVLT", vlt + " " + password);
		}

		public override void TakeScreenshot (int width, int heigth,  int xdiff, int ydiff, string path)
		{
			EventHandler.Instance.Trigger("TakeScreenshot", width + " " + heigth + " " + xdiff + " " + ydiff + " " + path);
		}

		public override void UnblockIP (string ip)
		{
			EventHandler.Instance.Trigger("UnblockIP", ip);
		}

		public override bool CompareImages (string image1, string image2, int failPercentage)
		{
			
			int percentageValue = 100 - failPercentage;
			
			RunCommand shell = new RunCommand ();
			bool result = false;
			
			//https://openimageio.readthedocs.io/en/latest/idiff.html#process-return-codes
			switch (shell.RunExeCommand("idiff", " -fail 0.1 -failpercent " + percentageValue + " " + image1 + " " + image2, true))
			{
				case 0:
					Logger.Instance.UpdateLog ("CompareImages: The two images were equal.", LoggerType.Error);
					result = true;
					break;
				case 1:
					Logger.Instance.UpdateLog ("CompareImages: The two images were similar but not equal.", LoggerType.Error);
					result = true;
					break;
				case 2:
					Logger.Instance.UpdateLog ("CompareImages: The two images were different.", LoggerType.Error);
					result = false;
					break;
				case 3:
					Logger.Instance.UpdateLog ("CompareImages: Tried to compare images with different sizes.", LoggerType.Error);
					result = false;
					break;
				case 4:
				case null:
					Logger.Instance.UpdateLog ("CompareImages: Tried to compare an image that doesn't exist", LoggerType.Error);
					result = false;
					break;
			}

			return result;
		}
		
		public override void StartAFTCashIn (Dictionary<string, object> cashInInfo)
		{
			string jsonStr = JsonConvert.SerializeObject (cashInInfo);
			string message = "StartAFTCashIn;" + jsonStr;

			EventHandler.Instance.Trigger("StartAFTCashIn", message);
		}
		
		public override void StartAFTCashOut ()
		{
			string message = "StartAFTCashOut;";

			EventHandler.Instance.Trigger("StartAFTCashOut", message);
		}
		
		public override void SendSASLP (int lpNumber, Dictionary<string, object> cashOutInfo, string lpVersion = "")
		{
			string jsonStr = JsonConvert.SerializeObject (cashOutInfo);
			string message = "SendSASLP;" + lpNumber + ";" + jsonStr + ";" + lpVersion;
			
			EventHandler.Instance.Trigger("SendSASLP", message);
		}
		
		public override void SendSASByteArray (byte[] bytes)
		{
			string jsonStr = JsonConvert.SerializeObject (bytes);
			string message = "SendSASByteArray;" + jsonStr;
			
			EventHandler.Instance.Trigger("SendSASByteArray", message);
		}
		
		public override void GetSASMeter (int meterNumber)
		{
			string message = "GetSASMeter;" + meterNumber;
			
			EventHandler.Instance.Trigger("GetSASMeter", message);
		}
	}
}
