using AuSy.Modules.GameLogsReader.LogReader.LogReaderWebsocket;
using AutoTestingService;
using AutoTestingService.Logging;
using EventHandler = AutoTestingService.EventHandler;

namespace AuSy.Modules.Communication.WebSockets
{
    public class GameLogsCommunication
    {
        #region Constructor

        public GameLogsCommunication()
        {
        }

        #endregion

        #region Methods

        public void OnOpen(string ip)
        {
            Logger.Instance.UpdateLog("GameLogs connected to Ausy via Websocket.");
        }

        /// <summary> Handles a websocket string message from game logs.</summary>
        /// <param name="message">Message to process.</param>
        /// <param name="senderIp">Ip of the sender.</param>
        public void OnMessage(string message, string senderIp)
        {
            EventHandler.Instance.Trigger("WsNewGameLogLines", message, new EventInfo {originIp = senderIp});
        }

        /// <summary> Handles a websocket bytes message from game logs.</summary>
        /// <param name="message">Message to process.</param>
        public void OnBytesMessage(byte[] message, string senderIp)
        {
            //Logger.Instance.UpdateLog("Received a websocket bytes message from GameLogs. There's no handling for GameLogs byte messages.", LoggerType.Warning);
        }

        public void OnClose(string ip)
        {
            //Logger.Instance.UpdateLog("Connection between GameLogs and AuSy closed.");
        }

        #endregion
    }
}