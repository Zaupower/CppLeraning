using System;
using System.Collections.Generic;
using AutoTestingService.Logging;
using EventHandler = AutoTestingService.EventHandler;

namespace AuSy.Modules.Communication.WebSockets
{
    public class EmuCommunication
    {
        #region Constructor

        public EmuCommunication()
        {
        }

        #endregion

        #region Methods

        public void OnOpen(string senderIp)
        {
            Logger.Instance.UpdateLog("EMU connected to Ausy via Websocket.");
        }

        /// <summary> Handles a websocket string message from EMU.</summary>
        /// <param name="message">Message to process.</param>
        public void OnMessage(string message, string ip)
        {
            if (!message.Contains(";"))
            {
                Logger.Instance.UpdateLog("EMU informative message: " +  message);
                return;
            }

            string[] msgSplit = message.Split(new char[] {';'}, StringSplitOptions.RemoveEmptyEntries);
            string msgArgs = message.Substring(message.IndexOf(";"));

            string command = message.Substring(0, message.IndexOf(";"));

            switch (command)
            {
                case "TriggerEvent":
                    EventHandler.Instance.Trigger(msgSplit[1], msgSplit[2]);
                    break;
                case "EmuGotReport":
                    EventHandler.Instance.Trigger("EmuGotReport",
                        msgSplit[1] + ";" + msgSplit[2]);
                    break;
                case "EmuGotStartPlay":
                    EventHandler.Instance.Trigger("EmuGotStartPlay",
                        msgSplit[1] + ";" + msgSplit[2]);
                    break;
                case "EmuGotEndPlay":
                    EventHandler.Instance.Trigger("EmuGotEndPlay",
                        msgSplit[1] + ";" + msgSplit[2]);
                    break;
                case "EmuGotPrizeJackpot":
                    EventHandler.Instance.Trigger("EmuGotPrizeJackpot", msgArgs);
                    break;
                case "EmuWonJackpotLocal":
                    EventHandler.Instance.Trigger("EMUWonJackpotLocal", msgArgs);
                    break;
                default:
                    Logger.Instance.UpdateLog("Received undocumented command from websocket: " + command);
                    break;
            }
        }

        /// <summary> Handles a websocket bytes message from EMU.</summary>
        /// <param name="message">Message to process.</param>
        public void OnBytesMessage(byte[] message, string senderIp)
        {
            Logger.Instance.UpdateLog("Received a websocket bytes message from EMU. There's no handling for EMU byte messages.", LoggerType.Warning);
        }

        public void OnClose(string ip)
        {
            //Logger.Instance.UpdateLog("Connection between EMU and AuSy closed.");
        }

        #endregion
    }
}