using System;
using System.Collections.Generic;
using AutoTestingService;
using WebSocketSharp;
using Newtonsoft.Json;
using EventHandler = AutoTestingService.EventHandler;
using Logger = AutoTestingService.Logging.Logger;

namespace AuSy.Modules.Communication.WebSockets
{
    /// <summary>Class for Ausy to Ausy communication, for distributed mode.</summary>
    public class AusyCommunication
    {
        #region Methods

        public void OnOpen(string ip)
        {
            Logger.Instance.UpdateLog("Another Ausy connected to Ausy via Websocket.");
        }

        /// <summary>Handles a websocket string message from another Ausy.</summary>
        /// <param name="message">Message to process.</param>
        /// <param name="senderIp">Ip of the sender</param>
        public void OnAusyMsg(string message, string senderIp)
        {
            Logger.Instance.UpdateLog("New Ausy message: " + message);

            IDictionary<string, object> fullMsg = JsonConvert.DeserializeObject<IDictionary<string, object>>(message);

            switch (fullMsg["message"])
            {
                case "DistributedInvite":
                    EventHandler.Instance.Trigger("ConnectToCoordinator", (string) fullMsg["param"]);
                    break;
                case "TriggerEvent":
                    EventHandler.Instance.Trigger((string) fullMsg["eventName"], (string) fullMsg["param"], new EventInfo {originIp = senderIp});
                    break;
                default:
                    Logger.Instance.UpdateLog("Ausy operator message received doesn't have type TriggerEvent. It will be ignored.");
                    break;
            }
        }

        /// <summary>Handles a websocket string message from a coordinator Ausy.</summary>
        /// <param name="message">Message to process.</param>
        /// <param name="senderIp">Ip of the sender</param>
        public void OnCoordinatorMsg(string message, string senderIp)
        {
            Logger.Instance.UpdateLog("New Ausy coordinator message: " + message);
            
            IDictionary<string, object> fullMsg = JsonConvert.DeserializeObject<IDictionary<string, object>>(message);

            switch (fullMsg["message"])
            {
                case "TriggerEvent":
                    EventHandler.Instance.Trigger((string) fullMsg["eventName"], (string) fullMsg["param"], new EventInfo {originIp = senderIp});
                    break;
                default:
                    Logger.Instance.UpdateLog("Ausy coordinator message received doesn't have type TriggerEvent. It will be ignored.");
                    break;
            }
        }

        /// <summary>Handles a websocket bytes message from another Ausy (not used).</summary>
        /// <param name="message">Message to process.</param>
        public void OnBytesMessage(byte[] message, string senderIp)
        {
            
        }

        /// <summary>Handles the connection with the other Ausy being closed</summary>
        /// <param name="ip">Other Ausy IP</param>
        public void OnClose(string ip)
        {
            EventDistributor.Instance.Trigger("ConnectionToAusyLost", ip);
        }

        #endregion
    }
}