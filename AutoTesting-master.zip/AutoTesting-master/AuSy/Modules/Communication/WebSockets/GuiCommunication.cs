using System;
using System.Collections.Generic;
using System.IO;
using AutoTestingService;
using AutoTestingService.Logging;
using AutoTestingService.Shared;
using EventHandler = AutoTestingService.EventHandler;

namespace AuSy.Modules.Communication.WebSockets
{
    public class GuiCommunication
    {
	    #region Variables

	    //private string remoteScripterID;

	    public bool remoteScriptingOutputActive = false;

	    #endregion
	    
	    #region Constructor

	    public GuiCommunication()
	    {
		    EventHandler.Instance.AddCallback ("ScripterConnected", ProcessScripterConnection);
		    EventHandler.Instance.AddCallback ("ScripterDisconnected", ProcessScripterDisconnection);
	    }

	    #endregion

	    #region Communication Handling

	    public void OnOpen(string ip)
        {
           Logger.Instance.UpdateLog("GUI connected to Ausy.");
           EventHandler.Instance.Trigger ("ScripterConnected", "");
        }
	    
	    public void OnClose(string ip)
	    {
		    Logger.Instance.UpdateLog("GUI connection closed.");
		    EventHandler.Instance.Trigger ("ScripterDisconnected", "");
	    }
        
        /// <summary> Handles a websocket message from the GUI and responds accordingly.</summary>
        /// <param name="message">Message to process.</param>
        public void OnMessage(string message, string senderIp)
        {
	        string[] msgSplit = message.Split (new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);

	        string command = message.Substring (0, message.IndexOf (";"));

	        switch (command)
	        {
		        case "TriggerEvent":
			        EventHandler.Instance.Trigger(msgSplit[1], msgSplit[2]);
			        break;
		        case "JS":
			        message = message.Remove (0, 3);
			        EventHandler.Instance.Trigger("ResetJsEngine", "");
			        EventHandler.Instance.Trigger("RunJs", message);
			        
			        EventHandler.Instance.Trigger ("SendGuiMessage", "CodeReceived");
			        break;
		        case "RunScript":
			        //TODO passar para evento??
			        DateTime? modifyDate = Scripter.Scripter.Instance.jsEngineWrapper.GetScriptModifyDate (msgSplit[1]);
			        if (modifyDate == null)
			        {
				        EventHandler.Instance.Trigger ("SendGuiMessage", "RanScript;" + msgSplit[1] + ";-");
			        }
			        else
			        {
				        EventHandler.Instance.Trigger("ResetJsEngine", "");
				        EventHandler.Instance.Trigger("RunJsFile", msgSplit[1]);

				        string agoString = "[unknown]";
				        if (modifyDate != null)
				        {
					        agoString = Helper.Instance.GetTimeAgo (modifyDate.Value);
				        }
				        EventHandler.Instance.Trigger ("SendGuiMessage", "RanScript;" + msgSplit[1] + ";" + agoString);
			        }
			        break;
		        case "StopScript":
			        EventHandler.Instance.Trigger("ResetJsEngine", "");
			        EventHandler.Instance.Trigger ("SendGuiMessage", "StoppedScript");
			        break;
		        /*case "PigBoom":
			        EventHandler.Instance.Trigger ("SendToAll", "PigBoom;Activate");
			        break;
		        case "BlacklistIP":
		        case "RemoveBlacklistIP":
		        case "Ping":
			        EventHandler.Instance.Trigger ("SendToAll", message);
			        break;*/
		        case "SendEMU":
			        message = message.Remove (0, 8);
			        EventHandler.Instance.Trigger("SendEmuMessage", message);
			        break;
		        /*
		        case "EmuGotReport":
			        AutoTestingClient.Instance.scripter.eventHandler.Handle("EmuGotReport", new List<object> {msgSplit[1], msgSplit[2]});
			        break;
		        case "EmuGotStartPlay":
			        AutoTestingClient.Instance.scripter.eventHandler.Handle("EmuGotStartPlay", new List<object> {msgSplit[1], msgSplit[2]});
			        break;
		        case "EmuGotEndPlay":
			        AutoTestingClient.Instance.scripter.eventHandler.Handle("EmuGotEndPlay", new List<object> {msgSplit[1], msgSplit[2]});
			        break;*/
		        case "GetTestSuite":
			        EventHandler.Instance.Trigger("UpdateTestSuiteFromFolder", "");
			        // TODO passar este sendTestSuiteListMessage para módulo TestSuiteManager??
			        //AutoTestingClient.Instance.sendTestSuiteListMessage ();
			        break;
		        case "ChangeTestSuiteAndStart":
			        List<string> list = new List<string> (msgSplit);
			        list.RemoveAt (0);
			        EventHandler.Instance.Trigger ("ReplaceTests", string.Join(";", list));
			        // TODO passar este sendTestSuiteListMessage para módulo TestSuiteManager??
			        //AutoTestingClient.Instance.sendTestSuiteListMessage ();
			        EventHandler.Instance.Trigger("StartTests", "");
			        break;
		        case "StopTestSuite":
			        EventHandler.Instance.Trigger("StopTests", "");
			        break;
		        case "DeleteTest":
			        File.Delete ("scripts/" + msgSplit[1]);
			        EventHandler.Instance.Trigger("DeleteTest", msgSplit[1]);
			        // TODO passar este sendTestSuiteListMessage para módulo TestSuiteManager??
			        //AutoTestingClient.Instance.sendTestSuiteListMessage ();
			        break;
		        /*
		        case "EmuGotPrizeJackpot":
			        List<object> l1 = new List<object> (msgSplit);
			        l1.RemoveAt (0);
			        AutoTestingClient.Instance.scripter.eventHandler.Handle("EmuGotPrizeJackpot", l1);
			        break;
		        case "EmuWonJackpotLocal":
			        List<object> l2 = new List<object> (msgSplit);
			        l2.RemoveAt (0);
			        AutoTestingClient.Instance.scripter.eventHandler.Handle ("EMUWonJackpotLocal", l2);
			        break;
			    */
		        default:
			        Logger.Instance.UpdateLog ("Received undocumented command from websocket: " + command);
			        break;
	        }
        }

        public void HandleZipFileMessage(byte[] message, string senderIp)
        {
	        File.WriteAllBytes (ATNames.Instance.TempZipLocation, message);
	        
	        try
	        {
		        string origin = ATNames.Instance.TempZipLocation;
		        Helper.Instance.UnzipFiles (origin, "scripts");
		        File.Delete (ATNames.Instance.TempZipLocation);
		        EventHandler.Instance.Trigger("UpdateTestSuiteFromFolder", "");
		        // TODO passar este sendTestSuiteListMessage para módulo TestSuiteManager??
		        //AutoTestingClient.Instance.sendTestSuiteListMessage ();
	        }
	        catch (Exception ex)
	        {
		        Logger.Instance.UpdateLog ("Error with zip file reception: " + ex);
	        }
        }

        #endregion

	    #region Methods

	    /// <summary>Code to handle a scripter being connected.</summary>
	    /// <param name="scripterID">Scripter identifier.</param>
	    public void ProcessScripterConnection (string _, EventInfo? __)
	    {
		    remoteScriptingOutputActive = true;
		    if (TestManager.TestManager.Instance.running)
		    {
			    EventHandler.Instance.Trigger("SendGuiMessage",
				    "WalkedIntoTestInProgress;" + TestManager.TestManager.Instance.fileList[TestManager.TestManager.Instance.currentFileIdx]);
		    }
		    else if (Scripter.Scripter.Instance.jsEngineWrapper.running)
		    {
			    EventHandler.Instance.Trigger("SendGuiMessage",
				    "WalkedIntoScriptInProgress;" + Scripter.Scripter.Instance.jsEngineWrapper.runningFileName);
		    }

		    EventDistributor.Instance.Trigger("GuiConnected", "");
	    }

	    /// <summary>Code to handle a scripter being disconnected.</summary>
	    /// <param name="scripterID">Scripter identifier.</param>
	    public void ProcessScripterDisconnection (string _, EventInfo? __)
	    {
		    remoteScriptingOutputActive = false;
	    }

	    #endregion
        
    }
}