using System;
using System.Collections.Generic;
using AutoTestingService;
using AutoTestingService.Logging;
using Newtonsoft.Json;
using EventHandler = AutoTestingService.EventHandler;

namespace AuSy.Modules.Communication.WebSockets
{
    public class SasCommunication
    {
        #region Constructor

        public SasCommunication()
        {
        }

        #endregion

        #region Methods

        public void OnOpen(string ip)
        {
            Logger.Instance.UpdateLog("Sas connected to Ausy.");
        }

        /// <summary> Handles a websocket string message from SAS.</summary>
        /// <param name="message">Message to process.</param>
        public void OnMessage(string message, string senderIp)
        {
            IDictionary<string, object> fullMsg = JsonConvert.DeserializeObject<IDictionary<string, object>>(message);

            switch (fullMsg["message"])
            {
                case "TriggerEvent":
                    EventHandler.Instance.Trigger((string) fullMsg["eventName"], (string) fullMsg["param"], new EventInfo {originIp = senderIp});
                    break;
                case "GotSASLP":
                    EventHandler.Instance.Trigger("SASLPReceived", JsonConvert.SerializeObject(fullMsg["data"]));
                    break;
                case "GotMeter":
                    EventHandler.Instance.Trigger ("SASMeterReceived", JsonConvert.SerializeObject(fullMsg["data"]));
                    break;
                case "TransactionFinished":
                    EventHandler.Instance.Trigger ("TransactionFinished", JsonConvert.SerializeObject(fullMsg["data"]));
                    break;
                case "UnknownLPRequest":
                    EventHandler.Instance.Trigger("DoJsPrint", "SAS host tried to send an unknown LP: " + fullMsg["data"]);
                    break;
                case "UnknownLPReplyFromGame":
                    EventHandler.Instance.Trigger("DoJsPrint", "SAS host received an unknown LP reply from game: " + fullMsg["data"]);
                    break;
                case "GotUnknownMeter":
                    EventHandler.Instance.Trigger("DoJsPrint", "SAS host tried to ask for an unknown meter.");
                    break;
                default:
                    Logger.Instance.UpdateLog("Received undocumented command from websocket: " + message);
                    break;
            }
        }

        /// <summary> Handles a websocket bytes message from SAS.</summary>
        /// <param name="message">Message to process.</param>
        public void OnBytesMessage(byte[] message, string senderIp)
        {
            Logger.Instance.UpdateLog("Received a websocket bytes message at SAS. There's no handling for SAS byte messages.", LoggerType.Warning);
        }

        public void OnClose(string ip)
        {
            Logger.Instance.UpdateLog("Websocket connection between SAS and Ausy closed.");
        }

        #endregion
    }
}