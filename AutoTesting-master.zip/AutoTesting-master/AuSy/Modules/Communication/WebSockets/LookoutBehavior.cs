using System.Reflection;
using WebSocketSharp;
using WebSocketSharp.Server;
using EventHandler = AutoTestingService.EventHandler;

namespace AuSy.Modules.Communication.WebSockets
{
    // TODO este behavior vai deixar de existir (usar nova lib de websockets para lookout)
    public class LookoutBehavior : WebSocketBehavior
    {
        /// <summary>When the connection is closed.</summary>
        /// <param name="e">Event arguments.</param>
        protected override void OnClose (CloseEventArgs e)
        {
            base.OnClose (e);

            // https://github.com/sta/websocket-sharp/issues/144
            var targetType = typeof (WebSocketBehavior);
            var base_websocket = targetType.GetField ("_websocket", BindingFlags.Instance | BindingFlags.NonPublic);
            base_websocket.SetValue (this, null);
        }

        /// <summary>When a message is received.</summary>
        /// <param name="e">Event arguments.</param>
        protected override void OnMessage (MessageEventArgs e)
        {
            /*AutoTestingClient.Instance.ConnectionRequestAddress = e.Data;
            AutoTestingClient.Instance.ConnectionRequestSignal.Set();*/
        }
    }
}