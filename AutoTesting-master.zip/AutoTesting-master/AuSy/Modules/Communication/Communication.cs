using System;
using System.Collections.Generic;
using System.Threading;
using AuSy.Modules.Communication.WebSockets;
using AuSy.Modules.MachineManager;
using AutoTestingService;
using WebSockets;
using WebSocketServer = WebSockets.WebSocketServer;
using EventHandler = AutoTestingService.EventHandler;
using AutoTestingService.Logging;
using Newtonsoft.Json;
using WebSocketClient = WebSockets.WebSocketClient;

namespace AuSy.Modules.Communication
{
    public class Communication
    {
        #region Singleton

        public static Communication Instance { get; } = new Communication ();

        private Communication ()
        {
        }

        #endregion

        #region Members

        /// <summary>The central module communication hub.</summary>
        public CommunicationManager hub;

        /// <summary>Class for communication with other Ausy's.</summary>
        private AusyCommunication _ausy;
        
        /// <summary>Class specifically for communicating with EMU.</summary>
        private EmuCommunication _emu;

        /// <summary>Class specifically for communicating with GUI.</summary>
        public GuiCommunication gui { get; private set; }

        /// <summary>Class specifically for communicating with SAS.</summary>
        private SasCommunication _sas;

        /// <summary>Class for communication with the game, to receive logs via websocket.</summary>
        private GameLogsCommunication _gameLogs;

        private LogType _logType;
        
        private string _gamePath;

        /// <summary>List of operators to connect to.</summary>
        private List<string> _operatorList;

        /// <summary>Coordinator IP that the operator is connected to, if any.</summary>
        private string _coordinatorIp;

        #endregion

        #region Init and Stop Methods

        /// <summary>Initialization method for Communication module.</summary>
        /// <param name="args">Arguments.</param>
        /// <param name="logType">Log type.</param>
        /// <param name="gamePath">Game directory path.</param>
        public void Init(CommunicationOptions args, LogType logType, string gamePath)
        {
            hub = new CommunicationManager();
            _ausy = new AusyCommunication();
            _emu = new EmuCommunication();
            gui = new GuiCommunication();
            _sas = new SasCommunication();
            _gameLogs = new GameLogsCommunication();

            _logType = logType;
            _gamePath = gamePath;
            _operatorList = args.OperatorList;

            bool serverNecessary =
                args.createServerForOtherApps ||
                args.createServerForOperators ||
                args.isLogsWebsocket ||
                args.isLookoutOperator;

            if (serverNecessary)
            {
                int serverPort = args.isLookoutOperator ? 4650 : 4649;
                WebSocketServer sv = hub.CreateWsServer(serverPort);
                
                if (args.createServerForOtherApps)
                {
                    sv.AddChannel(Apps.Emu, "/Emu-Ausy", _emu.OnOpen, _emu.OnMessage, _emu.OnBytesMessage, _emu.OnClose)
                        .AddChannel(Apps.Gui, "/Gui-Ausy", gui.OnOpen, gui.OnMessage, gui.HandleZipFileMessage, gui.OnClose)
                        .AddChannel(Apps.Sas, "/Sas-Ausy", _sas.OnOpen, _sas.OnMessage, _sas.OnBytesMessage, _sas.OnClose);

                    EventHandler.Instance.AddCallback("SendEmuMessage", SendEmuMessage);
                    EventHandler.Instance.AddCallback("SendGuiMessage", SendGuiMessage);
                    EventHandler.Instance.AddCallback("SendSasMessage", SendSasMessage);
                    EventHandler.Instance.AddCallback("SendAllMessage", SendAllMessage);
                    
                }

                if (args.isLogsWebsocket)
                {
                    sv.AddChannel(Apps.GameLogs, "/", _gameLogs.OnOpen, _gameLogs.OnMessage, _gameLogs.OnBytesMessage,
                        _gameLogs.OnClose);
                }

                if (args.createServerForOperators || args.isLookoutOperator)
                {
                    sv.AddChannel(
                        args.isLookoutOperator ? Apps.AusyCoordinator : Apps.AusyOperator,
                        "/Ausy-Ausy", _ausy.OnOpen, _ausy.OnAusyMsg, _ausy.OnBytesMessage, _ausy.OnClose);
                }
                
                sv.Start();
                
                hub.AddDirectConnection(Apps.Sas, _sas.OnOpen, _sas.OnMessage, _sas.OnBytesMessage, _sas.OnClose);
            }

            if (args.createClientForCoordinator)
            {
                if (!args.isLookoutOperator)
                {
                    EventHandler.Instance.AddCallback("StartAusy",
                        (s, i) => ConnectToCoordinatorAsync(args.CoordinatorIP));
                    EventHandler.Instance.AddCallback("ConnectionToAusyLost",
                        (s, i) => ConnectToCoordinatorAsync(s));
                }
                else
                {
                    EventHandler.Instance.AddCallback("ConnectionToAusyLost",
                        (s, i) =>
                        {
                            _coordinatorIp = "";
                            EventHandler.Instance.Trigger("EventReportIpChanged", "");
                        });
                }
                EventHandler.Instance.AddCallback("ConnectToCoordinator",
                    (s, i) => ConnectToCoordinatorAsync(s));
            }

            if (args.createServerForOperators)
            {
                EventHandler.Instance.AddCallback("StartAusy",
                    (s, i) => StartOperatorInviteThread());
            }
        }

        /// <summary>Stops all the running wsClients and wsServers.</summary>
        public void Stop()
        {
            hub.StopAllWsClients();
            hub.StopWsServer();
            hub.RemoveAllDirectConnections();
        }
        
        #endregion

        #region SendMessage Methods

        /// <summary>Sends EMU a string message</summary>
        /// <param name="message">Message</param>
        public void SendEmuMessage(string message, EventInfo? _)
        {
            hub.Send(Apps.Emu, message);
        }
                
        /// <summary>Sends GUI a string message</summary>
        /// <param name="message">Message</param>
        public void SendGuiMessage(string message, EventInfo? _)
        {
            hub.Send(Apps.Gui, message);
        }
        
        /// <summary>Sends SAS a string message</summary>
        /// <param name="message">Message</param>
        public void SendSasMessage(string message, EventInfo? _)
        {
            hub.Send(Apps.Sas, message);
        }
        
        /// <summary>Sends message to all modules connected to EMU via websockets</summary>
        /// <param name="message">Message</param>
        public void SendAllMessage(string message, EventInfo? _)
        {
            hub.SendToAll(message);
        }

        #endregion

        #region Misc

        private void ConnectToCoordinatorAsync(string coordinatorIp)
        {
            Thread connectToCoordinatorThread = new Thread(() => ConnectToCoordinator(coordinatorIp))
            {
                Name = "Connect Operator to Coordinator Thread"
            };
            connectToCoordinatorThread.Start();
        }
        
        private void ConnectToCoordinator(string coordinatorIp)
        {
            if (coordinatorIp != _coordinatorIp && !String.IsNullOrEmpty(_coordinatorIp))
            {
                Logger.Instance.UpdateLog("Refusing to connect to coordinator " + coordinatorIp +
                                          " because the operator is already connected to coordinator " +
                                          _coordinatorIp + ".");
                return;
            }
            
            WebSocketClient wsClient = hub.CreateWsClient(Apps.AusyCoordinator)
                .SetOnStringMessage(_ausy.OnCoordinatorMsg)
                .SetOnClose(_ausy.OnClose);

            while (!wsClient.Connect(coordinatorIp, 4649, "Ausy-Ausy"))
            {
                Logger.Instance.UpdateLog("Couldn't connect to Ausy coordinator via websockets. coordinatorIP: " + coordinatorIp);
                Thread.Sleep(5000);
            }

            _coordinatorIp = coordinatorIp;
            EventHandler.Instance.Trigger("EventReportIpChanged", coordinatorIp);
            Logger.Instance.UpdateLog("Connected to Ausy coordinator via websockets.");
            SendRegisterMachineToCoordinator(coordinatorIp, _logType, _gamePath);
        }

        private void SendRegisterMachineToCoordinator(string coordinatorIp, LogType logType, string gamePath)
        {
            MachineConfig machine = MachineHelper.Instance.GetLocalMachineConfig(logType, gamePath);
            string machineConfigJson = JsonConvert.SerializeObject(machine);
            EventDistributor.Instance.Trigger("RegisterMachine", machineConfigJson, coordinatorIp);
        }

        /// <summary>Starts the thread responsible for sending invites to the operators to get them to connect.
        /// It will also periodically send invites if an operator disconnects.</summary>
        private void StartOperatorInviteThread()
        {
            Thread operatorInviteThread = new Thread(OperatorInviteThreadCode)
            {
                Name = "Operator invite thread"
            };
            operatorInviteThread.Start();
        }


        /// <summary>Periodically sends invites to the operators to get them to connect.</summary>
        private void OperatorInviteThreadCode()
        {
            while (true)
            {
                foreach (string op in _operatorList)
                {
                    Machine machine = MachineManager.MachineManager.Instance.GetMachine(op);
                    if (machine != null && machine.IsOnline)
                    {
                        continue;
                    }
                    
                    WebSocketClient wsClient = hub.CreateWsClient(Apps.AusyOperator);

                    if (wsClient.Connect(op, 4650, "Ausy-Ausy"))
                    {
                        Dictionary<string, object> fullMsg = new Dictionary<string, object>
                        {
                            {"message", "DistributedInvite"},
                            {"param", Helper.Instance.Ip}
                        };
                        wsClient.Send(JsonConvert.SerializeObject(fullMsg));
                        wsClient.Disconnect();
                    }
                }
                
                Thread.Sleep(5000);
            }
        }

        #endregion
    }

    public struct CommunicationOptions
    {
        /// <summary>Create a WebSocket server for other apps to connect to as clients.</summary>
        public bool createServerForOtherApps;
        /// <summary>Create a WebSocket server for AuSy operators to connect as clients.</summary>
        public bool createServerForOperators;
        /// <summary>Create a WebSocket client that connects to an AuSy coordinator's server.</summary>
        public bool createClientForCoordinator;
        /// <summary>Are the game logs transmitted via WebSockets?</summary>
        public bool isLogsWebsocket;
        /// <summary>If using a distributed AuSy operator, this is the coordinator IP to connect to.</summary>
        public string CoordinatorIP;
        /// <summary>If using a distributed AuSy operator, use lookout mode.</summary>
        public bool isLookoutOperator;
        /// <summary>If using a distributed AuSy coordinator, this is the list of operator IPs to connect to.</summary>
        public List<string> OperatorList;
    } 
}