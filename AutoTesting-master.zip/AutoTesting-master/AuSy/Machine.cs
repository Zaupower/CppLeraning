using System;
using System.Collections.Generic;
using AuSy.Main;
using AuSy.Modules.MachineManager;
using AutoTestingService.Configuration.AusyConfig;
using AutoTestingService.Logging;
using AutoTestingService.Machine;

namespace AuSy
{
    /// <summary>Machine class.</summary>
	/// <description>Serializable class which holds information about a machine.
	/// In the case of standalone AuSy, this refers to the machine itself.</description>
	[Serializable]
	public class Machine
	{
		#region Members

		/// <summary>Information about the current state of gameplay, as well as functions to interact with it.</summary>
		public GameplayInfo GamePlay;

		/// <summary>Machine configuration (UId, ip, gameName..).</summary>
		public MachineConfig Config { get; private set; }
		
		/// <summary>Gets or sets the unique identifier.</summary>
		//public int UId { get; set; }

		/// <summary>Index that the client goes by in the current session of the server. This is not the client's UID.</summary>
		public int SessionIdx { get; private set; } = 0;

		/// <summary>Gets or sets the IP address.</summary>
		//public string Ip { get; set; }

		/// <summary>Gets or sets the Connection State.</summary>
		public bool IsOnline { get; set; }

		#endregion

		#region Init

		/// <summary>Initializes a new instance of the Machine class.</summary>
		public Machine (MachineConfig config, int sessionIdx, bool isOnline)
		{
			Config = config;
			SessionIdx = sessionIdx;
			IsOnline = isOnline;
			GamePlay = new GameplayInfo(this);
		}

		#endregion

		#region Client Auxiliary

		/// <summary>Check connection status.</summary>
		/// <returns><c>true</c>, if connection status was checked, <c>false</c> otherwise.</returns>
		/// <param name="timeout">Timeout.</param>
		public bool CheckConnectionStatus (int timeout)
		{
			try
			{
				if (IsOnline)
				{
					//TODO
					/*TimeSpan span = AutoTestingServer.Instance.StopWatch.Elapsed - TimeSpan.FromTicks (LastSeen);
					if ((int) span.TotalMilliseconds > timeout)
					{
						disconnectMachine ("Timed out: " + (int) span.TotalMilliseconds + " > " + timeout);
					}*/
					return true;
				}
				return false;
			}
			catch (Exception ex)
			{
				Logger.Instance.UpdateLog (SessionIdx + ": CheckStatus exception caught:\n" + ex.Message, LoggerType.Error);
			}
			return false;
		}

		/// <summary>Disconnects the machine.</summary>
		/// <param name="message">Message.</param>
		private void disconnectMachine (string message)
		{
			if (IsOnline)
			{
				Logger.Instance.UpdateLog ("Connection lost with Machine: " + SessionIdx + " (" + message + ")", LoggerType.Error);
				IsOnline = false;
				//TODO AutoTestingServer.Instance.MachineUpdateSignal.Set ();
			}
		}

		#endregion

		#region Methods

		public void FillGameplayInfo(List<GameEvent> gameEvents)
		{
			if (Config == null || Config.InterpreterConfig == null)
			{
				Logger.Instance.UpdateLog("FillGamePlayInfo: machine config or subsequent objets are null.");
				return;
			}
			Config?.InterpreterConfig?.FillGameplayInfo(gameEvents, GamePlay);
		}

		#endregion
	}
}