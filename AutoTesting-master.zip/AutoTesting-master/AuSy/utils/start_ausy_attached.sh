p=$(ps aux | grep AuSy.exe | grep -v grep | awk '{print $2}')
if [[ $p ]]
then
    echo "AuSy is already running on this machine."
else
    cd /storage/ausy
    export DISPLAY=:0
    ./AuSy.exe
fi
