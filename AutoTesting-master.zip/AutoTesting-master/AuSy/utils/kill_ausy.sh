p=$(ps aux | grep AuSy.exe | grep -v grep | awk '{print $2}')
if [[ $p ]]
then
    kill $p
else
    echo AuSy is not running.
fi
