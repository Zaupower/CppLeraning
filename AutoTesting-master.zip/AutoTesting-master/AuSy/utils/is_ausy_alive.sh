p=$(ps aux | grep AuSy.exe | grep -v grep | awk '{print $2}')
if [[ $p ]]
then
    echo AuSy is running on this machine.
else
    echo AuSy is NOT running on this machine.
fi
