p=$(ps aux | grep AuSy.exe | grep -v grep | awk '{print $2}')
if [[ $p ]]
then
    echo "AuSy is already running on this machine."
else
    setsid nohup /storage/ausy/utils/start_ausy_attached.sh >/dev/null 2>&1 < /dev/null &
fi
