p=$(ps aux | grep AuSy.exe | grep -v grep | awk '{print $2}')
if [[ $p ]]
then
    kill $p
fi
/storage/ausy/utils/start_ausy_detached.sh
