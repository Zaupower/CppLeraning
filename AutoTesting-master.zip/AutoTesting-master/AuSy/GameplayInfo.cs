using System;
using System.Collections.Generic;
using AutoTestingService;
using AutoTestingService.Configuration.EGMConfig;
using AutoTestingService.Configuration.AusyConfig;
using AutoTestingService.Logging;
using AutoTestingService.Machine;
using Newtonsoft.Json;
using Logger = AutoTestingService.Logging.Logger;

namespace AuSy
{
    public class GameplayInfo
    {
	    #region Private members

	    /// <summary>Machine information.</summary>
	    private Machine _machine;

	    #endregion

	    #region Machine members

	    /// <summary>Gets or sets the name of the current game.</summary>
		public string GameName { get; set; }

		/// <summary>Name of the currently selected game, in a multi-game machine.</summary>
		public string CurrentGame { get; set; }

		/// <summary>Gets or sets the version of the operative system distribution.</summary>
		public string Distro { get; set; }

		/// <summary>Machine and game configuration.</summary>
		public EGMConfig Config { get; set; }
		
		/// <summary>Ausy configuration.</summary>
		public AusyConfiguration AusyConfig { get; set; }

		/// <summary>Current amount of credits.</summary>
		public double Credits = 0;

		/// <summary>Information on the current play.</summary>
		public PlayInfo Play;

		#endregion

		#region Setup

		/// <summary>Initializes a new instance of the GameplayInfo class.</summary>
		public GameplayInfo (Machine machine)
		{
			_machine = machine;
			AusyConfig = new AusyConfiguration();
			AusyConfig.SetMachineIp(_machine.Config.Ip);
			Config = new EGMConfig();
			Config.SetMachineIp(_machine.Config.Ip);
			//TODO set GameName, Distro, Config
		}

		#endregion
		
		#region Machine funcions
		
		/// <summary>Request an IP block.</summary>
		/// <param name="ip">Ip to block.</param>
		public void BlockIP (string ip)
		{
			EventDistributor.Instance.Trigger("BlockIp", ip, _machine.Config.Ip);
		}

		/// <summary>Request that the Machine changes game in a multi-game machine.</summary>
		/// <param name="galleryGameNumber">Number of the game in the gallery.</param>
		public void ChangeGame (string galleryGameNumber)
		{
			EventDistributor.Instance.Trigger("ChangeGalleryGame", galleryGameNumber, _machine.Config.Ip);
		}
		
		/// <summary>Request that the Machine clears the NV files.</summary>
		public void ClearNVs ()
		{
			EventDistributor.Instance.Trigger("ClearNVs", "", _machine.Config.Ip);
		}
		
		/// <summary>Compares two images. This function requires the library OpenImageIO Tools. To install it run: "sudo apt-get install -y openimageio-tools" </summary></summary>
		/// <param name="image1">First image</param>
		/// <param name="image2">Second image</param>
		/// <param name="failPercentage">How similar in % the images must be</param>
		/// <returns>Comparison result</returns>
		public bool CompareImages (string image1, string image2, int failPercentage)
		{
			if (Helper.Instance.IsLocalhost(_machine.Config.Ip) || String.IsNullOrEmpty(_machine.Config.Ip))
			{
				int percentageValue = 100 - failPercentage;

				RunCommand shell = new RunCommand();
				bool result = false;

				//https://openimageio.readthedocs.io/en/latest/idiff.html#process-return-codes
				switch (shell.RunExeCommand("idiff",
					" -fail 0.1 -failpercent " + percentageValue + " " + image1 + " " + image2, true))
				{
					case 0:
						Logger.Instance.UpdateLog("CompareImages: The two images were equal.");
						result = true;
						break;
					case 1:
						Logger.Instance.UpdateLog("CompareImages: The two images were similar but not equal.");
						result = true;
						break;
					case 2:
						Logger.Instance.UpdateLog("CompareImages: The two images were different.");
						result = false;
						break;
					case 3:
						Logger.Instance.UpdateLog("CompareImages: Tried to compare images with different sizes.",
							LoggerType.Warning);
						result = false;
						break;
					case 4:
					case null:
						Logger.Instance.UpdateLog("CompareImages: Tried to compare an image that doesn't exist",
							LoggerType.Warning);
						result = false;
						break;
				}

				return result;
			}

			Logger.Instance.UpdateLog (GetSessionIdx () + ": CompareImages warning: can't use this scripting method in distributed mode.", LoggerType.Warning);
			return false;
		}
		
		/// <summary>Request Machine Input.</summary>
		/// <param name="inputs">Inputs to do, separated by space.</param>
		/// <param name="times">Number of times to perform the specified inputs.</param>
		public void DoInput (string inputs, int times)
		{
			//ATS-223
			if (times > 10)
			{
				Logger.Instance.UpdateLog (GetSessionIdx () + ": DoInput warning: pressing a key more than 10 times.", LoggerType.Warning);
			}
			
			EventDistributor.Instance.Trigger("PressKey", inputs + " " + times, _machine.Config.Ip);
		}
		
		/// <summary>Request mouse click.</summary>
		/// <param name="x">X coordinate.</param>
		/// <param name="y">Y coordinate.</param>
		public void DoTouch (int x, int y)
		{
			EventDistributor.Instance.Trigger("Click", x + " " + y, _machine.Config.Ip);
		}

		/// <summary>Fix a broken sums.md5 file.</summary>
		public void FixMD5 ()
		{
			EventDistributor.Instance.Trigger("FixMD5", "", _machine.Config.Ip);
		}
		
		/// <summary>Request that the machine forces the specified balls.</summary>
		/// <param name="balls">Balls to force.</param>
		public void ForceBalls (string balls)
		{
			EventDistributor.Instance.Trigger("ForceBalls", balls, _machine.Config.Ip);
		}

		/// <summary>Request that the machine forces the specified cards.</summary>
		/// <param name="cards">Cards to force.</param>
		public void ForceCards (string cards)
		{
			EventDistributor.Instance.Trigger("ForceCards", cards, _machine.Config.Ip);
		}
		
		/// <summary>Returns the machine's IP address.</summary>
		/// <returns>The IP address.</returns>
		public string GetIp ()
		{
			return _machine.Config.Ip;
		}

		/// <summary>Asks for a specific sas meter.</summary>
		public void GetSASMeter (int meterNumber)
		{
			EventDistributor.Instance.Trigger("GetSASMeter", JsonConvert.SerializeObject(meterNumber), _machine.Config.Ip);
		}
		
		/// <summary>Returns the index that the client goes by in the current session of the server, if any.</summary>
		/// <returns>The session index.</returns>
		public int GetSessionIdx ()
		{
			return _machine.SessionIdx;
		}

		/// <summary>Inserts a bill in the machine.</summary>
		/// <param name="value">Value of bill to be inserted, if applicable.</param>
		public void InsertBill (int value)
		{
			EventDistributor.Instance.Trigger("InsertBill", value.ToString(), _machine.Config.Ip);
		}

		/// <summary>Inserts a card in the machine.</summary>
		/// <param name="number">Number of card to be inserted, if applicable.</param>
		public void InsertCard (string number)
		{
			EventDistributor.Instance.Trigger("InsertCard", number, _machine.Config.Ip);
		}
		
		/// <summary>Inserts credits in the machine.</summary>
		public void InsertCredits ()
		{
			EventDistributor.Instance.Trigger("InsertCredits", "", _machine.Config.Ip);
		}

		/// <summary>Inserts credits in the machine.</summary>
		/// <remarks>\deprecated The argument "times" is deprecated and is not in use.
		/// It will be removed in future versions.</remarks>
		public void InsertCredits (int _)
		{
			Logger.Instance.UpdateLog(
				GetSessionIdx() +
				": Warning, the argument \"times\" in InsertCredits is deprecated and has no effect. It will be removed in future versions.",
				LoggerType.Warning);
			InsertCredits ();
		}

		/// <summary>Inserts a ticket in the machine.</summary>
		/// <param name="validationCode">Validation code of the inserted ticket, if applicable.</param>
		public void InsertTicket (string validationCode)
		{
			EventDistributor.Instance.Trigger("InsertTicket", validationCode, _machine.Config.Ip);
		}

		/// <summary>Request Machine to press specified button.</summary>
		/// <param name="button">Button to press</param>
		public void PressButton (string button)
		{
			EventDistributor.Instance.Trigger("PressButton", button, _machine.Config.Ip);
		}
		
		/// <summary>Request that the Machine Reboots.</summary>
		public void RebootMachine ()
		{
			EventDistributor.Instance.Trigger("Reboot", "", _machine.Config.Ip);
		}

		/// <summary>Remove credits from the machine.</summary>
		public void RemoveCredits ()
		{
			EventDistributor.Instance.Trigger("RemoveCredits", "", _machine.Config.Ip);
		}

		/// <summary>Request a JS timer removal.</summary>
		/// <param name="name">Timer name.</param>
		public void RemoveTimer (string name)
		{
			Tuple<string, int> timerDict = new Tuple<string, int>(name, GetSessionIdx());
			string timerJson = JsonConvert.SerializeObject(timerDict);
			EventDistributor.Instance.Trigger("RemoveJSTimer", timerJson);
		}
		
		/// <summary>Inserts credits in the machine.</summary>
		public void RestartCashcode ()
		{
			EventDistributor.Instance.Trigger("RestartCashcode", "", _machine.Config.Ip);
		}

		/// <summary>Request that the Machine restarts the Game.</summary>
		public void RestartGame ()
		{
			EventDistributor.Instance.Trigger("RestartGame", "", _machine.Config.Ip);
		}
		
		/// <summary>Sends a bytearray to the sasHost to be processed.</summary>
		public void SendSASByteArray (byte [] bytes)
		{
			EventDistributor.Instance.Trigger("SendSASByteArray", JsonConvert.SerializeObject(bytes), _machine.Config.Ip);
		}
		
		/// <summary>Sends the "lpNumber" lp information to the sasHost.</summary>
		public void SendSASLP (int number, object fields)
		{
			SendSASLP(number, fields, "");
		}
		
		/// <summary>Sends the "lpNumber" lp information to the sasHost.</summary>
		public void SendSASLP (int number, object fields, string version)
		{
			IDictionary<string, object> lpInfo = new Dictionary<string, object>();
			lpInfo.Add("number", number);
			lpInfo.Add("fields", fields);
			lpInfo.Add("version", version);
			EventDistributor.Instance.Trigger("SendSASLP", JsonConvert.SerializeObject(lpInfo), _machine.Config.Ip);
		}
		
		/// <summary>Request a JS interval creation.</summary>
		/// <param name="name">Timer name.</param>
		/// <param name="milliseconds">Milliseconds before it triggers.</param>
		/// <param name="code">code to run.</param>
		public void SetInterval (string name, int milliseconds, string code)
		{
			Tuple<string, int, string, int, bool> timerDict = new Tuple<string, int, string, int, bool>(name, milliseconds, code, GetSessionIdx(), true);
			string timerJson = JsonConvert.SerializeObject(timerDict);
			EventDistributor.Instance.Trigger("CreateJSTimer", timerJson);
		}
		
		/// <summary>Request a JS timeout creation.</summary>
		/// <param name="name">Timer name.</param>
		/// <param name="milliseconds">Milliseconds before it triggers.</param>
		/// <param name="code">code to run.</param>
		public void SetTimeout (string name, int milliseconds, string code)
		{
			Tuple<string, int, string, int, bool> timerDict = new Tuple<string, int, string, int, bool>(name, milliseconds, code, GetSessionIdx(), false);
			string timerJson = JsonConvert.SerializeObject(timerDict);
			EventDistributor.Instance.Trigger("CreateJSTimer", timerJson);
		}

		/// <summary>Sends a StartAFTCashIn command to the sasHost.</summary>
		public void StartAFTCashIn (object cashInInfo)
		{
			EventDistributor.Instance.Trigger("StartAFTCashIn", JsonConvert.SerializeObject(cashInInfo), _machine.Config.Ip);
		}
		
		/// <summary>Sends a StartAFTCashOut command to the sasHost.</summary>
		public void StartAFTCashOut ()
		{
			EventDistributor.Instance.Trigger("StartAFTCashOut", "", _machine.Config.Ip);
		}
		
		/// <summary>Take a screenshot.</summary>
		public void TakeScreenshot (int x1, int y1, int x2, int y2, string path)
		{
			EventDistributor.Instance.Trigger("TakeScreenshot", x1 + " " + y1 + " " + x2 + " " + y2 + " " + path, _machine.Config.Ip);
		}
		
		/// <summary>Take a screenshot.</summary>
		public void TakeScreenshot (int x1, int y1, int x2, int y2)
		{
			EventDistributor.Instance.Trigger("TakeScreenshot", x1 + " " + y1 + " " + x2 + " " + y2 + " ", _machine.Config.Ip);
		}

		/// <summary>Take a screenshot.</summary>
		public void TakeScreenshot (string path)
		{
			EventDistributor.Instance.Trigger("TakeScreenshot", "0 0 0 0 " + path, _machine.Config.Ip);
		}

		/// <summary>Take a screenshot.</summary>
		public void TakeScreenshot ()
		{
			EventDistributor.Instance.Trigger("TakeScreenshot", "0 0 0 0 ", _machine.Config.Ip);
		}

		/// <summary>Request an IP unblock.</summary>
		/// <param name="ip">Ip to unblock.</param>
		public void UnblockIP (string ip)
		{
			EventDistributor.Instance.Trigger("UnblockIP", ip, _machine.Config.Ip);
		}

		/// <summary>Sends a remote reset hand pay command to the sasHost.</summary>
		public void ValidateRemoteHandpay()
		{
			EventDistributor.Instance.Trigger("RemoteResetHandpay", "", _machine.Config.Ip);
		}
		
		
		#endregion
	}
}