using System.Collections.Generic;

namespace AuSy
{
    public class PlayInfo
    {
        /// <summary>Balls used for the extraction.</summary>
        public List<int> Balls = new List<int> ();

        /// <summary>Extra balls purchased.</summary>
        public List<ExtraBall> ExtraBalls = new List<ExtraBall> ();

        /// <summary>Cards in use, along with their numbers.</summary>
        public List<List<int>> Cards = new List<List<int>> ();

        /// <summary>Prizes won throughout the play.</summary>
        public List<Prize> Prizes = new List<Prize> ();

        /// <summary>List of bonuses entered and how they were played.</summary>
        public List<BonusPlay> BonusPlays = new List<BonusPlay> ();

    }

    public class Prize
    {
        /// <summary>Card in which the prize landed.</summary>
        public int card;
        /// <summary>ID of the prize.</summary>
        public int id;
        /// <summary>Value of the prize.</summary>
        public double value;
    }

    public class ExtraBall
    {
        /// <summary>Number displayed on the ball.</summary>
        public int number;
        /// <summary>Its cost.</summary>
        public double cost;
    }

    public class BonusPlay
    {
        /// <summary>How much each bonus piece is worth.</summary>
        public List<int> pieceValues = new List<int> ();
    }
}