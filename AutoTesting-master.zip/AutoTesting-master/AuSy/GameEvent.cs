using System.Collections.Generic;

namespace AuSy
{
    public struct GameEvent
    {
        /// <summary>Origin machine's IP.</summary>
        public string ip;
        /// <summary>Name of the event.</summary>
        public string name;
        /// <summary>Parameters about this specific event.</summary>
        public List<object> parameters;
        /// <summary>Type of parameters about this specific event.</summary>
        public string[] types;

        public GameEvent (string name, List<object> parameters = null, string[] types = null)
        {
            ip = "";
            
            this.name = name;

            if (parameters == null)
            {
                parameters = new List<object> ();
            }
            this.parameters = parameters;
            if (types == null)
            {
                types = new string[]{} ;
            }
            this.types = types;
        }
    }
}