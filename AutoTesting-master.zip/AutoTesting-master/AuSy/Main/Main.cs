﻿using System.Threading;

namespace AuSy.Main
{
    class Program
    {
        public static void Main(string[] args)
        {
            Ausy ausy = new Ausy();
            ausy.Init();
            
            bool exitAusy = false;
            while (!exitAusy)
            {
                WaitHandle.WaitAny(new WaitHandle[] { ausy.stopSignal });

                if (!ausy.doingSoftRestart)
                { 
                    exitAusy = true; 
                }
            }
        }
    }
}