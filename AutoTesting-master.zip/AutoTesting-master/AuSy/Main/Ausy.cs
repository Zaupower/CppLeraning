using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using AuSy.Modules.Accounting;
using AuSy.Modules.ActionMediator;
using AuSy.Modules.Communication;
using AuSy.Modules.GameLogsParser;
using AuSy.Modules.GameLogsReader;
using AuSy.Modules.GameLogsWsSetup;
using AuSy.Modules.MachineManager;
using AuSy.Modules.PeripheralMediator;
using AuSy.Modules.Scripter;
using AuSy.Modules.TestManager;
using AutoTestingService;
using AutoTestingService.Configuration;
using AutoTestingService.Configuration.AusyConfig;
using AutoTestingService.Logging;
using AutoTestingService.Shared;
using Newtonsoft.Json;
using EventHandler = AutoTestingService.EventHandler;

namespace AuSy.Main
{
	public class Ausy
	{
		#region Variables

		public ManualResetEvent stopSignal = new ManualResetEvent(false);

		public bool doingSoftRestart = false;
		
		#endregion

		#region Startup

		/// <summary>Initialization method. Initializes/loads Ausy configurations and Modules.</summary>
		public void Init()
		{
			LoadAusyConfig();
			InitFundamentalModules();
			InitBehaviorModules();
			if (!AutonomousMode.Instance.ausySoftRestartDone)
			{
				FinishInit();
			}
		}
		
		#endregion

		#region Config

		/// <summary>Loads the configuration file.</summary>
		private void LoadAusyConfig()
		{
			ConfigsManager.Instance.LoadAusyConfig(true);

			ConfigsManager.Instance.AusyConfig.FinishSetup();
			if (!ConfigsManager.Instance.AusyConfig.Verify())
			{
				Environment.Exit(1);
			}
		}

		#endregion

		#region Init procedure

		/// <summary>Initializes the essential modules for different parts of AuSy to communicate with others,
		/// based on the current config.</summary>
		private void InitFundamentalModules()
		{
			// Logger.
			Logger.Instance.Initialize(
				string.Format(ATNames.Instance.LogFilePath, DateTime.Now.ToString(ATNames.Instance.DateTimePattern))
			);
			
			// Communications.
			Communication.Instance.Init(
				new CommunicationOptions
				{
					isLogsWebsocket = ConfigsManager.Instance.AusyConfig.Game.ReadLogsWebsocket,
					createServerForOperators = ConfigsManager.Instance.AusyConfig.Application.Role == "coordinator",
					createServerForOtherApps = ConfigsManager.Instance.AusyConfig.Application.Role == "coordinator" ||
					                           ConfigsManager.Instance.AusyConfig.Application.StandaloneMode,
					CoordinatorIP = ConfigsManager.Instance.AusyConfig.Operator.CoordinatorIP,
					createClientForCoordinator = ConfigsManager.Instance.AusyConfig.Application.Role == "operator" &&
					                             !ConfigsManager.Instance.AusyConfig.Application.StandaloneMode,
					OperatorList = ConfigsManager.Instance.AusyConfig.Coordinator.OperatorList,
					isLookoutOperator = ConfigsManager.Instance.AusyConfig.Application.Role == "operator" &&
					                       !ConfigsManager.Instance.AusyConfig.Application.StandaloneMode &&
					                       ConfigsManager.Instance.AusyConfig.Operator.CoordinatorIP == "lookout"
				},
				ConfigsManager.Instance.AusyConfig.Game.LogType,
				ConfigsManager.Instance.AusyConfig.Game.GamePath
			);

			// Event distributor.
			EventDistributor.Instance.Init(
				Communication.Instance.hub
			);
			EventHandler.Instance.AddCallback("GuiConnected", GuiConnected);
			EventHandler.Instance.AddCallback("RestartAusy", AusySoftRestart);
		}

		/// <summary>Initializes the necessary modules for AuSy to do the behaviors specified in the current config.</summary>
		private void InitBehaviorModules()
		{
			if (ConfigsManager.Instance.AusyConfig.Application.Role == "operator")
			{
				InitOperationModules();
			}

			if (ConfigsManager.Instance.AusyConfig.Application.StandaloneMode ||
			    ConfigsManager.Instance.AusyConfig.Application.Role == "coordinator")
			{
				InitTestingModules();
			}
		}

		/// <summary>Initializes modules related to game operations.</summary>
		private void InitOperationModules()
		{
			// Accounting.
			Accounting.Instance.Init(
				ConfigsManager.Instance.AusyConfig.Accounting.CashSystem,
				ConfigsManager.Instance.AusyConfig.Accounting.S2S,
				ConfigsManager.Instance.AusyConfig.Peripherals.SASPort
			);

			// Action mediator.
			ActionMediator.Instance.Init(
				new ActionMediatorConfig
				{
					GamePath = ConfigsManager.Instance.AusyConfig.Game.GamePath,
					InputDelay = ConfigsManager.Instance.AusyConfig.Application.InputDelay,
					LogsPath = ConfigsManager.Instance.AusyConfig.Game.LogsPath,
					LogType = ConfigsManager.Instance.AusyConfig.Game.LogType
				}
			);

			// Websocket log setup.
			if (ConfigsManager.Instance.AusyConfig.Game.LogsWebSocketReceiverIP.Length > 0)
			{
				GameLogsWsSetup.Instance.Init(
					ConfigsManager.Instance.AusyConfig.Game.LogsWebSocketReceiverIP,
					ConfigsManager.Instance.AusyConfig.Game.GamePath
				);
			}

			// Log reader.
			GameLogsReader.Instance.Init(
				new GameLogsReaderConfig
				{
					gameFolder = ConfigsManager.Instance.AusyConfig.Game.GamePath,
					logMode = ConfigsManager.Instance.AusyConfig.Game.ReadLogsWebsocket
						? LogReaderMode.WebSocket
						: LogReaderMode.LogFile,
					logsFolder = ConfigsManager.Instance.AusyConfig.Game.LogsPath
				},
				stopSignal
			);

			// Peripheral mediator.
			PeripheralMediator.Instance.Init(
				ConfigsManager.Instance.AusyConfig.Peripherals,
				ConfigsManager.Instance.AusyConfig.Accounting.EnableKeyboardAcceptor,
				Accounting.Instance.GetRequiredPeripherals()
			);
		}

		private void TerminateOperationModules()
		{
			Accounting.Instance.Terminate();
			ActionMediator.Instance.Terminate();
			if (ConfigsManager.Instance.AusyConfig.Game.LogsWebSocketReceiverIP.Length > 0)
			{
				GameLogsWsSetup.Instance.Terminate();
			}
			GameLogsReader.Instance.Terminate();
			PeripheralMediator.Instance.Terminate();
		}

		/// <summary>Initializes modules related to testing.</summary>
		private void InitTestingModules()
		{
			// Log parser.
			GameLogsParser.Instance.Init(
				ConfigsManager.Instance.AusyConfig.Game.LogType,
				ConfigsManager.Instance.AusyConfig.Application.ReportUnknownLogLines
			);

			// Machine manager.
			MachineManager.Instance.Init(
				ConfigsManager.Instance.AusyConfig.Application.StandaloneMode,
				ConfigsManager.Instance.AusyConfig.Game.LogType,
				ConfigsManager.Instance.AusyConfig.Game.GamePath
			);

			// Scripter.
			Scripter.Instance.Init(
				ConfigsManager.Instance.AusyConfig.Application.StandaloneMode,
				ConfigsManager.Instance.AusyConfig.Game.GamePath,
				ConfigsManager.Instance.AusyConfig.Application.TestFile,
				stopSignal
			);

			// Test manager.
			TestManager.Instance.Init(
				ConfigsManager.Instance.AusyConfig.Application.TestDefinitionsPath
			);
		}

		private void TerminateTestingModules()
		{
			GameLogsParser.Instance.Terminate();
			MachineManager.Instance.Terminate();
			Scripter.Instance.Terminate();
			TestManager.Instance.Terminate();
		}

		/// <summary>Finishes the initialization process, and notifies other modules that it is finished.</summary>
		void FinishInit()
		{
			EventHandler.Instance.Trigger("StartAusy", "");
			if (!AutonomousMode.Instance.ausySoftRestartDone)
			{
				EventHandler.Instance.Trigger("StartAusy2", "");
			}
		}

		private void AusySoftRestart(string _, EventInfo? __)
		{
			doingSoftRestart = true;
			stopSignal.Set();
			if (ConfigsManager.Instance.AusyConfig.Application.Role == "operator")
			{
				TerminateOperationModules();
			}

			if (ConfigsManager.Instance.AusyConfig.Application.StandaloneMode ||
			    ConfigsManager.Instance.AusyConfig.Application.Role == "coordinator")
			{
				TerminateTestingModules();
			}

			stopSignal.Reset();

			LoadAusyConfig();
			InitBehaviorModules();
			FinishInit();
			doingSoftRestart = false;
		}
		
		#endregion

		#region GUI Handling

		public void GuiConnected(string _, EventInfo? __)
		{
			if (ConfigsManager.Instance.AusyConfig.Game.LogsPath != "/logs")
			{
				EventHandler.Instance.Trigger("SendGuiMessage",
					"CustomLogsFolderNote;" + ConfigsManager.Instance.AusyConfig.Game.LogsPath);
			}
		}

		#endregion
	}
}