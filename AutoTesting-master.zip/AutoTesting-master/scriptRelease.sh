#!/bin/bash

###################
# SETUP
###################

if [ "$#" -ne 1 ]; then
    echo "Please run this script with the version name as an argument."
	exit
fi

function finish() {
	statusStr="AuSy release creation finished successfully!"
	if [ "$1" -eq 1 ]; then
		statusStr="AuSy release creation failed. See above for errors."
	elif [ "$1" -eq 2 ]; then
		statusStr="AuSy release creation finished successfully but with warnings. See above for warnings."
	fi
	echo " "
	echo "=========================="
	echo $statusStr
	echo "=========================="
	exit
}

#Setup.
pcReleaseName="$1_pc"
patchName="$1_patch"
ausyRepoDir=$(pwd)
sasHostRepoDir=$ausyRepoDir/../fmqsashost
emuRepoDir=$ausyRepoDir/../fmq-server-emulator
releaseDir=$ausyRepoDir/$pcReleaseName
patchDir=$ausyRepoDir/$patchName

#Build AuSy.
msbuild AuSy/ || finish 1

###################
# RELEASE
###################

#Create the release folder.
mkdir $pcReleaseName
cd $pcReleaseName
mkdir ausy
cd ausy
mkdir gui

#Compile and copy libSasSerial.so.
cd $sasHostRepoDir/libSasSerial || finish 1
make clean
make
pcSasLibResult=$?
cp ./libSasSerial.so $releaseDir/ausy/

#Copy folders of things.
cd $releaseDir/ausy
mkdir log_types
cp $ausyRepoDir/AuSy/Modules/GameLogsParser/DefaultRules/bingo.json ./log_types || finish 1
cp $ausyRepoDir/AuSy/Modules/GameLogsParser/DefaultRules/slots.json ./log_types || finish 1
cp -r $ausyRepoDir/AuSy/gameData . || finish 1
cp -r $ausyRepoDir/AuSy/utils . || finish 1

#Copy binary and associated files.
cp $ausyRepoDir/AuSy/bin/Debug/*.exe . || finish 1
chmod 777 *.exe || finish 1
cp $ausyRepoDir/AuSy/bin/Debug/*.pdb . || finish 1
cp $ausyRepoDir/AuSy/bin/Debug/*.dll . || finish 1

#Copy GUI.
cd gui || finish 1
cp $emuRepoDir/WebGUI/* .

#Create the final release zip.
cd $ausyRepoDir
cd $pcReleaseName
zip -r $ausyRepoDir/$pcReleaseName.zip ausy || finish 1
rm -r $releaseDir

###################
# PATCH
###################

#Create the patch folder.
cd $ausyRepoDir
mkdir $patchName
cd $patchName
mkdir storage
cd storage
mkdir ausy
cd ausy
mkdir utils

#Compile and copy libSasSerial.so.
cd $sasHostRepoDir/libSasSerial || finish 1
make clean
make 32
patchSasLib32Result=$?
cp ./libSasSerial.so $patchDir/storage/ausy/utils/libSasSerial32.so
make clean
make
patchSasLib64Result=$?
cp ./libSasSerial.so $patchDir/storage/ausy/utils/libSasSerial64.so
make clean

#Copy folders of things.
cd $patchDir/storage/ausy
mkdir log_types
cp $ausyRepoDir/AuSy/Modules/GameLogsParser/DefaultRules/bingo.json ./log_types || finish 1
cp $ausyRepoDir/AuSy/Modules/GameLogsParser/DefaultRules/slots.json ./log_types || finish 1
cp -r $ausyRepoDir/AuSy/gameData . || finish 1
cp -r $ausyRepoDir/AuSy/utils . || finish 1

#Copy binary and associated files.
cp $ausyRepoDir/AuSy/bin/Debug/*.exe . || finish 1
chmod 777 *.exe || finish 1
cp $ausyRepoDir/AuSy/bin/Debug/*.pdb . || finish 1
cp $ausyRepoDir/AuSy/bin/Debug/*.dll . || finish 1

#Create the final patch content zip.
cd $ausyRepoDir
cd $patchName
zip -r $ausyRepoDir/$patchName.zip storage || finish 1
rm -r $patchDir

###################
# FINISH
###################

echo " "
echo "=========================="

finishStatus=0
if [ "$pcSasLibResult" -ne 0 ]; then
    echo "WARNING: libSasSerial.so for PC was not compiled correctly."
	finishStatus=2
fi

if [ "$patchSasLib32Result" -ne 0 ]; then
    echo "WARNING: libSasSerial.so for Quixant 32-bit was not compiled correctly."
	finishStatus=2
fi
if [ "$patchSasLib64Result" -ne 0 ]; then
    echo "WARNING: libSasSerial.so for Quixant 64-bit was not compiled correctly."
	finishStatus=2
fi

finish $finishStatus
